package com.javid.downloader;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Explicit, owner-requested one-off connection test, without interrupting polling.
 * The token stays in Android Keystore and memory; NEVER save URLs or exceptions.
 * No message is sent and no user/chat information is requested.
 */
final class TelegramConnectionProbe {
    private TelegramConnectionProbe() { }

    static String check(Context context) {
        if (!BotSecrets.hasToken(context))
            return "⚠️ توکن بات در این گوشی ثبت نشده است.";
        HttpURLConnection connection = null;
        try {
            String token = BotSecrets.read(context);
            if (!token.matches("[0-9]{5,15}:[A-Za-z0-9_-]{30,}"))
                return "⚠️ شکل توکن تلگرام معتبر نیست؛ دوباره ثبتش کن.";
            URL endpoint = new URL("https://api.telegram.org/bot" + token + "/getMe");
            connection = (HttpURLConnection) endpoint.openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setRequestProperty("Accept", "application/json");
            int http = connection.getResponseCode();
            if (http == 401 || http == 403) return "❌ تلگرام توکن بات را نپذیرفت (" + http + ").";
            if (http == 429) return "⏳ محدودیت موقت درخواست تلگرام؛ بعداً دوباره امتحان کن.";
            if (http != 200) return "⚠️ سرور تلگرام پاسخ HTTP " + http + " داد.";
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] bytes = new byte[1024];
                int n;
                while ((n = input.read(bytes)) != -1 && output.size() < 4096)
                    output.write(bytes, 0, Math.min(n, 4096 - output.size()));
                JSONObject response = new JSONObject(
                    new String(output.toByteArray(), StandardCharsets.UTF_8));
                if (!response.optBoolean("ok", false))
                    return "⚠️ تلگرام هویت بات را تأیید نکرد.";
                JSONObject bot = response.optJSONObject("result");
                String username = bot == null ? "" : bot.optString("username", "");
                if (!username.matches("[A-Za-z0-9_]{5,32}")) username = "بات ثبت‌شده";
                else username = "@" + username;
                return "✅ ارتباط مستقیم با تلگرام برقرار است: " + username +
                    "\nاین تست فقط هویت بات را تأیید می‌کند؛ فعال بودن دریافت پیام‌ها در جای دیگری باید جداگانه بررسی شود.";
            }
        } catch (Exception ignored) {
            // Never leak an exception string: it may contain the token-bearing URL.
            return "📴 ارتباط با Telegram API برقرار نشد؛ اینترنت یا محدودیت شبکه را بررسی کن.";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}

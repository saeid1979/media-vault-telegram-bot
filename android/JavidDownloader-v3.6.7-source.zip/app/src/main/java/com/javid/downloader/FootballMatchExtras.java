package com.javid.downloader;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Verified first-XI and half-time details only. No estimated lineups or fabricated statistics. */
final class FootballMatchExtras {
    private FootballMatchExtras() {}
    static final class Lineup {
        final List<String> home=new ArrayList<>(), away=new ArrayList<>();
        String homeFormation="", awayFormation="", source="";
        boolean complete() {return home.size()>=9 && away.size()>=9;}
    }
    private static String clean(String value) {
        if(value==null)return "";
        String s=value.replace('\n',' ').replace('\r',' ').replace('\t',' ').trim();
        return s.length()>45?s.substring(0,45):s;
    }
    private static void listPlayers(JSONArray source,List<String> output,boolean startersFlag) {
        if(source==null)return;
        for(int i=0;i<source.length()&&i<45&&output.size()<11;i++) {
            JSONObject item=source.optJSONObject(i);
            if(item==null)continue;
            if(startersFlag && !item.optBoolean("starter",false))continue;
            JSONObject athlete=item.optJSONObject("athlete");
            String name=clean(athlete==null?item.optString("name", ""):
                athlete.optString("displayName",athlete.optString("name","")));
            if(name.isEmpty())name=clean(item.optString("name", ""));
            if(!name.isEmpty()&&!output.contains(name))output.add(name);
        }
    }
    static Lineup fromEspn(JSONObject response) {
        Lineup lineup=new Lineup();lineup.source="ESPN";
        JSONArray rosters=response.optJSONArray("rosters");
        if(rosters==null)return lineup;
        for(int i=0;i<rosters.length()&&i<2;i++) {
            JSONObject row=rosters.optJSONObject(i);
            if(row==null)continue;
            String side=row.optString("homeAway", "");
            // ESPN commonly lists home first and away second. Only use fallback
            // if two roster slots are explicitly present.
            List<String> people="away".equalsIgnoreCase(side)?lineup.away:
                "home".equalsIgnoreCase(side)?lineup.home:i==0?lineup.home:lineup.away;
            listPlayers(row.optJSONArray("roster"),people,true);
            if(people.size()<9)people.clear();
        }
        return lineup;
    }
    static Lineup fromFotmob(JSONObject response) {
        Lineup lineup=new Lineup();lineup.source="FotMob";
        JSONObject content=response.optJSONObject("content");
        JSONObject line=content==null?null:content.optJSONObject("lineup");
        if(line==null)return lineup;
        JSONObject home=line.optJSONObject("homeTeam"),away=line.optJSONObject("awayTeam");
        if(home==null||away==null)return lineup;
        lineup.homeFormation=clean(home.optString("formation",""));
        lineup.awayFormation=clean(away.optString("formation",""));
        listPlayers(home.optJSONArray("starters"),lineup.home,false);
        listPlayers(away.optJSONArray("starters"),lineup.away,false);
        return lineup;
    }
    static Lineup fromSofa(JSONObject response) {
        Lineup lineup=new Lineup();lineup.source="Sofascore";
        JSONObject home=response.optJSONObject("home"),away=response.optJSONObject("away");
        if(home==null||away==null)return lineup;
        if(!home.optBoolean("confirmed",false)||!away.optBoolean("confirmed",false))return lineup;
        lineup.homeFormation=clean(home.optString("formation",""));
        lineup.awayFormation=clean(away.optString("formation",""));
        listPlayers(home.optJSONArray("players"),lineup.home,true);
        listPlayers(away.optJSONArray("players"),lineup.away,true);
        return lineup;
    }
    static Lineup fetchLineup(FootballLiveTracker.Match m) {
        try {
            if(m.id.startsWith("espn:")) {
                int index=m.id.lastIndexOf(':');
                JSONObject response=FootballLiveTracker.getJson(
                    "https://site.api.espn.com/apis/site/v2/sports/soccer/"+
                    m.id.substring(5,index)+"/summary?event="+m.id.substring(index+1),1_600_000);
                return fromEspn(response);
            }
            if(m.id.startsWith("fotmob:")) {
                JSONObject response=FootballLiveTracker.getJson(
                    "https://www.fotmob.com/api/data/matchDetails?matchId="+
                    m.id.substring(7),2_400_000);
                return fromFotmob(response);
            }
            if(m.id.startsWith("sofa:")) {
                JSONObject response=FootballLiveTracker.getJson(
                    "https://www.sofascore.com/api/v1/event/"+m.id.substring(5)+"/lineups",550_000);
                return fromSofa(response);
            }
        }catch(Exception ignored) { /* provider lineup not available */ }
        return new Lineup();
    }
    static String lineupMessage(FootballLiveTracker.Match m,Lineup lineup) {
        if(!lineup.complete())return "";
        StringBuilder s=new StringBuilder("📋 ترکیب اولیه تأییدشده\n");
        s.append(m.league).append("\n").append(m.home).append(" — ").append(m.away).append("\n");
        s.append("\n🏠 ").append(m.home);
        if(!lineup.homeFormation.isEmpty())s.append(" (").append(lineup.homeFormation).append(")");
        s.append("\n").append(String.join("، ",lineup.home));
        s.append("\n\n✈️ ").append(m.away);
        if(!lineup.awayFormation.isEmpty())s.append(" (").append(lineup.awayFormation).append(")");
        s.append("\n").append(String.join("، ",lineup.away));
        s.append("\nمنبع: ").append(lineup.source);
        return s.toString();
    }
    static String halftimeMessage(FootballLiveTracker.Match m) {
        StringBuilder message=new StringBuilder("⏸ پایان نیمه اول\n");
        message.append(m.league).append("\n").append(m.home).append(" ")
            .append(m.score()).append(" ").append(m.away).append("\n");
        FootballFinalStats.Summary stats=new FootballFinalStats.Summary();
        stats.source=m.source;
        try {
            if(m.id.startsWith("fotmob:")) {
                JSONObject result=FootballLiveTracker.getJson("https://www.fotmob.com/api/data/matchDetails?matchId="+
                    m.id.substring(7),2_400_000);
                stats=FootballFinalStats.fromFotmob(result); // At half-time All reflects first half played.
            }else if(m.id.startsWith("sofa:")) {
                JSONObject result=FootballLiveTracker.getJson("https://www.sofascore.com/api/v1/event/"+
                    m.id.substring(5)+"/statistics",800_000);
                stats=FootballFinalStats.fromSofascore(result,null,null);
            }else if(m.id.startsWith("espn:")) {
                int index=m.id.lastIndexOf(':');
                JSONObject result=FootballLiveTracker.getJson(
                    "https://site.api.espn.com/apis/site/v2/sports/soccer/"+
                    m.id.substring(5,index)+"/summary?event="+m.id.substring(index+1),1_600_000);
                stats=FootballFinalStats.fromEspn(result);
            }
        }catch(Exception ignored) {}
        String[] keys={"⚪ مالکیت توپ","🥅 مجموع شوت‌ها","🎯 شوت در چارچوب","🚩 کرنر"};
        boolean has=false;
        for(String key:keys) {
            String[] pair=stats.stats.get(key);
            if(pair==null)continue;
            if(!has){message.append("\n📊 آمار نیمه اول (میزبان | میهمان)\n");has=true;}
            message.append(key).append(": ").append(pair[0]).append(" | ").append(pair[1]).append("\n");
        }
        if(!has)message.append("\nآمار تفصیلی نیمه اول از منبع در دسترس نیست.\n");
        message.append("منبع: ").append(stats.source.isEmpty()?m.source:stats.source);
        return message.toString();
    }
}

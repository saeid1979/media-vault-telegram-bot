package com.javid.downloader;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Small on-device retry queue for FAILED football alert deliveries.
 *
 * No bulk chat import, no background server, no saved bot token. Retries are
 * bounded in size, attempts and age. Messages are retried only for recipients
 * who are still subscribed, and only for the currently configured channel.
 *
 * Telegram sendMessage has no idempotency key; when Telegram accepts a message
 * but its HTTP acknowledgement is lost, an occasional duplicate is possible.
 */
final class AlertDeliveryOutbox extends SQLiteOpenHelper {
    private static final String FILE_NAME = "javid_alert_outbox_v1.db";
    private static final String TABLE = "pending_alerts";
    private static final long TTL = TimeUnit.HOURS.toMillis(2);
    private static final int MAX_PENDING = 200;
    private static final int MAX_ATTEMPTS = 5;

    interface Sender { void send(String destination, String body) throws Exception; }
    interface Eligibility { boolean allowed(String destination,String body); }

    static final class Pending {
        final long id;
        final String destination, body;
        final int attempts;
        Pending(long id,String destination,String body,int attempts) {
            this.id=id;this.destination=destination;this.body=body;this.attempts=attempts;
        }
    }
    static final class QueueStats {
        final int pending;
        final long oldestMs;
        QueueStats(int pending,long oldestMs) {this.pending=pending;this.oldestMs=oldestMs;}
    }

    AlertDeliveryOutbox(Context context) { super(context, FILE_NAME, null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE + " ("+
            "_id INTEGER PRIMARY KEY AUTOINCREMENT,"+
            "destination TEXT NOT NULL, body TEXT NOT NULL, unique_key TEXT NOT NULL UNIQUE,"+
            "created_at INTEGER NOT NULL, next_retry INTEGER NOT NULL,"+
            "attempts INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX IF NOT EXISTS pending_next_retry ON "+TABLE+"(next_retry)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {}

    private static String hash(String destination,String message) throws Exception {
        MessageDigest sha=MessageDigest.getInstance("SHA-256");
        byte[] value=sha.digest((destination+"\n"+message).getBytes(StandardCharsets.UTF_8));
        StringBuilder out=new StringBuilder();
        for(byte b:value)out.append(String.format(java.util.Locale.US,"%02x",b & 255));
        return out.toString();
    }
    private void expire(SQLiteDatabase db,long now) {
        db.delete(TABLE, "created_at<? OR attempts>=?",new String[]{
            String.valueOf(now-TTL),String.valueOf(MAX_ATTEMPTS)
        });
    }
    synchronized void addFailure(String destination,String message) {
        if(destination==null || message==null || message.isEmpty() || message.length()>3900)
            return;
        try {
            SQLiteDatabase db=getWritableDatabase();
            long now=System.currentTimeMillis();
            expire(db,now);
            ContentValues record=new ContentValues();
            record.put("destination",destination);
            record.put("body",message);
            record.put("unique_key",hash(destination,message));
            record.put("created_at",now);
            record.put("next_retry",now+TimeUnit.MINUTES.toMillis(2));
            record.put("attempts",1); // first immediate network attempt has already failed
            db.insertWithOnConflict(TABLE,null,record,SQLiteDatabase.CONFLICT_IGNORE);
            // Bound storage on devices used by several opted-in members.
            db.execSQL("DELETE FROM "+TABLE+" WHERE _id NOT IN ("+
                "SELECT _id FROM "+TABLE+" ORDER BY _id DESC LIMIT "+MAX_PENDING+")");
        } catch(Exception ignored) {
            // Failure to persist a retry must not crash the owner-visible bot.
        }
    }
    synchronized int discardRecipient(String destination) {
        if(destination==null || destination.isEmpty())return 0;
        return getWritableDatabase().delete(TABLE,"destination=?",
            new String[]{destination});
    }
    synchronized QueueStats stats() {
        SQLiteDatabase db=getWritableDatabase();
        expire(db,System.currentTimeMillis());
        try(Cursor c=db.rawQuery("SELECT COUNT(*), MIN(created_at) FROM "+TABLE,null)) {
            if(c.moveToFirst()) return new QueueStats(c.getInt(0),c.isNull(1)?0:c.getLong(1));
        }
        return new QueueStats(0,0);
    }
    private static boolean allowedRecipient(String address,BotUserStore userStore,
                                            String activeChannel) {
        if(address.equals(activeChannel) && HourlyDigestPublisher.channelValid(address))
            return true;
        // Positive numeric IDs are only direct chats, not channel or group IDs.
        if(!address.matches("[1-9][0-9]{0,18}"))return false;
        try {
            BotUserStore.User user=userStore.find(Long.parseLong(address));
            return user!=null && user.active && !user.blocked && user.digestSubscribed;
        } catch(Exception ignored){return false;}
    }
    synchronized int retry(Sender sender,BotUserStore users,String activeChannel,int maxCount) {
        return retry(sender,users,activeChannel,maxCount,(destination,body)->true);
    }
    synchronized int retry(Sender sender,BotUserStore users,String activeChannel,
                           int maxCount,Eligibility eligible) {
        SQLiteDatabase db=getWritableDatabase();
        long now=System.currentTimeMillis();
        expire(db,now);
        List<Pending> tasks=new ArrayList<>();
        // Prevent a huge burst after a long network interruption.
        try(Cursor c=db.rawQuery("SELECT _id,destination,body,attempts FROM "+TABLE+
            " WHERE next_retry<=? ORDER BY next_retry,_id LIMIT ?",
            new String[]{String.valueOf(now),String.valueOf(Math.min(8,Math.max(0,maxCount)))})) {
            while(c.moveToNext())tasks.add(new Pending(
                c.getLong(0),c.getString(1),c.getString(2),c.getInt(3)));
        }
        int sent=0;
        for(Pending item:tasks) {
            if(Thread.currentThread().isInterrupted())break;
            if(!allowedRecipient(item.destination,users,activeChannel) ||
                !eligible.allowed(item.destination,item.body)) {
                db.delete(TABLE,"_id=?",new String[]{String.valueOf(item.id)});
                continue;
            }
            try {
                sender.send(item.destination,item.body);
                db.delete(TABLE,"_id=?",new String[]{String.valueOf(item.id)});
                sent++;
            }catch(Exception networkFailure) {
                int nextAttempt=item.attempts+1;
                if(nextAttempt>=MAX_ATTEMPTS) {
                    db.delete(TABLE,"_id=?",new String[]{String.valueOf(item.id)});
                    continue;
                }
                // bounded exponential backoff: 4, 8, 16... minutes.
                long delay=TimeUnit.MINUTES.toMillis(1L << Math.min(nextAttempt,4));
                ContentValues patch=new ContentValues();
                patch.put("attempts",nextAttempt);
                patch.put("next_retry",System.currentTimeMillis()+delay);
                db.update(TABLE,patch,"_id=?",new String[]{String.valueOf(item.id)});
            }
            try {Thread.sleep(220);}catch(InterruptedException interrupted){
                Thread.currentThread().interrupt();break;
            }
        }
        return sent;
    }
}

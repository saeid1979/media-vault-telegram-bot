package com.javid.downloader;

/** Stateless anti-duplicate gates. Require observed transitions; no backlog when bot starts. */
final class FootballMatchMilestones {
    private FootballMatchMilestones() {}

    static boolean canFetchLineup(boolean upcoming, long kickoff, long now, boolean alreadySent) {
        return upcoming && !alreadySent && kickoff > now &&
            kickoff - now <= 90L * 60_000L;
    }
    static boolean shouldSendLineup(boolean upcoming, long kickoff, long now,
                                    boolean alreadySent, int homeStarters, int awayStarters) {
        return canFetchLineup(upcoming,kickoff,now,alreadySent) &&
            homeStarters>=9 && awayStarters>=9;
    }
    static boolean shouldSendKickoff(boolean hadBaseline, boolean oldUpcoming,
                                     boolean oldLive, boolean currentLive,
                                     boolean alreadySent, long kickoff, long now) {
        return hadBaseline && oldUpcoming && !oldLive && currentLive && !alreadySent &&
            kickoff>0 && now>=kickoff-10L*60_000L && now<=kickoff+35L*60_000L;
    }
    static boolean shouldSendHalftime(boolean hadBaseline, boolean previouslyLive,
                                      boolean previouslyHalftime, boolean currentHalftime,
                                      boolean alreadySent) {
        return hadBaseline && previouslyLive && !previouslyHalftime &&
            currentHalftime && !alreadySent;
    }
    static boolean isHalfTime(String status) {
        if(status==null)return false;
        String s=status.trim().toLowerCase(java.util.Locale.ROOT);
        return s.equals("ht") || s.equals("half time") || s.equals("halftime") ||
            s.equals("half-time") || s.equals("status_halftime") ||
            s.equals("half time break") || s.equals("intermission") ||
            s.equals("1st half ended");
    }
}

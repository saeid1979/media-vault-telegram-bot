package com.javid.downloader;

import android.content.Context;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Opt-in, explicit-request-only cloud transcription and text replies. */
public final class JavidCloudAiClient {
    public static final String SETTINGS = "javid_cloud_ai_settings";
    public static final String ENABLED = "enabled";
    public static final String VOICE_ENABLED = "voice_enabled";
    public static final long MAX_VOICE_BYTES=8L*1024L*1024L;
    private JavidCloudAiClient() { }
    public static boolean canChat(Context context) {
        return context.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE).getBoolean(ENABLED,false)
            && JavidAiSecrets.configured(context);
    }
    public static boolean canVoice(Context context) {
        return canChat(context) && context.getSharedPreferences(SETTINGS,Context.MODE_PRIVATE)
            .getBoolean(VOICE_ENABLED,false);
    }
    private static String readLimited(InputStream stream,int max) throws Exception {
        if(stream==null)throw new IllegalStateException("empty API response");
        try(InputStream in=stream){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
            byte[] chunk=new byte[4096];int n;while((n=in.read(chunk))!=-1){
                if(out.size()+n>max)throw new IllegalStateException("API response too large");
                out.write(chunk,0,n);
            }
            return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }
    }
    private static JSONObject receive(HttpURLConnection conn) throws Exception {
        int status=conn.getResponseCode();
        // Never include raw provider error bodies; they can accidentally echo credentials or user text.
        if(status<200||status>=300)throw new IllegalStateException("Cloud AI HTTP "+status);
        return new JSONObject(readLimited(conn.getInputStream(),60000));
    }
    public static String answer(Context context,String query) throws Exception {
        if(!canChat(context))throw new IllegalStateException("Cloud AI disabled");
        if(query==null || query.trim().length()==0 || query.length()>1000)
            throw new IllegalArgumentException("invalid question size");
        String secret=JavidAiSecrets.read(context);
        HttpURLConnection conn=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        try {
            conn.setRequestMethod("POST");conn.setConnectTimeout(12000);conn.setReadTimeout(45000);
            conn.setDoOutput(true);conn.setRequestProperty("Authorization","Bearer "+secret);
            conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            JSONObject request=new JSONObject().put("model","gpt-4.1-mini")
                .put("store",false).put("max_output_tokens",400)
                .put("instructions","You are Javid AI, an assistant within a Telegram bot. Reply concisely in the user's language. Do not claim to access live bot state, private files, tools, Telegram accounts or download history. You have no ability to execute actions. Never request secrets, API keys, or passwords. For app operations ask users to use explicit bot commands. Do not output executable commands to control the bot.")
                .put("input",query.trim());
            byte[] bytes=request.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
            JSONObject result=receive(conn);
            JSONArray outputs=result.optJSONArray("output");
            if(outputs==null)throw new IllegalStateException("response unavailable");
            StringBuilder response=new StringBuilder();
            for(int i=0;i<outputs.length();i++){
                JSONObject item=outputs.optJSONObject(i);if(item==null)continue;
                JSONArray pieces=item.optJSONArray("content");if(pieces==null)continue;
                for(int j=0;j<pieces.length();j++){
                    JSONObject part=pieces.optJSONObject(j);
                    if(part!=null && "output_text".equals(part.optString("type"))) {
                        if(response.length()>0)response.append("\n");
                        response.append(part.optString("text",""));
                    }
                }
            }
            String answer=response.toString().trim();
            if(answer.isEmpty())throw new IllegalStateException("response empty");
            return answer.length()>3500?answer.substring(0,3500):answer;
        } finally{conn.disconnect();}
    }
    public static String transcribe(Context context, File voice) throws Exception {
        if(!canVoice(context))throw new IllegalStateException("Voice transcription disabled");
        if(voice==null || voice.length()==0 || voice.length()>MAX_VOICE_BYTES)
            throw new IllegalArgumentException("voice size unsupported");
        String secret=JavidAiSecrets.read(context);
        String boundary="JavidVoice"+UUID.randomUUID().toString().replace("-","");
        HttpURLConnection conn=(HttpURLConnection)new URL("https://api.openai.com/v1/audio/transcriptions").openConnection();
        try{
            conn.setRequestMethod("POST");conn.setDoOutput(true);
            conn.setConnectTimeout(12000);conn.setReadTimeout(50000);
            conn.setRequestProperty("Authorization","Bearer "+secret);
            conn.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            conn.setChunkedStreamingMode(32*1024);
            try(OutputStream out=conn.getOutputStream()){
                byte[] model=("--"+boundary+"\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\ngpt-4o-mini-transcribe\r\n")
                    .getBytes(StandardCharsets.UTF_8);
                out.write(model);
                out.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\"telegram-voice.ogg\"\r\nContent-Type: audio/ogg\r\n\r\n")
                    .getBytes(StandardCharsets.UTF_8));
                try(FileInputStream stream=new FileInputStream(voice)){
                    byte[] chunk=new byte[8192];int n;
                    while((n=stream.read(chunk))!=-1)out.write(chunk,0,n);
                }
                out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
            }
            String result=receive(conn).optString("text","").trim();
            if(result.isEmpty())throw new IllegalStateException("empty transcription");
            return result.length()>900?result.substring(0,900):result;
        }finally{conn.disconnect();}
    }
}

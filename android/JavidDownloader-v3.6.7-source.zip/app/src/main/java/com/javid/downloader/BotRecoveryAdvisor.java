package com.javid.downloader;

/**
 * Offline, deterministic recovery policy. No credentials, network I/O,
 * user data, or model API involved. Separate from Android for JVM tests.
 */
final class BotRecoveryAdvisor {
    enum Problem { HEALTHY, OFF_BY_OWNER, TOKEN_MISSING, TOKEN_REJECTED, POLLER_CONFLICT, NETWORK, STALE_SERVICE }
    private BotRecoveryAdvisor() { }

    static Problem assess(boolean desired, boolean tokenPresent, String error,
                          long heartbeatMs, long nowMs, boolean hasNetwork) {
        if (!desired) return Problem.OFF_BY_OWNER;
        if (!tokenPresent) return Problem.TOKEN_MISSING;
        if ("401".equals(error)) return Problem.TOKEN_REJECTED;
        if ("409".equals(error)) return Problem.POLLER_CONFLICT;
        if (!hasNetwork) return Problem.NETWORK;
        if (heartbeatMs <= 0L || nowMs < heartbeatMs || nowMs-heartbeatMs>120_000L)
            return Problem.STALE_SERVICE;
        return Problem.HEALTHY;
    }

    static boolean canRequestSafeResume(Problem problem, long lastAttemptMs, long nowMs) {
        return problem == Problem.STALE_SERVICE && nowMs > 0L &&
            (lastAttemptMs <= 0L || nowMs < lastAttemptMs || nowMs-lastAttemptMs >= 180_000L);
    }

    static long backoffMillis(String category, int failures) {
        if ("401".equals(category)) return 600_000L; // Do not hammer revoked tokens.
        if ("409".equals(category)) return 180_000L; // Never delete webhook automatically.
        int power = Math.min(5, Math.max(0, failures-1));
        return Math.min(90_000L, 3_000L << power);
    }

    static String explanation(Problem p) {
        switch (p) {
            case OFF_BY_OWNER: return "بات به انتخاب مالک خاموش است؛ هیچ بازیابی خودکاری انجام نمی‌شود.";
            case TOKEN_MISSING: return "توکن ثبت نشده است؛ فقط مالک باید آن را در تنظیمات ثبت کند.";
            case TOKEN_REJECTED: return "تلگرام توکن را نپذیرفته است (401)؛ توکن را بررسی کن. تلاش‌های مجدد محدود می‌شوند.";
            case POLLER_CONFLICT: return "خطای 409: احتمال اجرای بات در جای دیگر. از بخش Webhook بررسی کن؛ تنظیمات سرور خودکار تغییر نمی‌کند.";
            case NETWORK: return "اینترنت این گوشی در دسترس یا تأییدشده نیست؛ بعد از اتصال مجدد سرویس دوباره تلاش می‌کند.";
            case STALE_SERVICE: return "ضربان سرویس قدیمی است؛ درخواست بازیابی با تأیید مالک و محدودیت زمانی مجاز است.";
            default: return "ضربان سرویس تازه است. برای اطمینان از ارتباط واقعی، تست تلگرام را دستی اجرا کن.";
        }
    }
}

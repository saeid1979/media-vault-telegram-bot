package com.javid.downloader;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Persistent, synchronized queue. Independent from the existing yt-dlp Telegram/download workflow. */
public final class DownloadQueueStore {
    public static final String QUEUED="queued", RUNNING="running", PAUSED="paused", DONE="done", FAILED="failed", CANCELLED="cancelled";
    private static final String PREFS="javid_http_queue_v3", KEY="items";
    private static final Object MUTEX=new Object();
    private DownloadQueueStore() {}

    public static final class Item {
        public String id,url,name,state=QUEUED,reason="",uri="",etag="";
        public long bytes=0,total=-1,addedAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis(),retryAt=0;
        public int priority=1,retries=0;
        public double bytesPerSec=0;
        JSONObject toJson() throws Exception {
            JSONObject o=new JSONObject();
            o.put("id",id);o.put("url",url);o.put("name",name);o.put("state",state);o.put("reason",reason);
            o.put("uri",uri);o.put("etag",etag);o.put("bytes",bytes);o.put("total",total);
            o.put("addedAt",addedAt);o.put("updatedAt",updatedAt);o.put("retryAt",retryAt);
            o.put("priority",priority);o.put("retries",retries);o.put("speed",bytesPerSec);return o;
        }
        static Item fromJson(JSONObject o){
            Item i=new Item(); i.id=o.optString("id","");i.url=o.optString("url","");i.name=o.optString("name","download.bin");
            i.state=o.optString("state",QUEUED);i.reason=o.optString("reason","");i.uri=o.optString("uri","");i.etag=o.optString("etag","");
            i.bytes=o.optLong("bytes",0);i.total=o.optLong("total",-1);
            i.addedAt=o.optLong("addedAt",System.currentTimeMillis());i.updatedAt=o.optLong("updatedAt",i.addedAt);
            i.retryAt=o.optLong("retryAt",0);i.priority=o.optInt("priority",1);i.retries=o.optInt("retries",0);
            i.bytesPerSec=o.optDouble("speed",0);return i;
        }
    }
    private static SharedPreferences prefs(Context ctx){return ctx.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private static ArrayList<Item> load(Context ctx){
        ArrayList<Item> all=new ArrayList<>();
        try {JSONArray a=new JSONArray(prefs(ctx).getString(KEY,"[]"));
            for(int k=0;k<a.length();k++){JSONObject o=a.optJSONObject(k);if(o!=null){Item i=Item.fromJson(o);if(!i.id.isEmpty())all.add(i);}}
        }catch(Exception ignored){} return all;
    }
    private static void save(Context ctx,List<Item> all){
        JSONArray a=new JSONArray();try{for(Item i:all)a.put(i.toJson());}catch(Exception ignored){}
        // Commit rather than apply so process termination does not discard a queue change.
        prefs(ctx).edit().putString(KEY,a.toString()).commit();
    }
    public static List<Item> snapshot(Context ctx){synchronized(MUTEX){return new ArrayList<>(load(ctx));}}
    public static Item get(Context ctx,String id){synchronized(MUTEX){for(Item i:load(ctx))if(i.id.equals(id))return i;return null;}}
    public static String add(Context ctx,String link,String proposedName,boolean priority){
        synchronized(MUTEX){
            try {
                URL url=new URL(link.trim());
                if(!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost()==null || url.getHost().isEmpty() || url.getUserInfo()!=null)
                    throw new IllegalArgumentException("فقط لینک مستقیم HTTPS بدون نام کاربری مجاز است.");
                if(link.length()>4096)throw new IllegalArgumentException("لینک بیش‌ازحد طولانی است.");
            }catch(IllegalArgumentException e){throw e;}catch(Exception e){throw new IllegalArgumentException("آدرس HTTPS معتبر نیست.");}
            String name=safeName(proposedName);
            if(name.isEmpty()) {try {String path=new URL(link.trim()).getPath(); name=safeName(path.substring(path.lastIndexOf('/')+1));}catch(Exception ignored){}}
            if(name.isEmpty())name="Javid-"+System.currentTimeMillis()+".bin";
            ArrayList<Item> all=load(ctx);
            for(Item i:all){if(i.url.equals(link.trim()) && !CANCELLED.equals(i.state) && !FAILED.equals(i.state))return i.id;}
            Item i=new Item();i.id=UUID.randomUUID().toString();i.url=link.trim();i.name=name;i.priority=priority?2:1;all.add(i);save(ctx,all);return i.id;
        }
    }
    public static String safeName(String name){
        if(name==null)return "";
        String s=name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").replace("..","_").trim();
        while(s.startsWith("."))s=s.substring(1);
        return s.length()>110?s.substring(s.length()-110):s;
    }
    public static void mutate(Context ctx,String id,java.util.function.Consumer<Item> change){
        synchronized(MUTEX){ArrayList<Item> all=load(ctx);boolean hit=false;
            for(Item i:all)if(i.id.equals(id)){change.accept(i);i.updatedAt=System.currentTimeMillis();hit=true;break;}
            if(hit)save(ctx,all);
        }
    }
    public static void reconcileInterrupted(Context ctx){synchronized(MUTEX){ArrayList<Item> all=load(ctx);boolean updated=false;
        for(Item i:all)if(RUNNING.equals(i.state)){i.state=QUEUED;i.reason="ادامه پس از بسته‌شدن سرویس";i.bytesPerSec=0;updated=true;}
        if(updated)save(ctx,all);
    }}
    public static List<Item> runnable(Context ctx,int maximum){synchronized(MUTEX){
        ArrayList<Item> all=load(ctx), ready=new ArrayList<>();long now=System.currentTimeMillis();
        for(Item i:all)if(QUEUED.equals(i.state)&&i.retryAt<=now)ready.add(i);
        Collections.sort(ready,Comparator.comparingInt((Item x)->-x.priority).thenComparingLong(x->x.addedAt));
        return new ArrayList<>(ready.subList(0,Math.min(maximum,ready.size())));
    }}
    public static File partFile(Context ctx,String id){
        File folder=new File(ctx.getFilesDir(),"http_download_parts");if(!folder.exists())folder.mkdirs();
        return new File(folder,id+".part");
    }
    public static void deletePart(Context ctx,String id){File f=partFile(ctx,id);if(f.exists())f.delete();}
    public static void control(Context ctx,String id,String action){
        mutate(ctx,id,i->{
            if("pause".equals(action) && (QUEUED.equals(i.state)||RUNNING.equals(i.state))){i.state=PAUSED;i.reason="توسط کاربر متوقف شد";i.bytesPerSec=0;}
            if("resume".equals(action) && (PAUSED.equals(i.state)||FAILED.equals(i.state))){i.state=QUEUED;i.reason="";i.retryAt=0;i.retries=0;}
            if("cancel".equals(action) && !DONE.equals(i.state)){i.state=CANCELLED;i.reason="لغو شد";i.bytesPerSec=0;}
            if("priority".equals(action) && (QUEUED.equals(i.state)||PAUSED.equals(i.state)))i.priority=(i.priority==2)?1:2;
        });
        if("cancel".equals(action))deletePart(ctx,id);
    }
}

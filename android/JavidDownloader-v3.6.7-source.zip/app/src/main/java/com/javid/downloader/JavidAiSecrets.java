package com.javid.downloader;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Locally encrypted BYOK cloud-AI credential; never committed or sent to Telegram. */
public final class JavidAiSecrets {
    private JavidAiSecrets() { }
    private static final String ALIAS = "javid_cloud_ai_aes_v1";
    private static final String PREFS = "javid_cloud_ai_credential";
    private static final String FIELD = "encrypted_key";
    private static SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return generator.generateKey();
    }
    public static void save(Context context,String plain) throws Exception {
        if(plain==null || plain.trim().length()<12 || plain.length()>300 || plain.contains("\n"))
            throw new IllegalArgumentException("API key invalid");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] body=cipher.doFinal(plain.trim().getBytes(StandardCharsets.UTF_8));
        byte[] iv=cipher.getIV();byte[] combined=new byte[iv.length+body.length];
        System.arraycopy(iv,0,combined,0,iv.length);System.arraycopy(body,0,combined,iv.length,body.length);
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
            .putString(FIELD,Base64.encodeToString(combined,Base64.NO_WRAP)).apply();
    }
    public static String read(Context context) throws Exception {
        String encoded=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(FIELD,"");
        if(encoded.isEmpty())return "";
        byte[] combined=Base64.decode(encoded,Base64.NO_WRAP);
        if(combined.length<29)throw new IllegalStateException("credential invalid");
        byte[] iv=new byte[12],body=new byte[combined.length-12];
        System.arraycopy(combined,0,iv,0,12);System.arraycopy(combined,12,body,0,body.length);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
        return new String(cipher.doFinal(body),StandardCharsets.UTF_8);
    }
    public static boolean configured(Context context) {
        return !context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(FIELD,"").isEmpty();
    }
    public static void clear(Context context) {
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().remove(FIELD).apply();
    }
}

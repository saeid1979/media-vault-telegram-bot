package com.javid.downloader;

/** Pure Java precipitation threshold policy, separately testable from Android. */
final class RainProbabilityPolicy {
    static final int THRESHOLD = 50;                 // STRICTLY GREATER than 50%
    static final long HORIZON_SECONDS = 24L * 3600L;

    static final class Event {
        final long startEpochSeconds;
        final long endEpochSeconds;
        final int peakProbability;
        Event(long start, long end, int peak) {
            startEpochSeconds=start; endEpochSeconds=end; peakProbability=peak;
        }
    }

    /** Earliest contiguous high-probability period within the next 24 hours. */
    static Event firstEvent(long nowSeconds, long[] hours, double[] chances) {
        if (hours == null || chances == null) return null;
        int length = Math.min(hours.length, chances.length);
        long start = -1, end = -1;
        int peak = 0;
        for (int i = 0; i < length; i++) {
            long hour = hours[i];
            double chance = chances[i];
            if (hour + 3600 <= nowSeconds) continue;
            if (hour >= nowSeconds + HORIZON_SECONDS) break;
            boolean high = Double.isFinite(chance) && chance > THRESHOLD;
            if (high) {
                if (start < 0) {
                    start = hour;
                    end = hour + 3600;
                    peak = (int)Math.round(chance);
                } else if (hour == end) {
                    end = hour + 3600;
                    peak = Math.max(peak, (int)Math.round(chance));
                } else {
                    return new Event(start, end, peak);
                }
            } else if (start >= 0) {
                return new Event(start, end, peak);
            }
        }
        return start >= 0 ? new Event(start, end, peak) : null;
    }
}

package com.javid.downloader;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/** Single 23:00 daily football digest in the phone's local timezone, DST-safe. */
final class FootballNotificationPolicy {
    private FootballNotificationPolicy() {}
    static final int DAILY_HOUR = 23;

    static String dayKey(long atMillis, ZoneId zone) {
        return Instant.ofEpochMilli(atMillis).atZone(zone).toLocalDate().toString();
    }
    static boolean shouldSendDaily(long atMillis, ZoneId zone, String lastSentDay) {
        ZonedDateTime at=Instant.ofEpochMilli(atMillis).atZone(zone);
        return at.getHour()==DAILY_HOUR && !at.toLocalDate().toString().equals(lastSentDay);
    }
    static boolean playedToday(long kickoffMillis, boolean live, long atMillis, ZoneId zone) {
        if(live) return true;
        if(kickoffMillis<=0)return false;
        LocalDate today=Instant.ofEpochMilli(atMillis).atZone(zone).toLocalDate();
        return today.equals(Instant.ofEpochMilli(kickoffMillis).atZone(zone).toLocalDate());
    }

    /** Classify only real match incidents, excluding offside and VAR-disallowed goals. */
    static String incidentKind(String rawType,String rawClass,String cardColor,boolean cancelled) {
        if(cancelled)return "";
        String type=norm(rawType), detail=norm(rawClass), card=norm(cardColor);
        if(type.contains("offside")||type.contains("var")||type.contains("disallow")||
            detail.contains("cancel")||detail.contains("disallow")||detail.contains("overturn"))return "";
        if(type.contains("card")||type.equals("booking")) {
            String color=card+" "+detail+" "+type;
            if(color.contains("red")||color.contains("secondyellow")||color.contains("yellowred")) return "RED";
            if(color.contains("yellow"))return "YELLOW";
        }
        if(type.equals("goal")||type.equals("owngoal")||type.equals("penaltygoal"))return "GOAL";
        return "";
    }
    private static String norm(String s) {
        return s==null?"":s.toLowerCase(java.util.Locale.ROOT)
            .replace("-","").replace("_","").replace(" ","");
    }
}

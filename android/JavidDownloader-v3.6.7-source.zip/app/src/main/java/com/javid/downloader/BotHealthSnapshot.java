package com.javid.downloader;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** On-device, owner-initiated diagnostics; never reads or logs Telegram tokens. */
final class BotHealthSnapshot {
    private BotHealthSnapshot() { }

    private static String localTime(long epochMs) {
        if (epochMs <= 0L) return "ثبت نشده";
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.US)
            .format(new Date(epochMs));
    }

    private static String connection(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "نامشخص";
            Network active = cm.getActiveNetwork();
            if (active == null) return "قطع";
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(active);
            if (capabilities == null) return "نامشخص";
            if (!capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                return "شبکه بدون قابلیت اینترنت";
            return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                ? "متصل و تأییدشده" : "متصل؛ دسترسی اینترنت تأیید نشده";
        } catch (Exception unavailable) { return "نامشخص"; }
    }

    private static String telegramStatus(String code) {
        if ("409".equals(code)) return "ربات در جای دیگری نیز اجرا می‌شود (409)";
        if ("401".equals(code)) return "توکن تلگرام پذیرفته نشد (401)";
        if ("network".equals(code)) return "شبکه یا سرور موقتاً در دسترس نبود";
        return "مشکلی ثبت نشده";
    }

    static String report(Context context) {
        SharedPreferences p = context.getSharedPreferences(
            TelegramBotService.PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        long heartbeat = p.getLong("service_heartbeat", 0L);
        boolean desired = p.getBoolean(TelegramBotService.PREF_DESIRED, false);
        boolean recent = heartbeat > 0L && now >= heartbeat &&
            now - heartbeat < TimeUnit.SECONDS.toMillis(90);
        String state = !desired ? "خاموش به انتخاب مالک" :
            recent ? "سرویس فعال؛ آخرین ضربان ثبت شده" :
            "شروع درخواستی است؛ ضربان سرویس قدیمی یا موجود نیست";
        StringBuilder out = new StringBuilder(300);
        out.append("Javid Downloader 3.4.0 | عیب‌یابی محلی\n")
           .append("بات: ").append(state).append('\n')
           .append("شبکه: ").append(connection(context)).append('\n')
           .append("راه‌اندازی خودکار: ")
           .append(p.getBoolean(TelegramBotService.PREF_AUTO_RESUME, true)
               ? "فعال" : "غیرفعال").append('\n')
           .append("آخرین ضربان سرویس: ").append(localTime(heartbeat)).append('\n')
           .append("آخرین پاسخ موفق تلگرام: ")
           .append(localTime(p.getLong("last_telegram_poll_ok", 0L))).append('\n')
           .append("خطاهای متوالی تلگرام: ")
           .append(p.getInt("telegram_consecutive_failures", 0)).append('\n')
           .append("نوع آخرین مشکل: ")
           .append(telegramStatus(p.getString("telegram_error_category", ""))).append('\n')
           .append("اعلان‌های فوتبال: ")
           .append(p.getBoolean(HourlyDigestPublisher.ENABLED, false)
               ? "فعال" : "غیرفعال").append('\n')
           .append("آخرین بررسی فوتبال: ")
           .append(localTime(p.getLong(FootballLiveTracker.LAST_CHECK, 0L)))
           .append('\n');
        try (AlertDeliveryOutbox queue = new AlertDeliveryOutbox(context)) {
            AlertDeliveryOutbox.QueueStats stats = queue.stats();
            out.append("اعلان‌های معوق: ").append(stats.pending).append('\n');
            if (stats.pending > 0)
                out.append("قدیمی‌ترین اعلان معوق: ")
                    .append(localTime(stats.oldestMs)).append('\n');
        } catch (Exception error) {
            out.append("صف اعلان‌ها: در حال حاضر قابل خواندن نیست\n");
        }
        String resumeProblem = p.getString("auto_resume_issue", "");
        if (!resumeProblem.isEmpty()) out.append("اجرا در پس‌زمینه: محدود شده\n");
        out.append("این گزارش فاقد توکن، شناسه کاربر و محتوای پیام‌هاست.");
        return out.toString();
    }
}

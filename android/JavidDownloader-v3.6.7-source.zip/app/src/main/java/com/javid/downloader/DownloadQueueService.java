package com.javid.downloader;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** User-initiated foreground transfer service; two simultaneous, resumable HTTPS direct-file downloads. */
public final class DownloadQueueService extends Service {
    public static final String ACTION_START="com.javid.downloader.HTTP_QUEUE_START";
    public static final String ACTION_WAKE="com.javid.downloader.HTTP_QUEUE_WAKE";
    public static final String ACTION_STOP="com.javid.downloader.HTTP_QUEUE_STOP";
    private static final String CHANNEL="javid_http_queue_v3"; private static final int NOTIFY_ID=4630;
    private final ExecutorService pool=Executors.newFixedThreadPool(2);
    private final Set<String> active=new HashSet<>();
    private final android.os.Handler timer=new android.os.Handler(android.os.Looper.getMainLooper());
    private volatile boolean closing=false;
    private boolean started=false;
    private final Runnable tick=new Runnable(){@Override public void run(){if(closing)return; schedule();timer.postDelayed(this,2000);}};

    @Override public void onCreate(){super.onCreate();DownloadQueueStore.reconcileInterrupted(this);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"مدیر دانلود جاوید",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(ACTION_STOP.equals(intent==null?null:intent.getAction())){closing=true;timer.removeCallbacks(tick);stopSelf();return START_NOT_STICKY;}
        if(!started){started=true;startForeground(NOTIFY_ID,notification("مدیریت صف دانلود در حال اجراست"));timer.post(tick);}
        else schedule();
        return START_NOT_STICKY;
    }
    private Notification notification(String message){
        Intent open=new Intent(this,DownloadQueueActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=new Notification.Builder(this,CHANNEL).setContentTitle("Javid Downloader • صف دانلود")
            .setContentText(message).setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setContentIntent(pi);
        return b.build();
    }
    private boolean connected(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null)return false;
        NetworkInfo info=cm.getActiveNetworkInfo();return info!=null && info.isConnected();
    }
    private synchronized void schedule(){
        if(closing)return;
        List<DownloadQueueStore.Item> items=DownloadQueueStore.snapshot(this);
        boolean hasQueued=false;for(DownloadQueueStore.Item i:items)if(DownloadQueueStore.QUEUED.equals(i.state))hasQueued=true;
        if(!connected()){
            if(hasQueued || !active.isEmpty())getSystemService(NotificationManager.class).notify(NOTIFY_ID,notification("اینترنت قطع است؛ اتصال را دوباره بررسی می‌کنیم"));
            // Keep service running only while a user-requested queue exists. Android 15 has a limited dataSync budget.
            if(active.isEmpty()&&!hasQueued)finish();return;
        }
        int spaces=2-active.size();
        if(spaces>0){
            for(DownloadQueueStore.Item task:DownloadQueueStore.runnable(this,spaces)){
                if(active.contains(task.id))continue;
                active.add(task.id);DownloadQueueStore.mutate(this,task.id,i->{i.state=DownloadQueueStore.RUNNING;i.reason="";});
                pool.execute(()->download(task.id));
            }
        }
        if(active.isEmpty()&&!hasQueued)finish();
        else getSystemService(NotificationManager.class).notify(NOTIFY_ID,notification("فعال: "+active.size()+" • در صف: "+Math.max(0,DownloadQueueStore.runnable(this,1000).size())));
    }
    private synchronized void finish(){if(!closing){closing=true;timer.removeCallbacks(tick);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}}
    private boolean mustStop(String id){DownloadQueueStore.Item x=DownloadQueueStore.get(this,id);
        return closing || x==null || !DownloadQueueStore.RUNNING.equals(x.state);
    }
    private void download(String id){
        try{transfer(id);}catch(StoppedException ignored){}
        catch(Exception e){
            DownloadQueueStore.Item before=DownloadQueueStore.get(this,id);
            if(before!=null && DownloadQueueStore.RUNNING.equals(before.state)){
                final String reason=safeError(e);final int n=before.retries+1;
                DownloadQueueStore.mutate(this,id,i->{i.retries=n;i.bytesPerSec=0;i.reason=reason;
                    if(n<=3){i.state=DownloadQueueStore.QUEUED;i.retryAt=System.currentTimeMillis()+Math.min(60000L,5000L*(1L<<n));}
                    else{i.state=DownloadQueueStore.FAILED;i.retryAt=0;}
                });
            }
        }finally{ synchronized(this){active.remove(id);}timer.post(this::schedule);}
    }
    private static class StoppedException extends Exception{}
    private static String safeError(Exception e){String m=e.getMessage();if(m==null||m.isEmpty())return "خطای دریافت فایل";
        if(m.length()>140)m=m.substring(0,140);return m.replaceAll("https?://\\S+","[link]");
    }
    private void transfer(String id) throws Exception{
        DownloadQueueStore.Item item=DownloadQueueStore.get(this,id);if(item==null || mustStop(id))throw new StoppedException();
        File part=DownloadQueueStore.partFile(this,id);
        long current=part.exists()?part.length():0;
        if(current==0 && item.bytes!=0)DownloadQueueStore.mutate(this,id,i->{i.bytes=0;i.etag="";});
        HttpURLConnection conn=null;long total=-1;
        try{
            URL url=new URL(item.url);
            if(!"https".equalsIgnoreCase(url.getProtocol()))throw new Exception("فقط HTTPS پشتیبانی می‌شود");
            conn=(HttpURLConnection)url.openConnection();conn.setConnectTimeout(18000);conn.setReadTimeout(25000);
            conn.setInstanceFollowRedirects(true);conn.setRequestProperty("Accept-Encoding","identity");
            conn.setRequestProperty("User-Agent","JavidDownloader/3.1 Android");
            if(current>0){conn.setRequestProperty("Range","bytes="+current+"-");if(!item.etag.isEmpty())conn.setRequestProperty("If-Range",item.etag);}
            int code=conn.getResponseCode();
            if(code==416 && current>0){conn.disconnect();part.delete();DownloadQueueStore.mutate(this,id,i->{i.bytes=0;i.etag="";});throw new Exception("سرور درخواست ادامه را رد کرد؛ دریافت از ابتدا تلاش می‌شود");}
            if(code!=200&&code!=206)throw new Exception("خطای سرور: HTTP "+code);
            String contentType=conn.getContentType();
            if(contentType!=null && contentType.toLowerCase(java.util.Locale.ROOT).startsWith("text/html"))throw new Exception("این آدرس صفحه وب است، نه لینک مستقیم فایل");
            boolean resumed=code==206&&current>0;
            if(resumed){
                String range=conn.getHeaderField("Content-Range");
                if(range==null || !range.startsWith("bytes "+current+"-"))throw new Exception("محدوده ادامه دانلود معتبر نیست");
            } else current=0;
            final long startBytes=current;
            long contentLength=conn.getContentLengthLong();
            total=contentLength>=0?contentLength+startBytes:-1;
            final long storedTotal=total;
            final String etag=conn.getHeaderField("ETag")==null?"":conn.getHeaderField("ETag");
            DownloadQueueStore.mutate(this,id,i->{i.bytes=startBytes;i.total=storedTotal;i.etag=etag;});
            try(InputStream in=conn.getInputStream();RandomAccessFile out=new RandomAccessFile(part,"rw")){
                if(startBytes==0)out.setLength(0);out.seek(startBytes);
                byte[] buffer=new byte[65536];long bytes=startBytes,lastSaved=System.currentTimeMillis(),sampleStart=lastSaved,sampleBytes=bytes;
                int count;while((count=in.read(buffer))!=-1){
                    if(mustStop(id))throw new StoppedException();
                    out.write(buffer,0,count);bytes+=count;
                    long now=System.currentTimeMillis();
                    if(now-lastSaved>1400){
                        long position=bytes;double rate=(bytes-sampleBytes)*1000.0/Math.max(1,now-sampleStart);
                        DownloadQueueStore.mutate(this,id,i->{i.bytes=position;i.bytesPerSec=Math.max(0,rate);});
                        lastSaved=now;sampleStart=now;sampleBytes=bytes;
                    }
                }
                final long completeBytes=bytes;
                DownloadQueueStore.mutate(this,id,i->{i.bytes=completeBytes;i.bytesPerSec=0;});
                if(total>=0 && bytes!=total)throw new Exception("حجم فایل کامل دریافت نشده است");
            }
            if(mustStop(id))throw new StoppedException();
            Uri published=publish(part,item.name);
            DownloadQueueStore.mutate(this,id,i->{i.state=DownloadQueueStore.DONE;i.uri=published.toString();i.reason="";i.bytesPerSec=0;i.retryAt=0;});
            part.delete();
        }finally{if(conn!=null)conn.disconnect();}
    }
    private Uri publish(File part,String name) throws Exception{
        String extension=android.webkit.MimeTypeMap.getFileExtensionFromUrl(name);
        if(extension==null||extension.isEmpty()){int x=name.lastIndexOf('.');extension=x==-1?"":name.substring(x+1).toLowerCase(java.util.Locale.ROOT);}
        String mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);if(mime==null)mime="application/octet-stream";
        ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,DownloadQueueStore.safeName(name));
        values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/JavidDownloader");
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri result=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
        if(result==null)throw new Exception("فضای ذخیره‌سازی قابل استفاده نیست");
        try(OutputStream out=getContentResolver().openOutputStream(result);FileInputStream in=new FileInputStream(part)){
            if(out==null)throw new Exception("نوشتن فایل ممکن نبود");
            byte[] buf=new byte[65536];int n;while((n=in.read(buf))>=0){out.write(buf,0,n);}out.flush();
            ContentValues done=new ContentValues();done.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(result,done,null,null);return result;
        }catch(Exception e){getContentResolver().delete(result,null,null);throw e;}
    }
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onDestroy(){closing=true;timer.removeCallbacks(tick);pool.shutdownNow();super.onDestroy();}
}

package com.javid.downloader;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Opt-in, per-chat hourly forecast notifications, independent of football digest. */
final class RainProbabilityAlerts {
    static final String PREFIX="rain50_sub_";
    private static final String SENT_PREFIX="rain50_sent_";
    private static final String EVENT_PREFIX="rain50_event_";
    static final long MIN_GAP_MS=6L*60L*60L*1000L;
    private final SharedPreferences prefs;
    private final WeatherCityStore cities;

    RainProbabilityAlerts(SharedPreferences prefs, WeatherCityStore cities) {
        this.prefs=prefs; this.cities=cities;
    }

    static String cityId(String entered) {
        if (entered == null) return null;
        String name = entered.trim().toLowerCase(Locale.ROOT);
        if(name.isEmpty())return null;
        for (WeatherCityStore.City city:WeatherCityStore.PRESETS) {
            if(city.id.equals(name) || city.name.toLowerCase(Locale.ROOT).equals(name) ||
                city.name.toLowerCase(Locale.ROOT).startsWith(name+"،") ||
                city.name.toLowerCase(Locale.ROOT).startsWith(name+",")) return city.id;
        }
        return null;
    }

    private static String key(long user) { return PREFIX+user; }

    synchronized Set<String> subscribed(long user) {
        String raw=prefs.getString(key(user),"");
        Set<String> result=new LinkedHashSet<>();
        for (String id:raw.split(",")) {
            if (!id.isEmpty() && cities.get(id)!=null) result.add(id);
        }
        return result;
    }

    synchronized void enable(long user, String city) {
        Set<String> old=subscribed(user);
        old.add(city);
        save(user,old);
    }
    synchronized void enableDefaults(long user) {
        Set<String> old=subscribed(user);
        old.addAll(Arrays.asList("salamanca","madrid","tehran","ardabil"));
        save(user,old);
    }
    synchronized void disable(long user, String city) {
        Set<String> old=subscribed(user);
        if (city==null) old.clear();
        else old.remove(city);
        save(user,old);
    }
    private void save(long user,Set<String> cityIds) {
        String value=String.join(",",cityIds);
        prefs.edit().putString(key(user),value).apply();
    }

    synchronized Map<String,List<Long>> destinations() {
        Map<String,List<Long>> out=new HashMap<>();
        for (String item:prefs.getAll().keySet()) {
            if (!item.startsWith(PREFIX))continue;
            try {
                long user=Long.parseLong(item.substring(PREFIX.length()));
                for (String id:subscribed(user)) {
                    out.computeIfAbsent(id,ignored->new ArrayList<>()).add(user);
                }
            }catch(NumberFormatException ignored) { /* Ignore corrupted local keys */ }
        }
        return out;
    }

    RainProbabilityPolicy.Event fetch(WeatherCityStore.City city) throws Exception {
        String endpoint="https://api.open-meteo.com/v1/forecast?latitude="+
            URLEncoder.encode(city.lat,"UTF-8")+"&longitude="+
            URLEncoder.encode(city.lon,"UTF-8")+
            "&hourly=precipitation_probability&forecast_hours=26"+
            "&timezone=UTC&timeformat=unixtime";
        JSONObject result=FootballLiveTracker.getJson(endpoint,200_000);
        JSONObject hourly=result.getJSONObject("hourly");
        JSONArray times=hourly.getJSONArray("time");
        JSONArray probabilities=hourly.getJSONArray("precipitation_probability");
        int count=Math.min(times.length(),probabilities.length());
        long[] hours=new long[count];
        double[] chance=new double[count];
        for(int i=0;i<count;i++) {
            hours[i]=times.getLong(i);
            chance[i]=probabilities.isNull(i)?Double.NaN:probabilities.optDouble(i,Double.NaN);
        }
        return RainProbabilityPolicy.firstEvent(
            System.currentTimeMillis()/1000L,hours,chance);
    }

    String message(WeatherCityStore.City city,RainProbabilityPolicy.Event event) {
        ZoneId zone=ZoneId.of(city.zone);
        DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm",Locale.US);
        String from=Instant.ofEpochSecond(event.startEpochSeconds).atZone(zone).format(format);
        String until=Instant.ofEpochSecond(event.endEpochSeconds).atZone(zone).format(format);
        return "🌧️ هشدار احتمال بارندگی بالای ۵۰٪\n"+
            "📍 شهر: "+city.name+"\n"+
            "📊 بیشترین احتمال: "+event.peakProbability+"٪\n"+
            "🕒 زمان پیش‌بینی: "+from+" تا "+until+" (به وقت شهر)\n"+
            "🔎 منبع: Open-Meteo\n"+
            "⚠️ پیش‌بینی احتمالی است، نه هشدار رسمی هواشناسی.";
    }

    synchronized boolean due(long user,String city,RainProbabilityPolicy.Event event) {
        String suffix=user+"_"+city;
        long last=prefs.getLong(SENT_PREFIX+suffix,0);
        if (System.currentTimeMillis()-last < MIN_GAP_MS) return false;
        return prefs.getLong(EVENT_PREFIX+suffix,-1)!=event.startEpochSeconds;
    }
    synchronized void sent(long user,String city,RainProbabilityPolicy.Event event) {
        String suffix=user+"_"+city;
        prefs.edit().putLong(SENT_PREFIX+suffix,System.currentTimeMillis())
            .putLong(EVENT_PREFIX+suffix,event.startEpochSeconds).apply();
    }
}

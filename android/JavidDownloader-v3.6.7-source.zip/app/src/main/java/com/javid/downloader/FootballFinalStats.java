package com.javid.downloader;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;

/** Final whistle facts from the MATCH'S OWN provider, never generated or estimated.
 * Missing statistics are shown as unavailable, not as zeros. Uses no AI or paid keys.
 */
final class FootballFinalStats {
    private FootballFinalStats() { }

    static final class Summary {
        final Map<String,String[]> stats = new LinkedHashMap<>();
        final LinkedHashSet<String> assists = new LinkedHashSet<>();
        String playerOfMatch = "";
        String source = "";
        String status = "";
        void add(String name, String home, String away) {
            String key = statLabel(name);
            if(key == null || key.isEmpty() || stats.containsKey(key)) return;
            String a=FootballFinalReportPolicy.safeValue(home);
            String b=FootballFinalReportPolicy.safeValue(away);
            if(a.equals("—") && b.equals("—"))return;
            stats.put(key,new String[]{a,b});
        }
        void addAssist(String player) {
            if (player==null || player.trim().isEmpty() || assists.size()>=8)return;
            String cleaned=player.replace('\n',' ').replace('\r',' ').trim();
            if(cleaned.length()>55)cleaned=cleaned.substring(0,55);
            if(!cleaned.isEmpty())assists.add(cleaned);
        }
        boolean hasDetails(){return !stats.isEmpty()||!assists.isEmpty()||!playerOfMatch.isEmpty();}
    }
    private static String code(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");}
    /** Separate total chances created from big chances, and do not equate shots with shots on target. */
    private static String statLabel(String key) {
        switch(code(key)) {
            case "ballpossession":case "possession":case "possessionpct":case "possessionpercentage":
                return "⚪ مالکیت توپ";
            case "bigchances":case "bigchance":case "bigchancescreated":
                return "🎯 موقعیت‌های بزرگ گل";
            case "chancescreated":case "keypasses":case "keypass":
                return "🎯 موقعیت گل ساخته‌شده";
            case "totalshots":case "shots":case "shotstotal":case "totalshot":case "totalshotsattempted":
                return "🥅 مجموع شوت‌ها";
            case "shotsontarget":case "shotontarget":case "ontargetscoringattempts":
            case "shotsongoal":case "shotsongoalattempts":case "shotsongoaltotal":
                return "🎯 شوت در چارچوب";
            case "shotsofftarget":case "shotsoffgoal":case "offtargetscoringattempts":
                return "💨 شوت خارج چارچوب";
            case "corners":case "cornerkicks":case "cornerkick":
                return "🚩 کرنر";
            case "fouls":case "foulscommitted":case "totalfouls":
                return "🦶 خطاها";
            case "offsides":case "offside":return ""; // offside is not a requested live alert or report field
            case "yellowcards":case "yellowcard":return "🟨 کارت زرد";
            case "redcards":case "redcard":return "🟥 کارت قرمز";
            case "saves":case "goalkeepersaves":case "goalsaves":return "🧤 مهار دروازه‌بان";
            case "expectedgoals":case "expectedgoalsxg":case "xg":return "📈 گل موردانتظار (xG)";
            case "accuratepasses":case "successfulpasses":return "✅ پاس سالم";
            case "totalpasses":case "passes":return "↔️ مجموع پاس‌ها";
            default:return null;
        }
    }
    private static String get(Object value) {
        if(value==null||value==JSONObject.NULL)return "";
        if(value instanceof JSONObject) {
            JSONObject o=(JSONObject)value;
            for(String k:new String[]{"displayValue","value","current","name"}){
                if(o.has(k))return get(o.opt(k));
            }
            return "";
        }
        return String.valueOf(value);
    }
    private static void parseStatPair(JSONObject row,Summary summary) {
        String key=row.optString("key",row.optString("name",row.optString("title","")));
        Object h=row.opt("home"),a=row.opt("away");
        if(h==null)h=row.opt("homeValue");
        if(a==null)a=row.opt("awayValue");
        JSONArray pair=row.optJSONArray("stats");
        if(pair!=null && pair.length()>=2 && !(pair.opt(0) instanceof JSONObject)){
            h=pair.opt(0);a=pair.opt(1);
        }
        if(summary!=null && h!=null && a!=null)summary.add(key,get(h),get(a));
        // FotMob: category.stats[] -> individual title/stats[] pairs.
        if(pair!=null)for(int i=0;i<pair.length()&&i<70;i++){
            JSONObject item=pair.optJSONObject(i);if(item!=null)parseStatPair(item,summary);
        }
    }
    static Summary fromFotmob(JSONObject json) {
        Summary report=new Summary();report.source="FotMob";
        JSONObject content=json.optJSONObject("content");
        JSONObject stats=content==null?null:content.optJSONObject("stats");
        JSONObject periods=stats==null?null:stats.optJSONObject("Periods");
        JSONObject all=periods==null?null:periods.optJSONObject("All");
        JSONArray rows=all==null?null:all.optJSONArray("stats");
        if(rows!=null)for(int i=0;i<rows.length()&&i<90;i++){
            JSONObject section=rows.optJSONObject(i);if(section!=null)parseStatPair(section,report);
        }
        JSONObject facts=content==null?null:content.optJSONObject("matchFacts");
        if(facts!=null){
            JSONObject motm=facts.optJSONObject("playerOfTheMatch");
            if(motm!=null)report.playerOfMatch=playerName(motm);
            JSONObject events=facts.optJSONObject("events");
            if(events!=null)collectAssists(events.optJSONArray("events"),report);
            if(facts.optJSONArray("events")!=null)collectAssists(facts.optJSONArray("events"),report);
        }
        report.status=report.hasDetails()?"":"جزئیات آماری از منبع دریافت نشد.";
        return report;
    }
    static Summary fromSofascore(JSONObject statsJson,JSONObject incidents,JSONObject best) {
        Summary report=new Summary();report.source="Sofascore";
        JSONArray periods=statsJson==null?null:statsJson.optJSONArray("statistics");
        if(periods!=null)for(int i=0;i<periods.length();i++){
            JSONObject period=periods.optJSONObject(i);
            if(period==null || !"ALL".equalsIgnoreCase(period.optString("period","")))continue;
            JSONArray groups=period.optJSONArray("groups");
            if(groups==null)continue;
            for(int g=0;g<groups.length();g++){
                JSONObject group=groups.optJSONObject(g);if(group==null)continue;
                JSONArray items=group.optJSONArray("statisticsItems");
                if(items==null)continue;
                for(int j=0;j<items.length();j++){
                    JSONObject item=items.optJSONObject(j);if(item!=null)parseStatPair(item,report);
                }
            }
        }
        if(incidents!=null)collectAssists(incidents.optJSONArray("incidents"),report);
        if(best!=null) {
            JSONObject player=best.optJSONObject("playerOfTheMatch");
            if(player!=null)report.playerOfMatch=playerName(player);
        }
        report.status=report.hasDetails()?"":"جزئیات آماری از منبع دریافت نشد.";
        return report;
    }
    static Summary fromEspn(JSONObject json) {
        Summary report=new Summary();report.source="ESPN";
        JSONObject box=json.optJSONObject("boxscore");
        JSONArray teams=box==null?null:box.optJSONArray("teams");
        if(teams!=null) {
            JSONObject home=null,away=null;
            for(int i=0;i<teams.length();i++){
                JSONObject team=teams.optJSONObject(i);if(team==null)continue;
                String side=team.optString("homeAway","");
                if(side.isEmpty()&&team.optJSONObject("team")!=null)
                    side=team.optJSONObject("team").optString("homeAway","");
                if("home".equalsIgnoreCase(side))home=team;
                if("away".equalsIgnoreCase(side))away=team;
            }
            // Some ESPN summaries omit homeAway but keep a home-first pair.
            if(home!=null && away!=null) {
                Map<String,String> homeStats=espnStats(home.optJSONArray("statistics"));
                Map<String,String> awayStats=espnStats(away.optJSONArray("statistics"));
                for(String k:homeStats.keySet())if(awayStats.containsKey(k))
                    report.add(k,homeStats.get(k),awayStats.get(k));
            }
        }
        JSONArray scoring=json.optJSONArray("scoringPlays");
        if(scoring!=null)collectAssists(scoring,report);
        report.status=report.hasDetails()?"":"جزئیات آماری از منبع دریافت نشد.";
        return report;
    }
    private static Map<String,String> espnStats(JSONArray list) {
        Map<String,String> out=new LinkedHashMap<>();
        if(list==null)return out;
        for(int i=0;i<list.length();i++) {
            JSONObject o=list.optJSONObject(i);if(o==null)continue;
            String name=o.optString("name",o.optString("label",o.optString("abbreviation","")));
            String v=get(o.opt("displayValue"));
            if(v.isEmpty())v=get(o.opt("value"));
            if(!name.isEmpty()&&!v.isEmpty())out.put(name,v);
        }
        return out;
    }
    private static String playerName(JSONObject row) {
        if(row==null)return "";
        JSONObject player=row.optJSONObject("player");
        if(player!=null)row=player;
        JSONObject nameObj=row.optJSONObject("name");
        String name=nameObj==null?row.optString("name",""):
            nameObj.optString("fullName",nameObj.optString("name",nameObj.optString("shortName","")));
        if(name.isEmpty())name=row.optString("fullName",row.optString("shortName",""));
        if(name.isEmpty())name=row.optString("playerName","");
        return name.replace('\n',' ').replace('\r',' ').trim();
    }
    private static void collectAssists(JSONArray rows,Summary report) {
        if(rows==null)return;
        for(int i=0;i<rows.length() && i<140;i++) {
            JSONObject event=rows.optJSONObject(i);if(event==null)continue;
            String type=event.optString("incidentType",event.optString("type",event.optString("eventType","")))
                .toLowerCase(Locale.ROOT);
            if(!type.contains("goal")||type.contains("disallow")||event.optBoolean("cancelled",false))continue;
            for(String field:new String[]{"assist1","assist2","assist","assistedBy","assists"}) {
                Object obj=event.opt(field);
                String name="";
                if(obj instanceof JSONObject)name=playerName((JSONObject)obj);
                else if(obj instanceof String)name=(String)obj;
                if(!name.isEmpty() && event.has("isHome"))
                    name+=" ("+(event.optBoolean("isHome")?"میزبان":"میهمان")+")";
                report.addAssist(name);
            }
        }
    }
    /** Fetch detailed final statistics at most once per newly finished match. */
    static Summary fetch(FootballLiveTracker.Match match) {
        if(!match.finished)return new Summary();
        try {
            if(match.id.startsWith("fotmob:")) {
                JSONObject d=FootballLiveTracker.getJson("https://www.fotmob.com/api/data/matchDetails?matchId="+
                    match.id.substring(7),2_800_000);
                return fromFotmob(d);
            }
            if(match.id.startsWith("sofa:")) {
                String id=match.id.substring(5);
                String base="https://www.sofascore.com/api/v1/event/"+id;
                JSONObject stats=null,incidents=null,best=null;
                try{stats=FootballLiveTracker.getJson(base+"/statistics",900_000);}catch(Exception ignored){}
                try{incidents=FootballLiveTracker.getJson(base+"/incidents",300_000);}catch(Exception ignored){}
                try{best=FootballLiveTracker.getJson(base+"/best-players-summary",300_000);}catch(Exception ignored){}
                return fromSofascore(stats,incidents,best);
            }
            if(match.id.startsWith("espn:")) {
                int index=match.id.lastIndexOf(':');
                String league=match.id.substring(5,index);
                String event=match.id.substring(index+1);
                JSONObject d=FootballLiveTracker.getJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+
                    league+"/summary?event="+event,1_800_000);
                return fromEspn(d);
            }
        }catch(Exception unavailable){
            Summary missing=new Summary();missing.source=match.source;
            missing.status="منبع آمار تکمیلی پاسخ نداد.";
            return missing;
        }
        Summary missing=new Summary();missing.source=match.source;
        missing.status="اطلاعات تکمیلی موجود نیست.";
        return missing;
    }
    static String message(FootballLiveTracker.Match match,Summary stats) {
        StringBuilder text=new StringBuilder("🏁 گزارش پایان مسابقه\n");
        text.append(match.league).append("\n").append(match.home).append(" ")
            .append(match.score()).append(" ").append(match.away).append("\n");
        if(match.scorers!=null && !match.scorers.isEmpty())
            text.append("⚽ گلزنان: ").append(match.scorers).append("\n");
        text.append("\n📊 آمار: میزبان | میهمان\n");
        String[] order={"⚪ مالکیت توپ","🎯 موقعیت‌های بزرگ گل","🎯 موقعیت گل ساخته‌شده",
            "🥅 مجموع شوت‌ها","🎯 شوت در چارچوب","💨 شوت خارج چارچوب",
            "🚩 کرنر","↔️ مجموع پاس‌ها","✅ پاس سالم","🦶 خطاها",
            "🟨 کارت زرد","🟥 کارت قرمز","🧤 مهار دروازه‌بان","📈 گل موردانتظار (xG)"};
        for(String key:order) {
            String[] values=stats.stats.get(key);
            // Make unavailable metrics explicit rather than claim they were zero.
            text.append(key).append(": ")
                .append(values==null?"—":values[0]).append(" | ")
                .append(values==null?"—":values[1]).append("\n");
        }
        text.append("\n🅰️ پاس‌گل‌ها: ");
        if(stats.assists.isEmpty())text.append("اطلاعات موجود نیست");
        else {
            int printed=0;
            for(String name:stats.assists){if(printed++>0)text.append("، ");text.append(name);}
        }
        text.append("\n⭐ بهترین بازیکن: ").append(stats.playerOfMatch.isEmpty()?"اعلام نشده":stats.playerOfMatch);
        if(!stats.status.isEmpty())text.append("\n⚠️ ").append(stats.status);
        text.append("\nمنبع: ").append(stats.source.isEmpty()?match.source:stats.source);
        return text.toString();
    }
}

package com.javid.downloader;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.content.SharedPreferences;

/** The key stays encrypted using Android Keystore and never enters APK resources. */
public final class JavidAiSettingsActivity extends Activity {
    private SharedPreferences preferences;
    private Switch chatSwitch,voiceSwitch;
    private TextView status;
    private TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);
        t.setTextSize(size);t.setTextColor(Color.rgb(20,50,66));t.setPadding(6,14,6,14);return t;}
    private Button button(String text,Runnable onClick){Button b=new Button(this);b.setText(text);
        b.setOnClickListener(v->onClick.run());return b;}
    @Override public void onCreate(Bundle state){super.onCreate(state);
        preferences=getSharedPreferences(JavidCloudAiClient.SETTINGS, Context.MODE_PRIVATE);
        ScrollView scroll=new ScrollView(this);LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);content.setPadding(28,28,28,30);
        scroll.addView(content);setContentView(scroll);
        content.addView(label("🧠 تنظیمات اختیاری Javid AI Cloud",22));
        content.addView(label("ارسال متن با /ask و پردازش پیام صوتی تلگرام از سرویس خارجی استفاده می‌کند و ممکن است هزینه API داشته باشد. پیش‌فرض هر دو خاموش است؛ پردازش محلی قبلی فعال می‌ماند. هیچ درخواست مدیریتی به مدل سپرده نمی‌شود.",14));
        status=label("",14);content.addView(status);
        content.addView(button("🔑 ثبت یا تغییر کلید API (فقط روی همین گوشی)",this::showKeyDialog));
        content.addView(button("🗑 حذف کلید API ذخیره‌شده",()->new AlertDialog.Builder(this)
            .setTitle("حذف کلید").setMessage("کلید ذخیره‌شده روی این گوشی پاک شود؟")
            .setNegativeButton("انصراف",(d,w)->{}).setPositiveButton("حذف",(d,w)->{
                JavidAiSecrets.clear(this);
                preferences.edit().putBoolean(JavidCloudAiClient.ENABLED,false)
                    .putBoolean(JavidCloudAiClient.VOICE_ENABLED,false).apply();
                chatSwitch.setChecked(false);voiceSwitch.setChecked(false);refresh();
            }).show()));
        chatSwitch=new Switch(this);chatSwitch.setText("فعال‌سازی /ask (فقط درخواست صریح متن)");
        chatSwitch.setChecked(preferences.getBoolean(JavidCloudAiClient.ENABLED,false));
        chatSwitch.setOnCheckedChangeListener((view,checked)->{
            if(checked&&!JavidAiSecrets.configured(this)){
                Toast.makeText(this,"ابتدا کلید API را ذخیره کن",Toast.LENGTH_LONG).show();
                chatSwitch.setChecked(false);return;
            }
            preferences.edit().putBoolean(JavidCloudAiClient.ENABLED,checked).apply();
            if(!checked){voiceSwitch.setChecked(false);preferences.edit().putBoolean(JavidCloudAiClient.VOICE_ENABLED,false).apply();}
            refresh();
        });content.addView(chatSwitch);
        voiceSwitch=new Switch(this);voiceSwitch.setText("فعال‌سازی دریافت پیام صوتی با رضایت هر کاربر");
        voiceSwitch.setChecked(preferences.getBoolean(JavidCloudAiClient.VOICE_ENABLED,false));
        voiceSwitch.setOnCheckedChangeListener((view,checked)->{
            if(checked&&!JavidCloudAiClient.canChat(this)){
                Toast.makeText(this,"ابتدا کلید و قابلیت /ask را فعال کن",Toast.LENGTH_LONG).show();
                voiceSwitch.setChecked(false);return;
            }
            preferences.edit().putBoolean(JavidCloudAiClient.VOICE_ENABLED,checked).apply();refresh();
        });content.addView(voiceSwitch);
        content.addView(label("دستورات تلگرام: /ai (دستیار آفلاین)، /ask سؤال (پرسش ابری صریح)، /voiceon (اجازه ارسال صدا برای رونویسی)، /voiceoff (لغو اجازه)، /aistatus (وضعیت دسترسی). پیام صوتی فقط پس از /voiceon به سرویس پردازش صوت فرستاده می‌شود. فایل موقت بلافاصله حذف می‌شود.",14));
        refresh();
    }
    private void showKeyDialog(){EditText input=new EditText(this);input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint("sk-...");input.setPadding(20,25,20,25);
        new AlertDialog.Builder(this).setTitle("کلید API برای Javid AI")
            .setMessage("کلید فقط در فضای رمزگذاری‌شده همین دستگاه ذخیره می‌شود. ممکن است استفاده از API هزینه داشته باشد.")
            .setView(input).setNegativeButton("انصراف",(d,w)->{})
            .setPositiveButton("ذخیره",(d,w)->{
                try {JavidAiSecrets.save(this,input.getText().toString().trim());refresh();
                    Toast.makeText(this,"کلید ذخیره شد",Toast.LENGTH_SHORT).show();}
                catch(Exception error){Toast.makeText(this,"کلید ذخیره نشد",Toast.LENGTH_LONG).show();}
            }).show();
    }
    private void refresh(){status.setText("وضعیت کلید: "+(JavidAiSecrets.configured(this)?"✅ ذخیره شده":"⛔ تنظیم نشده")+
        " • متن ابری: "+(JavidCloudAiClient.canChat(this)?"فعال":"خاموش")+
        " • پیام صوتی: "+(JavidCloudAiClient.canVoice(this)?"فعال":"خاموش"));}
}

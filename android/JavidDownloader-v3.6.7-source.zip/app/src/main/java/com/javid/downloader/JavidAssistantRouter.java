package com.javid.downloader;

import java.util.Locale;

/**
 * Small, fully offline Persian/English intent router.
 * Does NOT pretend to be an LLM; no messages leave this phone.
 * The router classifies only. It never executes commands or accesses secrets.
 */
final class JavidAssistantRouter {
    enum Intent {
        HELP, BOT_STATUS, BOT_START, BOT_STOP, TELEGRAM_TEST, WEBHOOK_TEST,
        USERS, USER_MANAGER, STATS, DASHBOARD, DOWNLOADS, DIAGNOSE, RECOVER,
        UNRECOGNIZED
    }

    private JavidAssistantRouter() { }

    static String normalize(String raw) {
        if (raw == null) return "";
        return raw.toLowerCase(Locale.ROOT)
            .replace('\u064a', '\u06cc').replace('\u0643', '\u06a9')
            .replace('\u0623', '\u0627').replace('\u0625', '\u0627')
            .replace('\u200c', ' ').replaceAll("[\\p{Mn}\\u064b-\\u065f]", "")
            .replaceAll("[^\\p{L}\\p{Nd}]+", " ")
            .replaceAll("\\s+", " ").trim();
    }
    private static boolean any(String text, String... words) {
        for (String word : words) if (text.contains(word)) return true;
        return false;
    }

    static Intent detect(String utterance) {
        String s = normalize(utterance);
        if (s.isEmpty() || any(s, "راهنما", "کمک", "چه کار", "چی بلدی", "دستورها", "help", "commands"))
            return Intent.HELP;
        // Negated and ambiguous imperative phrases NEVER cause service actions.
        if (any(s, "نکن", "نکنید", "نزن", "نشه", "نباش", "don't", "do not", "not start", "not stop"))
            return Intent.HELP;
        boolean hasBot = any(s, "بات", "ربات", "bot", "telegram", "تلگرام");
        boolean askingStatus = any(s, "وضعیت", "سلامت", "فعاله", "فعال است", "روشنه", "خاموشه", "status", "health", "online");
        if (hasBot && any(s, "خاموش کن", "متوقف کن", "توقف بده", "بات رو ببند", "stop bot", "turn off bot"))
            return Intent.BOT_STOP;
        if (hasBot && any(s, "روشن کن", "فعال کن", "راه اندازی کن", "شروع کن", "start bot", "turn on bot"))
            return Intent.BOT_START;
        if (hasBot && any(s, "بازیابی", "راه اندازی مجدد", "دوباره راه بنداز", "تعمیر بات", "recover bot", "repair bot", "retry bot"))
            return Intent.RECOVER;
        if (any(s, "وبهوک", "وب هوک", "webhook", "تداخل 409", "خطای 409"))
            return Intent.WEBHOOK_TEST;
        if (hasBot && any(s, "تست اتصال", "ارتباط تلگرام", "وصل میشه", "وصل می شود", "connection", "test telegram"))
            return Intent.TELEGRAM_TEST;
        if (any(s, "مشکل", "خطا", "خراب", "قطع", "عیب", "کار نمی کن", "کار نمیکن", "error", "problem", "fix"))
            return Intent.DIAGNOSE;
        if (any(s, "تعداد اعضا", "تعداد کاربر", "چند کاربر", "چند نفر", "چند عضو", "کاربران چند", "vip", "وی ای پی"))
            return Intent.USERS;
        if (any(s, "کاربران", "کاربرها", "اعضا", "مدیریت کاربر", "manage users"))
            return Intent.USER_MANAGER;
        if (any(s, "گزارش دانلود", "آمار", "دانلود موفق", "دانلود ناموفق", "statistics", "report"))
            return Intent.STATS;
        if (any(s, "داشبورد", "dashboard", "نمودار")) return Intent.DASHBOARD;
        if (any(s, "دانلود", "صف", "download", "queue", "فایل ها")) return Intent.DOWNLOADS;
        if (hasBot && askingStatus) return Intent.BOT_STATUS;
        if (any(s, "وضعیت", "سلامت")) return Intent.BOT_STATUS;
        return Intent.UNRECOGNIZED;
    }
}

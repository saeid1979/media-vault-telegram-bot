package com.javid.downloader;

import java.text.Normalizer;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Conservatively reconcile overlapping public football score feeds.
 * A source disagreement is UNKNOWN, not evidence of a goal, and must never
 * generate an alert until the feeds agree again. No network/Android dependency.
 */
final class FootballSourceReliability {
    private FootballSourceReliability() {}

    static final class Game {
        final String id, home, away, source;
        final long kickoff;
        final int h, a;
        final boolean iran, nationalTeam, live, finished;
        Game(String id, String home, String away, String source, long kickoff,
             int h, int a, boolean iran, boolean nationalTeam, boolean live, boolean finished) {
            this.id=id;this.home=home;this.away=away;this.source=source;
            this.kickoff=kickoff;this.h=h;this.a=a;this.iran=iran;
            this.nationalTeam=nationalTeam;this.live=live;this.finished=finished;
        }
    }
    static final class Group {
        final String stableId;
        final Game preferred;
        final int sources;
        final boolean scoreConflict;
        Group(String stableId,Game preferred,int sources,boolean scoreConflict) {
            this.stableId=stableId;this.preferred=preferred;
            this.sources=sources;this.scoreConflict=scoreConflict;
        }
    }
    static final class Result {
        final List<Group> games=new ArrayList<>();
        int duplicates, conflicting, corroborated;
    }
    static String normalizedTeam(String value) {
        if(value==null)return "";
        String n=Normalizer.normalize(value.toLowerCase(Locale.ROOT),Normalizer.Form.NFKD)
            .replaceAll("\\p{M}+","")
            .replace('ي','ی').replace('ك','ک')
            .replaceAll("[\\p{Punct}\\p{IsPunctuation}]+", " ")
            .replaceAll("\\s+", " ").trim();
        // Only discard exact, well-known decorations; avoid aggressive aliases
        // which can silently conflate two genuinely different clubs.
        n=n.replaceAll("^(fc|cf|afc)\\s+","")
           .replaceAll("\\s+(fc|cf)$","").trim();
        return n;
    }
    private static String family(Game g) {
        return g.iran?"IRN":g.nationalTeam?"NAT":"EUR";
    }
    static String stableId(Game g) {
        if(g==null || g.kickoff<=0 || normalizedTeam(g.home).isEmpty()
                || normalizedTeam(g.away).isEmpty())return g==null?"":g.id;
        LocalDate date=Instant.ofEpochMilli(g.kickoff).atZone(ZoneOffset.UTC).toLocalDate();
        return "match:"+family(g)+":"+date+":"+normalizedTeam(g.home)+
            ":"+normalizedTeam(g.away);
    }
    private static boolean sameGame(Game a,Game b) {
        return a.kickoff>0 && b.kickoff>0 &&
            Math.abs(a.kickoff-b.kickoff)<=TimeUnit.MINUTES.toMillis(90) &&
            family(a).equals(family(b)) &&
            normalizedTeam(a.home).equals(normalizedTeam(b.home)) &&
            normalizedTeam(a.away).equals(normalizedTeam(b.away)) &&
            !normalizedTeam(a.home).isEmpty() && !normalizedTeam(a.away).isEmpty();
    }
    private static int priority(Game g) {
        // FotMob publishes Iranian domestic fixtures frequently; ESPN is
        // preferred for supported Europe and senior national competitions.
        if(g.iran) {
            if(g.source.equals("FotMob"))return 0;
            if(g.source.equals("Sofascore"))return 1;
            return 2;
        }
        if(g.source.equals("ESPN"))return 0;
        if(g.source.equals("FotMob"))return 1;
        return 2;
    }
    static Result reconcile(List<Game> input) {
        Result result=new Result();
        if(input==null||input.isEmpty())return result;
        List<List<Game>> groups=new ArrayList<>();
        for(Game g:input) {
            if(g==null || g.id==null || g.id.isEmpty())continue;
            List<Game> target=null;
            for(List<Game> existing:groups) {
                if(sameGame(existing.get(0),g)) {target=existing;break;}
            }
            if(target==null) {target=new ArrayList<>();groups.add(target);}
            target.add(g);
        }
        for(List<Game> group:groups) {
            group.sort(Comparator.comparingInt(FootballSourceReliability::priority)
                .thenComparing(g->g.id));
            Game preferred=group.get(0);
            boolean conflict=false;
            Set<String> providers=new HashSet<>();
            for(Game g:group)providers.add(g.source);
            // Multiple feeds from the SAME source do not independently
            // corroborate a result. One provider may have stale cached data.
            if(providers.size()>1){
                Map<String,Game> bySource=new HashMap<>();
                for(Game g:group)bySource.putIfAbsent(g.source,g);
                for(Game g:bySource.values()) {
                    if(g.h!=preferred.h||g.a!=preferred.a) {conflict=true;break;}
                }
            }
            String stableId=stableId(preferred);
            result.games.add(new Group(stableId,preferred,providers.size(),conflict));
            result.duplicates+=group.size()-1;
            if(conflict) result.conflicting++;
            else if(providers.size()>1)result.corroborated++;
        }
        return result;
    }
}

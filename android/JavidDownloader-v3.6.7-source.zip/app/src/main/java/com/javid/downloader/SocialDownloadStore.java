package com.javid.downloader;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.Consumer;

/** Persistent queue of user-initiated yt-dlp jobs. No tokens/cookies are stored. */
public final class SocialDownloadStore {
    public static final String QUEUED="queued", RUNNING="running", PAUSED="paused", DONE="done", FAILED="failed", CANCELLED="cancelled";
    private static final String PREF="javid_social_queue_v310", KEY="items";
    private static final Object LOCK=new Object();
    private SocialDownloadStore() {}
    public static final class Job {
        public String id="", link="", host="", state=QUEUED, info="", uri="", fileName="";
        public int quality=0, percent=0, attempts=0, priority=1;
        public long created=System.currentTimeMillis(), updated=created, retryAt=0;
        public JSONObject toJson() throws Exception {
            JSONObject j=new JSONObject();j.put("id",id);j.put("link",link);j.put("host",host);j.put("state",state);
            j.put("info",info);j.put("uri",uri);j.put("fileName",fileName);j.put("quality",quality);
            j.put("percent",percent);j.put("attempts",attempts);j.put("priority",priority);
            j.put("created",created);j.put("updated",updated);j.put("retryAt",retryAt);return j;
        }
        static Job parse(JSONObject o){Job j=new Job();j.id=o.optString("id");j.link=o.optString("link");
            j.host=o.optString("host");j.state=o.optString("state",QUEUED);j.info=o.optString("info");
            j.uri=o.optString("uri");j.fileName=o.optString("fileName");j.quality=o.optInt("quality");
            j.percent=o.optInt("percent");j.attempts=o.optInt("attempts");j.priority=o.optInt("priority",1);
            j.created=o.optLong("created",System.currentTimeMillis());j.updated=o.optLong("updated",j.created);
            j.retryAt=o.optLong("retryAt",0);return j;
        }
    }
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    private static ArrayList<Job> read(Context c){ArrayList<Job> result=new ArrayList<>();try{
        JSONArray a=new JSONArray(prefs(c).getString(KEY,"[]"));for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o!=null){Job j=Job.parse(o);if(!j.id.isEmpty())result.add(j);}}
        }catch(Exception ignored){}return result;}
    private static void write(Context c,List<Job> jobs){JSONArray a=new JSONArray();try{for(Job j:jobs)a.put(j.toJson());}catch(Exception ignored){}
        prefs(c).edit().putString(KEY,a.toString()).commit();}
    public static List<Job> snapshot(Context c){synchronized(LOCK){return new ArrayList<>(read(c));}}
    public static Job get(Context c,String id){synchronized(LOCK){for(Job j:read(c))if(j.id.equals(id))return j;return null;}}
    public static boolean isSupported(String address){try{Uri u=Uri.parse(address);String scheme=u.getScheme(),host=u.getHost();
        if(!"https".equalsIgnoreCase(scheme)||host==null||u.getUserInfo()!=null)return false;
        String h=host.toLowerCase(Locale.ROOT);
        String[] suffixes={"youtube.com","youtu.be","youtube-nocookie.com","instagram.com","instagr.am","facebook.com","fb.watch","tiktok.com","vm.tiktok.com","x.com","twitter.com","pinterest.com","pin.it","vimeo.com","reddit.com","redd.it","dailymotion.com","dai.ly","twitch.tv"};
        for(String s:suffixes)if(h.equals(s)||h.endsWith("."+s))return true;
    }catch(Exception ignored){}return false;}
    public static String add(Context c,String url,int quality,boolean important){String clean=url==null?"":url.trim();
        if(clean.length()>3000||!isSupported(clean))throw new IllegalArgumentException("لینک HTTPS از شبکه اجتماعی پشتیبانی‌شده وارد کن.");
        if(quality<0||quality>5)throw new IllegalArgumentException("کیفیت نامعتبر است");
        synchronized(LOCK){ArrayList<Job> jobs=read(c);
            for(Job j:jobs)if(j.link.equals(clean)&&j.quality==quality&&!(CANCELLED.equals(j.state)||FAILED.equals(j.state)))return j.id;
            Job j=new Job();j.id=UUID.randomUUID().toString();j.link=clean;j.host=Uri.parse(clean).getHost();
            j.quality=quality;j.priority=important?2:1;jobs.add(j);write(c,jobs);return j.id;
        }
    }
    public static void update(Context c,String id,Consumer<Job> action){synchronized(LOCK){ArrayList<Job> all=read(c);
        for(Job j:all)if(j.id.equals(id)){action.accept(j);j.updated=System.currentTimeMillis();write(c,all);break;}
    }}
    public static void interrupted(Context c){synchronized(LOCK){ArrayList<Job> all=read(c);boolean changed=false;
        for(Job j:all)if(RUNNING.equals(j.state)){j.state=QUEUED;j.percent=0;j.info="بازیابی صف بعد از توقف برنامه";changed=true;}
        if(changed)write(c,all);
    }}
    public static Job next(Context c){synchronized(LOCK){ArrayList<Job> ready=new ArrayList<>();long now=System.currentTimeMillis();
        for(Job j:read(c))if(QUEUED.equals(j.state)&&j.retryAt<=now)ready.add(j);
        Collections.sort(ready,Comparator.comparingInt((Job j)->-j.priority).thenComparingLong(j->j.created));
        return ready.isEmpty()?null:ready.get(0);
    }}
    public static boolean hasQueued(Context c){synchronized(LOCK){for(Job j:read(c))if(QUEUED.equals(j.state))return true;return false;}}
    public static void control(Context c,String id,String choice){
        Job before=get(c,id);
        boolean wasRunning=before!=null && RUNNING.equals(before.state);
        update(c,id,j->{
        switch(choice){
            case "pause":if(QUEUED.equals(j.state)||RUNNING.equals(j.state)){j.state=PAUSED;j.info="توسط کاربر متوقف شد";}break;
            case "resume":if(PAUSED.equals(j.state)||FAILED.equals(j.state)){j.state=QUEUED;j.info="";j.retryAt=0;j.attempts=0;}break;
            case "cancel":if(!DONE.equals(j.state)){j.state=CANCELLED;j.info="لغو شد";}break;
            case "priority":if(QUEUED.equals(j.state)||PAUSED.equals(j.state))j.priority=j.priority==1?2:1;break;
        }
    });// Worker owns temporary files until it has stopped.
        if("cancel".equals(choice)) { Job j=get(c,id); if(j!=null && !RUNNING.equals(j.state)) { /* service performs final cleanup */ } }}
    public static File folder(Context c,String id){File base=new File(c.getFilesDir(),"social_download_parts");return new File(base,id);}
    public static void deleteFiles(Context c,String id){File root=folder(c,id);File[] children=root.listFiles();
        if(children!=null)for(File f:children)if(f.isFile())f.delete();root.delete();}
}

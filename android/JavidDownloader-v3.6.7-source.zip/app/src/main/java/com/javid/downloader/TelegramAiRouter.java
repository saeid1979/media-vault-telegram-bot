package com.javid.downloader;

import java.util.Locale;

/**
 * Private-chat, offline, deterministic multilingual intent detection.
 * This is NOT a cloud LLM and never stores or forwards user utterances.
 * No intent itself grants authorization or performs a privileged action.
 */
public final class TelegramAiRouter {
    public enum Intent {
        HELP, ACCOUNT, BOT_STATUS, VIDEO, MP3,
        IRAN_FOOTBALL, WORLD_FOOTBALL, MATCHES, TABLE,
        WEATHER, FAVORITES, SUBSCRIBE, UNSUBSCRIBE,
        ADMIN_HEALTH, ADMIN_STATS, DOWNLOAD_STATUS, UNKNOWN
    }
    private TelegramAiRouter() { }

    static String normalize(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
            .replace('ي','ی').replace('ك','ک')
            .replace('أ','ا').replace('إ','ا').replace('آ','ا')
            .replace('‌',' ')
            .replaceAll("[\u064b-\u065f]", "")
            .replaceAll("[^\\p{L}\\p{Nd}]+", " ")
            .replaceAll("\\s+", " ").trim();
    }
    private static boolean includes(String text, String... parts) {
        for (String part : parts) if (text.contains(part)) return true;
        return false;
    }
    public static Intent detect(String raw) {
        String s = normalize(raw);
        if (s.isEmpty() || s.length() > 550) return Intent.UNKNOWN;
        // Commands with unintended negation never trigger side effects.
        if (includes(s, "نکن", "نکنید", "نمیخوام", "نمی خوام", "dont", "do not", "no quiero"))
            return Intent.UNKNOWN;
        if (includes(s,"راهنما","کمک","چی بلدی","چه کار","help","ayuda","commands","capabilities"))
            return Intent.HELP;
        if (includes(s,"لغو اعلان","قطع اعلان","اعلان رو قطع","دیگه اعلان","unsubscribe","stop alerts","desactivar avisos"))
            return Intent.UNSUBSCRIBE;
        if (includes(s,"عضویت اعلان","اعلان رو فعال","فعال کردن اعلان","خبرنامه رو فعال","subscribe","enable alerts","activar avisos"))
            return Intent.SUBSCRIBE;
        if (includes(s,"سلامت بات","عیب یابی بات","مشکل بات","خطای بات","بات کار نمیکن","bot error","bot diagnostics","diagnostico del bot"))
            return Intent.ADMIN_HEALTH;
        if (includes(s,"تعداد کاربران","چند کاربر","چند نفر","گزارش مدیریتی","امار کاربران","admin stats","user statistics","estadisticas de usuarios"))
            return Intent.ADMIN_STATS;
        if (includes(s,"دانلودهای فعال","صف دانلود","وضعیت دانلود","چند دانلود","download status","download queue","cola de descargas"))
            return Intent.DOWNLOAD_STATUS;
        if (includes(s,"اهنگ","موسیقی","ام پی تری","mp3","audio file","solo audio","solo musica","musica"))
            return Intent.MP3;
        if (includes(s,"دانلود ویدیو","دانلود فیلم","ویدیو دانلود","download video","download clip","descargar video","bajar video"))
            return Intent.VIDEO;
        if (includes(s,"فوتبال ایران","لیگ ایران","پرسپولیس","استقلال","iran football","iran league","liga iran"))
            return Intent.IRAN_FOOTBALL;
        if (includes(s,"نتایج فوتبال","فوتبال جهان","نتیجه فوتبال","football results","football scores","resultados futbol","resultados fútbol"))
            return Intent.WORLD_FOOTBALL;
        if (includes(s,"برنامه بازی","بازی های فردا","مسابقات امروز","fixtures","upcoming matches","partidos manana","partidos mañana"))
            return Intent.MATCHES;
        if (includes(s,"جدول لیگ","جدول ","رده بندی","جدول فوتبال","standings","league table","clasificacion","clasificación"))
            return Intent.TABLE;
        if (includes(s,"اب و هوا","هواشناسی","بارندگی","weather","clima","tiempo"))
            return Intent.WEATHER;
        if (includes(s,"تیم محبوب","تیم های محبوب","تیم مورد علاقه","تیم های من","my teams","favorite team","equipo favorito"))
            return Intent.FAVORITES;
        if (includes(s,"وضعیت حساب","سهمیه","حساب من","اکانت من","my account","my quota","mi cuenta","limite"))
            return Intent.ACCOUNT;
        if (includes(s,"وضعیت بات","ربات فعاله","بات فعاله","bot status","bot online","estado del bot"))
            return Intent.BOT_STATUS;
        return Intent.UNKNOWN;
    }
}

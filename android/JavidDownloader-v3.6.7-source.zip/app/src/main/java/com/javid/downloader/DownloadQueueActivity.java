package com.javid.downloader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Download queue for direct HTTPS files. Social network pages remain handled by existing yt-dlp UI. */
public final class DownloadQueueActivity extends Activity {
    private static final int NAVY=Color.rgb(25,41,66),TEAL=Color.rgb(0,150,134),GREY=Color.rgb(108,123,145),BG=Color.rgb(246,248,252);
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){@Override public void run(){if(!isFinishing()&&!isDestroyed()){drawItems();handler.postDelayed(this,1750);}}};
    private EditText urlInput,nameInput;private CheckBox priority;
    private LinearLayout rows,socialRows;private TextView summary,socialSummary;private EditText socialUrl;private Spinner socialQuality;
    private int dip(int x){return Math.round(getResources().getDisplayMetrics().density*x);}
    private GradientDrawable panel(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dip(radius));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout horizontal(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private LinearLayout.LayoutParams pad(int t,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dip(t),0,dip(b));return p;}
    private Button button(String label,int bg,int fg){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);b.setTextColor(fg);b.setBackground(panel(bg,12));b.setPadding(dip(9),dip(5),dip(9),dip(5));return b;}
    private static String unit(long bytes){if(bytes<0)return "نامشخص";if(bytes<1024)return bytes+" B";
        double amount=bytes;String[] u={"B","KB","MB","GB","TB"};int p=0;
        while(amount>=1024&&p<u.length-1){amount/=1024;p++;}return String.format(Locale.US,"%.1f %s",amount,u[p]);
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=vertical();root.setPadding(dip(17),dip(17),dip(17),dip(25));scroll.addView(root);setContentView(scroll);
        TextView title=text("📥 مدیر دانلود پیشرفته",23,NAVY,true);root.addView(title,pad(6,4));
        root.addView(text("Javid Downloader 3.1.0 • صف فایل مستقیم و رسانه‌های اجتماعی",12,GREY,false));
        LinearLayout card=vertical();card.setPadding(dip(14),dip(13),dip(14),dip(13));card.setBackground(panel(Color.WHITE,18));root.addView(card,pad(15,13));
        card.addView(text("لینک مستقیم فایل (HTTPS)",14,NAVY,true));
        urlInput=new EditText(this);urlInput.setSingleLine(true);urlInput.setTextSize(13);urlInput.setHint("https://example.com/video.mp4");
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        card.addView(urlInput,new LinearLayout.LayoutParams(-1,dip(51)));
        nameInput=new EditText(this);nameInput.setSingleLine(true);nameInput.setTextSize(13);nameInput.setHint("نام فایل (اختیاری)");
        card.addView(nameInput,new LinearLayout.LayoutParams(-1,dip(48)));
        priority=new CheckBox(this);priority.setText("اولویت بالا");priority.setTextSize(13);priority.setTextColor(NAVY);card.addView(priority);
        Button add=button("＋ افزودن به صف دانلود",NAVY,Color.WHITE);
        card.addView(add,new LinearLayout.LayoutParams(-1,dip(48)));
        add.setOnClickListener(v->{
            try{String link=urlInput.getText().toString().trim();if(link.isEmpty()){Toast.makeText(this,"لینک را وارد کن",Toast.LENGTH_SHORT).show();return;}
                String id=DownloadQueueStore.add(this,link,nameInput.getText().toString(),priority.isChecked());
                urlInput.setText("");nameInput.setText("");priority.setChecked(false);wake();drawItems();
                Toast.makeText(this,"به صف دانلود افزوده شد",Toast.LENGTH_SHORT).show();
            }catch(Exception e){new AlertDialog.Builder(this).setTitle("لینک معتبر نیست").setMessage(e.getMessage()).setPositiveButton("متوجه شدم",null).show();}
        });
        TextView hint=text("این صف برای لینک مستقیم فایل است؛ برای YouTube و Instagram از صفحه اصلی و موتور yt-dlp استفاده کن. دانلودها در Downloads/JavidDownloader ذخیره می‌شوند.",12,GREY,false);
        root.addView(hint,pad(0,16));
        summary=text("در حال بررسی صف...",14,NAVY,true);root.addView(summary,pad(3,9));
        LinearLayout actions=horizontal();root.addView(actions,pad(0,10));
        Button refreshBtn=button("↻ به‌روزرسانی",Color.rgb(223,238,248),NAVY);
        actions.addView(refreshBtn,new LinearLayout.LayoutParams(0,dip(44),1));refreshBtn.setOnClickListener(v->{wake();drawItems();});
        Button viewFolder=button("📂 فایل‌های ذخیره‌شده",Color.rgb(225,247,239),NAVY);
        LinearLayout.LayoutParams f=new LinearLayout.LayoutParams(0,dip(44),1);f.setMargins(dip(8),0,0,0);
        actions.addView(viewFolder,f);
        viewFolder.setOnClickListener(v->{
            try{Intent x=new Intent(Intent.ACTION_OPEN_DOCUMENT);x.setType("*/*");x.addCategory(Intent.CATEGORY_OPENABLE);startActivity(Intent.createChooser(x,"نمایش فایل‌ها؛ پوشه Downloads/JavidDownloader"));}
            catch(Exception e){Toast.makeText(this,"از Files > Downloads > JavidDownloader استفاده کن",Toast.LENGTH_LONG).show();}
        });
        rows=vertical();root.addView(rows,pad(3,0));
        // Separate durable yt-dlp queue: streaming websites are NOT direct file URLs.
        LinearLayout social=vertical();social.setPadding(dip(14),dip(14),dip(14),dip(14));
        social.setBackground(panel(Color.WHITE,18));root.addView(social,pad(21,12));
        social.addView(text("🎬 صف دانلود YouTube / Instagram / Facebook / TikTok",16,NAVY,true));
        social.addView(text("لینک عمومی HTTPS • یک دانلود در هر نوبت • فایل‌های نیمه‌تمام نگهداری می‌شوند",12,GREY,false),pad(5,5));
        socialUrl=new EditText(this);socialUrl.setSingleLine(true);socialUrl.setTextSize(13);
        socialUrl.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        socialUrl.setHint("https://www.youtube.com/watch?v=...");social.addView(socialUrl,new LinearLayout.LayoutParams(-1,dip(51)));
        socialQuality=new Spinner(this);
        String[] formats={"بهترین کیفیت", "1080p", "720p", "480p", "360p", "MP3"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,formats);
        socialQuality.setAdapter(adapter);social.addView(socialQuality,new LinearLayout.LayoutParams(-1,dip(48)));
        Button socialAdd=button("＋ افزودن رسانه به صف",TEAL,Color.WHITE);
        social.addView(socialAdd,new LinearLayout.LayoutParams(-1,dip(48)));
        socialAdd.setOnClickListener(v->{try{
            String link=socialUrl.getText().toString().trim();
            SocialDownloadStore.add(this,link,socialQuality.getSelectedItemPosition(),false);
            socialUrl.setText("");wakeSocial();drawSocial();
            Toast.makeText(this,"به صف yt-dlp اضافه شد",Toast.LENGTH_SHORT).show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("لینک رسانه معتبر نیست")
            .setMessage(e.getMessage()).setPositiveButton("متوجه شدم",null).show();}});
        socialSummary=text("دانلودهای رسانه‌ای",14,NAVY,true);root.addView(socialSummary,pad(3,8));
        socialRows=vertical();root.addView(socialRows,pad(4,15));
        String shared=getIntent().getStringExtra("url");if(shared!=null&&!shared.isEmpty()){
            if(SocialDownloadStore.isSupported(shared))socialUrl.setText(shared);else urlInput.setText(shared);
        }
    }
    private void wake(){try{Intent s=new Intent(this,DownloadQueueService.class).setAction(DownloadQueueService.ACTION_WAKE);startForegroundService(s);}
        catch(Exception e){Toast.makeText(this,"اجرای سرویس ممکن نیست. مجوزهای برنامه را بررسی کن.",Toast.LENGTH_LONG).show();}}
    private void wakeSocial(){try{startForegroundService(new Intent(this,SocialDownloadService.class)
        .setAction(SocialDownloadService.WAKE));}catch(Exception e){Toast.makeText(this,"امکان شروع صف رسانه‌ای نیست",Toast.LENGTH_LONG).show();}}
    private void signalSocial(){try{startService(new Intent(this,SocialDownloadService.class)
        .setAction(SocialDownloadService.CONTROL));}catch(Exception ignored){}}
    @Override protected void onResume(){super.onResume();
        for(DownloadQueueStore.Item item:DownloadQueueStore.snapshot(this)){
            if(DownloadQueueStore.QUEUED.equals(item.state)||DownloadQueueStore.RUNNING.equals(item.state)){
                wake();break;
            }
        }
        if(SocialDownloadStore.hasQueued(this))wakeSocial();
        handler.post(refresh);
    }
    @Override protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
    private void drawItems(){if(rows==null)return;
        drawSocial();
        List<DownloadQueueStore.Item> jobs=DownloadQueueStore.snapshot(this);int done=0,active=0,queued=0,paused=0,failed=0;
        for(DownloadQueueStore.Item i:jobs){switch(i.state){case DownloadQueueStore.DONE:done++;break;case DownloadQueueStore.RUNNING:active++;break;
            case DownloadQueueStore.QUEUED:queued++;break;case DownloadQueueStore.PAUSED:paused++;break;case DownloadQueueStore.FAILED:failed++;break;}}
        summary.setText("فعال: "+active+"   در صف: "+queued+"   متوقف: "+paused+"   تکمیل: "+done+"   خطا: "+failed);
        rows.removeAllViews();
        if(jobs.isEmpty()){rows.addView(text("هنوز فایلی به صف اضافه نشده است.",14,GREY,false),pad(18,6));return;}
        for(int j=jobs.size()-1;j>=0;j--){DownloadQueueStore.Item job=jobs.get(j);addRow(job);}
    }
    private void drawSocial(){if(socialRows==null)return;
        List<SocialDownloadStore.Job> jobs=SocialDownloadStore.snapshot(this);
        int running=0,waiting=0,done=0,failed=0;
        for(SocialDownloadStore.Job j:jobs){if(SocialDownloadStore.RUNNING.equals(j.state))running++;
            else if(SocialDownloadStore.QUEUED.equals(j.state))waiting++;
            else if(SocialDownloadStore.DONE.equals(j.state))done++;
            else if(SocialDownloadStore.FAILED.equals(j.state))failed++;}
        socialSummary.setText("🎬 رسانه‌ها • فعال: "+running+"  در صف: "+waiting+"  کامل: "+done+"  خطا: "+failed);
        socialRows.removeAllViews();
        if(jobs.isEmpty()){socialRows.addView(text("هنوز دانلود رسانه‌ای به صف اضافه نشده است.",13,GREY,false));return;}
        for(int n=jobs.size()-1;n>=0;n--){SocialDownloadStore.Job j=jobs.get(n);
            LinearLayout card=vertical();card.setPadding(dip(13),dip(13),dip(13),dip(13));
            card.setBackground(panel(Color.WHITE,16));socialRows.addView(card,pad(4,6));
            String label=j.fileName.isEmpty()?j.host:j.fileName;
            card.addView(text(label,14,NAVY,true));
            String format=j.quality==5?"MP3":j.quality==0?"بهترین":(j.quality==1?"1080p":j.quality==2?"720p":j.quality==3?"480p":"360p");
            card.addView(text("فرمت: "+format+"  •  "+stateLabel(j.state)+(j.priority==2?"  • فوری":""),12,GREY,false),pad(3,4));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);
            bar.setProgress(j.percent);bar.setIndeterminate(SocialDownloadStore.RUNNING.equals(j.state)&&j.percent==0);
            bar.setProgressTintList(ColorStateList.valueOf(TEAL));card.addView(bar,pad(6,6));
            if(!j.info.isEmpty())card.addView(text(j.info,12,GREY,false),pad(3,3));
            LinearLayout options=horizontal();card.addView(options,pad(8,0));
            if(SocialDownloadStore.RUNNING.equals(j.state)||SocialDownloadStore.QUEUED.equals(j.state))
                socialControl(options,"⏸ توقف",j.id,"pause",false);
            else if(SocialDownloadStore.PAUSED.equals(j.state)||SocialDownloadStore.FAILED.equals(j.state))
                socialControl(options,"▶ ادامه",j.id,"resume",true);
            if(SocialDownloadStore.QUEUED.equals(j.state)||SocialDownloadStore.PAUSED.equals(j.state))
                socialControl(options,j.priority==2?"↓ عادی":"↑ فوری",j.id,"priority",false);
            if(!SocialDownloadStore.DONE.equals(j.state)&&!SocialDownloadStore.CANCELLED.equals(j.state))
                socialControl(options,"✕ لغو",j.id,"cancel",false);
            if(SocialDownloadStore.DONE.equals(j.state)&&!j.uri.isEmpty()){
                Button open=button("📂 باز کردن",Color.rgb(220,242,232),NAVY);
                options.addView(open,new LinearLayout.LayoutParams(0,dip(42),1));
                open.setOnClickListener(v->openFile(j.uri,j.fileName));
            }
        }
    }
    private void socialControl(LinearLayout row,String title,String id,String action,boolean primary){
        Button b=button(title,primary?TEAL:Color.rgb(234,240,248),primary?Color.WHITE:NAVY);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dip(42),1);p.setMargins(dip(2),0,dip(2),0);
        row.addView(b,p);b.setOnClickListener(v->{SocialDownloadStore.control(this,id,action);
            if("resume".equals(action)||"priority".equals(action))wakeSocial();
            else signalSocial();drawSocial();});
    }
    private void addRow(DownloadQueueStore.Item i){
        LinearLayout card=vertical();card.setPadding(dip(13),dip(13),dip(13),dip(13));card.setBackground(panel(Color.WHITE,16));
        rows.addView(card,pad(5,5));
        String state=stateLabel(i.state);int color=DownloadQueueStore.DONE.equals(i.state)?TEAL:NAVY;
        card.addView(text(i.name,15,NAVY,true));
        card.addView(text("● "+state+(i.priority==2?"  • اولویت بالا":""),12,color,true),pad(4,2));
        int pc=i.total>0?(int)Math.min(100,Math.max(0,(100.0*i.bytes/i.total))):0;
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);
        bar.setIndeterminate(i.total<=0&&DownloadQueueStore.RUNNING.equals(i.state));bar.setProgress(pc);
        bar.setProgressTintList(ColorStateList.valueOf(TEAL));card.addView(bar,pad(5,7));
        String extra=unit(i.bytes)+" / "+unit(i.total);
        if(i.bytesPerSec>1 && DownloadQueueStore.RUNNING.equals(i.state)){
            extra+="    •    "+unit((long)i.bytesPerSec)+"/s";
            if(i.total>i.bytes)extra+="    •    "+Math.max(1,Math.round((i.total-i.bytes)/i.bytesPerSec))+" ثانیه";
        }
        card.addView(text(extra,12,GREY,false));
        if(i.reason!=null&&!i.reason.isEmpty())card.addView(text(i.reason,12,Color.rgb(173,94,45),false),pad(4,0));
        LinearLayout ctr=horizontal();card.addView(ctr,pad(9,0));
        if(DownloadQueueStore.RUNNING.equals(i.state)||DownloadQueueStore.QUEUED.equals(i.state)){
            control(ctr,"⏸ توقف",i.id,"pause",false);
        } else if(DownloadQueueStore.PAUSED.equals(i.state)||DownloadQueueStore.FAILED.equals(i.state)){
            control(ctr,"▶ ادامه",i.id,"resume",true);
        }
        if(DownloadQueueStore.QUEUED.equals(i.state)||DownloadQueueStore.PAUSED.equals(i.state))
            control(ctr,i.priority==2?"↓ عادی":"↑ فوری",i.id,"priority",false);
        if(!DownloadQueueStore.DONE.equals(i.state)&&!DownloadQueueStore.CANCELLED.equals(i.state))
            control(ctr,"✕ لغو",i.id,"cancel",false);
        if(DownloadQueueStore.DONE.equals(i.state)&&!i.uri.isEmpty()){
            Button open=button("📂 باز کردن",Color.rgb(220,242,232),NAVY);ctr.addView(open,new LinearLayout.LayoutParams(0,dip(42),1));
            open.setOnClickListener(v->openFile(i.uri,i.name));
        }
        if(DownloadQueueStore.CANCELLED.equals(i.state))card.addView(text("دانلود لغو شده است.",12,GREY,false),pad(6,0));
        card.addView(text("افزوده‌شده: "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,new Locale("fa")).format(new Date(i.addedAt)),11,GREY,false),pad(8,0));
    }
    private void control(LinearLayout row,String title,String id,String action,boolean primary){
        Button b=button(title,primary?TEAL:Color.rgb(234,240,248),primary?Color.WHITE:NAVY);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dip(42),1);p.setMargins(dip(2),0,dip(2),0);row.addView(b,p);
        b.setOnClickListener(v->{DownloadQueueStore.control(this,id,action);if("resume".equals(action)||"priority".equals(action))wake();drawItems();});
    }
    private static String stateLabel(String state){switch(state){case DownloadQueueStore.RUNNING:return "در حال دانلود";case DownloadQueueStore.QUEUED:return "منتظر دانلود";
        case DownloadQueueStore.PAUSED:return "متوقف";case DownloadQueueStore.DONE:return "کامل";
        case DownloadQueueStore.FAILED:return "ناموفق";case DownloadQueueStore.CANCELLED:return "لغو شده";default:return state;}}
    private void openFile(String raw,String name){
        try{Intent i=new Intent(Intent.ACTION_VIEW);Uri uri=Uri.parse(raw);
            String mime=getContentResolver().getType(uri);i.setDataAndType(uri,mime==null?"*/*":mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"باز کردن فایل"));
        }catch(Exception e){Toast.makeText(this,"برنامه مناسب برای باز کردن فایل یافت نشد",Toast.LENGTH_LONG).show();}
    }
}

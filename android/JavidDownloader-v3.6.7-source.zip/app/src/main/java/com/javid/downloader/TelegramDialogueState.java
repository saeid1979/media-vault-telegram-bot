package com.javid.downloader;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Minimal, in-memory conversation context. Never stores message text, URLs,
 * downloaded files, usernames, chat identifiers or Telegram access tokens.
 * Entries expire after five minutes; restarting the service clears them.
 */
public final class TelegramDialogueState {
    public enum Phase { NONE, CHOOSE_FORMAT, WAIT_FOR_LINK }
    public enum Choice { NO_REPLY, MP3, VIDEO, ASK_AGAIN }
    public static final long TIMEOUT_MS = 5L * 60 * 1000;
    private static final int MAX_SESSIONS = 400;
    private static final class State {
        final Phase phase;
        final String format;
        final long expiresAt;
        State(Phase phase, String format, long expiresAt) {
            this.phase = phase; this.format = format; this.expiresAt = expiresAt;
        }
    }
    private final Map<Long, State> sessions = new ConcurrentHashMap<>();
    public static boolean asksDownloadFormat(String raw) {
        String s=TelegramAiRouter.normalize(raw);
        return s.equals("دانلود") || s.equals("دانلود میخوام") ||
            s.equals("میخوام دانلود کنم") || s.equals("download") ||
            s.equals("download file") || s.equals("descargar") ||
            s.equals("quiero descargar");
    }
    public static boolean isCancel(String raw) {
        String s=TelegramAiRouter.normalize(raw);
        return s.equals("لغو") || s.equals("بیخیال") || s.equals("cancel") ||
            s.equals("cancelar") || s.equals("انصراف");
    }
    private State current(long user, long now) {
        State state=sessions.get(user);
        if (state != null && now >= state.expiresAt) {
            sessions.remove(user, state); return null;
        }
        return state;
    }
    private void store(long user, Phase phase, String format, long now) {
        if (sessions.size() >= MAX_SESSIONS) {
            sessions.entrySet().removeIf(e -> now >= e.getValue().expiresAt);
            if (sessions.size() >= MAX_SESSIONS) sessions.clear();
        }
        sessions.put(user,new State(phase,format,now+TIMEOUT_MS));
    }
    public void askFormat(long user, long now) { store(user,Phase.CHOOSE_FORMAT,null,now); }
    public boolean awaitingFormat(long user, long now) {
        State s=current(user,now);return s!=null && s.phase==Phase.CHOOSE_FORMAT;
    }
    public Choice replyToFormat(long user,String raw,long now) {
        if (!awaitingFormat(user,now)) return Choice.NO_REPLY;
        String s=TelegramAiRouter.normalize(raw);
        if (s.equals("mp3") || s.equals("اهنگ") || s.equals("موسیقی") ||
            s.equals("صدا") || s.equals("audio") || s.equals("musica") ||
            s.equals("آهنگ") || s.equals("1") || s.equals("یک")) {
            rememberFormat(user,"a",now);return Choice.MP3;
        }
        if (s.equals("video") || s.equals("ویدیو") || s.equals("ویدئو") ||
            s.equals("فیلم") || s.equals("vídeo") || s.equals("2") || s.equals("دو")) {
            rememberFormat(user,"v",now);return Choice.VIDEO;
        }
        return Choice.ASK_AGAIN;
    }
    public void rememberFormat(long user,String format,long now) {
        if (!"a".equals(format) && !"v".equals(format)) return;
        store(user,Phase.WAIT_FOR_LINK,format,now);
    }
    /** Consume only after a link arrives. A link after timeout gets format buttons. */
    public String consumeForLink(long user,long now) {
        State state=current(user,now);
        if (state==null || state.phase!=Phase.WAIT_FOR_LINK) return null;
        sessions.remove(user,state);
        return state.format;
    }
    public void clear(long user) { sessions.remove(user); }
    public boolean hasActive(long user,long now) { return current(user,now)!=null; }
}

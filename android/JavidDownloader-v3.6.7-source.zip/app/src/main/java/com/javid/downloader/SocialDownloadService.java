package com.javid.downloader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Network;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.yausername.ffmpeg.FFmpeg;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;

/** Foreground, user-initiated queue: one yt-dlp job at a time, resumable partial files. */
public final class SocialDownloadService extends Service {
    public static final String WAKE="com.javid.downloader.SOCIAL_WAKE", CONTROL="com.javid.downloader.SOCIAL_CONTROL";
    public static final String EXTRA_ID="job_id";
    private static final String CHANNEL="javid_social_queue_v310";
    private static final int NOTICE=4631;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final android.os.Handler main=new android.os.Handler(android.os.Looper.getMainLooper());
    private volatile String activeId="";
    private volatile boolean started=false,closing=false;
    private final Runnable tick=new Runnable(){@Override public void run(){if(closing)return;
        poll();main.postDelayed(this,2000);
    }};

    @Override public void onCreate(){super.onCreate();SocialDownloadStore.interrupted(this);
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel(CHANNEL,"دانلود شبکه‌های اجتماعی",NotificationManager.IMPORTANCE_LOW));}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(!started){started=true;startForeground(NOTICE,notification("صف دانلود شبکه‌های اجتماعی"));main.post(tick);}
        if(intent!=null&&CONTROL.equals(intent.getAction()))checkCancelled();
        poll();return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent intent){return null;}
    private Notification notification(String description){
        PendingIntent open=PendingIntent.getActivity(this,7,new Intent(this,DownloadQueueActivity.class),
            PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Javid Downloader • موتور yt-dlp")
            .setContentText(description).setContentIntent(open).setOngoing(true).build();
    }
    private boolean online(){try{ConnectivityManager cm=getSystemService(ConnectivityManager.class);
        Network network=cm==null?null:cm.getActiveNetwork();
        NetworkCapabilities c=network==null?null:cm.getNetworkCapabilities(network);
        return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }catch(Exception e){return false;}}
    private void checkCancelled(){String id=activeId;if(id.isEmpty())return;
        SocialDownloadStore.Job j=SocialDownloadStore.get(this,id);
        if(j==null||!SocialDownloadStore.RUNNING.equals(j.state)){
            try{YoutubeDL.getInstance().destroyProcessById(id);}catch(Exception ignored){}
        }
    }
    private synchronized void poll(){if(closing)return;checkCancelled();
        if(!activeId.isEmpty())return;
        SocialDownloadStore.Job next=SocialDownloadStore.next(this);
        if(next==null){if(!SocialDownloadStore.hasQueued(this))finish();return;}
        if(!online()){
            getSystemService(NotificationManager.class).notify(NOTICE,notification("اتصال اینترنت قطع است؛ صف ذخیره شده"));
            // Android imposes a limit on dataSync foreground service runtime.
            finish();return;
        }
        activeId=next.id;
        SocialDownloadStore.update(this,next.id,j->{j.state=SocialDownloadStore.RUNNING;j.info="در حال آماده‌سازی موتور";});
        worker.execute(()->runJob(next.id));
    }
    private synchronized void finish(){if(closing)return;closing=true;main.removeCallbacks(tick);
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    private boolean interrupted(String id){SocialDownloadStore.Job j=SocialDownloadStore.get(this,id);
        return j==null||!SocialDownloadStore.RUNNING.equals(j.state);
    }
    private void runJob(String id){try{
        YoutubeDL.getInstance().init(getApplicationContext());FFmpeg.getInstance().init(getApplicationContext());
        if(interrupted(id))return;
        transfer(id);
    }catch(Exception error){
        SocialDownloadStore.Job j=SocialDownloadStore.get(this,id);
        if(j!=null&&SocialDownloadStore.RUNNING.equals(j.state)){
            String reason=safeError(error);String lower=reason.toLowerCase(Locale.ROOT);
            boolean permanent=lower.contains("http error 403")||lower.contains("http error 401")
                ||lower.contains("login")||lower.contains("private")||lower.contains("copyright")
                ||lower.contains("drm")||lower.contains("not available")||lower.contains("unsupported url")
                ||lower.contains("http error 429")||lower.contains("sign in");
            int count=j.attempts+1;
            SocialDownloadStore.update(this,id,x->{x.attempts=count;x.info=reason;
                if(!permanent&&count<3&&online()){x.state=SocialDownloadStore.QUEUED;
                    x.retryAt=System.currentTimeMillis()+(count==1?15_000L:60_000L);
                }else{x.state=SocialDownloadStore.FAILED;x.retryAt=0;}
            });
        }
    }finally{SocialDownloadStore.Job last=SocialDownloadStore.get(this,id);
        if(last!=null&&(SocialDownloadStore.DONE.equals(last.state)||SocialDownloadStore.CANCELLED.equals(last.state)))
            SocialDownloadStore.deleteFiles(this,id);
        activeId="";main.post(this::poll);
    }}
    private static String safeError(Exception e){String value=e.getMessage();if(value==null||value.trim().isEmpty())return "خطای موتور دانلود";
        value=value.replaceAll("https?://\\S+","[link]").replaceAll("(?i)(cookie|authorization|password|token)\\S*", "[redacted]");
        return value.length()>150?value.substring(0,150):value;
    }
    private void transfer(String id) throws Exception{
        SocialDownloadStore.Job job=SocialDownloadStore.get(this,id);if(job==null||interrupted(id))return;
        File folder=SocialDownloadStore.folder(this,id);
        if(!folder.isDirectory()&&!folder.mkdirs())throw new Exception("فضای موقت برای دانلود موجود نیست");
        YoutubeDLRequest r=new YoutubeDLRequest(job.link);
        r.addOption("--no-playlist");r.addOption("--continue");r.addOption("--part");
        r.addOption("--no-mtime");r.addOption("--retries","3");
        r.addOption("-o",new File(folder,"%(title).110B [%(id)s].%(ext)s").getAbsolutePath());
        if(job.quality==5){r.addOption("-x");r.addOption("--audio-format","mp3");r.addOption("--audio-quality","0");}
        else if(job.quality==0){r.addOption("-f","bv*+ba/b");r.addOption("--merge-output-format","mp4");}
        else {int h=job.quality==1?1080:job.quality==2?720:job.quality==3?480:360;
            r.addOption("-f","bv*[height<="+h+"]+ba/bv*[height<="+h+"]/b[height<="+h+"]/best[height<="+h+"]");
            r.addOption("--merge-output-format","mp4");
        }
        final long[] last={0};Function3<Float,Long,String,Unit> progress=(p,eta,output)->{
            if(interrupted(id)){try{YoutubeDL.getInstance().destroyProcessById(id);}catch(Exception ignored){}return Unit.INSTANCE;}
            long now=System.currentTimeMillis();if(now-last[0]>1100||p>=100){last[0]=now;
                int percent=Math.max(0,Math.min(100,p.intValue()));
                SocialDownloadStore.update(this,id,j->{if(SocialDownloadStore.RUNNING.equals(j.state)){
                    j.percent=percent;j.info=eta!=null&&eta>=0?"زمان باقی‌مانده: "+eta+" ثانیه":"در حال دریافت رسانه";
                }});
                getSystemService(NotificationManager.class).notify(NOTICE,notification("دانلود شبکه اجتماعی: "+percent+"٪"));
            }return Unit.INSTANCE;
        };
        try{YoutubeDL.getInstance().execute(r,id,progress);}
        catch(Exception first){
            // Format selector may be unavailable on sites which report no height.
            String m=String.valueOf(first.getMessage()).toLowerCase(Locale.ROOT);
            if(job.quality==0||job.quality==5||interrupted(id)||!(m.contains("requested format")||m.contains("no video formats")))throw first;
            YoutubeDLRequest fallback=new YoutubeDLRequest(job.link);
            fallback.addOption("--no-playlist");fallback.addOption("--continue");fallback.addOption("--part");
            fallback.addOption("--no-mtime");fallback.addOption("-o",new File(folder,"%(title).110B [%(id)s].%(ext)s").getAbsolutePath());
            fallback.addOption("-f","b/bv*+ba");fallback.addOption("--merge-output-format","mp4");
            YoutubeDL.getInstance().execute(fallback,id,progress);
        }
        if(interrupted(id))return;
        File[] completed=folder.listFiles(f->f.isFile()&&!f.getName().endsWith(".part")&&
            !f.getName().endsWith(".ytdl")&&!f.getName().endsWith(".json")&&
            !f.getName().endsWith(".webp")&&!f.getName().endsWith(".description")&&
            !f.getName().endsWith(".temp")&&!f.getName().endsWith(".jpg"));
        if(completed==null||completed.length==0)throw new Exception("فایل خروجی قابل انتشار پیدا نشد");
        Arrays.sort(completed,Comparator.comparingLong(File::lastModified).reversed());
        File file=completed[0];Uri media=publish(file);
        SocialDownloadStore.update(this,id,j->{j.state=SocialDownloadStore.DONE;j.uri=media.toString();
            j.fileName=file.getName();j.percent=100;j.info="در Downloads/JavidDownloader ذخیره شد";});
    }
    private Uri publish(File source) throws Exception{
        String name=source.getName(),ext="";
        int n=name.lastIndexOf('.');if(n>=0)ext=name.substring(n+1).toLowerCase(Locale.ROOT);
        String mime=ext.equals("mp3")?"audio/mpeg":ext.equals("m4a")?"audio/mp4":
            ext.equals("webm")?"video/webm":ext.equals("mkv")?"video/x-matroska":"video/mp4";
        ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/JavidDownloader");
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri out=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
        if(out==null)throw new Exception("عدم دسترسی به پوشه دانلود");
        boolean success=false;try(InputStream in=new FileInputStream(source);
                                  OutputStream dst=getContentResolver().openOutputStream(out)){
            if(dst==null)throw new Exception("عدم دسترسی به ذخیره فایل");
            byte[] buffer=new byte[128*1024];int k;while((k=in.read(buffer))!=-1)dst.write(buffer,0,k);
            success=true;
        }finally{if(!success)getContentResolver().delete(out,null,null);}
        values.clear();values.put(MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(out,values,null,null);return out;
    }
    @Override public void onDestroy(){closing=true;main.removeCallbacks(tick);
        String id=activeId;
        if(!id.isEmpty()){
            try{YoutubeDL.getInstance().destroyProcessById(id);}catch(Exception ignored){}
        }
        worker.shutdownNow();super.onDestroy();}
}

package com.javid.downloader;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Read-only owner-facing health report. Never includes token or a Telegram URL. */
final class BotRecoveryDiagnostics {
    private BotRecoveryDiagnostics() { }

    static boolean validatedNetwork(Context c) {
        try {
            ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm==null) return false;
            Network network=cm.getActiveNetwork();
            NetworkCapabilities caps=network==null?null:cm.getNetworkCapabilities(network);
            return caps!=null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Exception ignored) { return false; }
    }

    static BotRecoveryAdvisor.Problem problem(Context c) {
        SharedPreferences prefs=c.getSharedPreferences(TelegramBotService.PREFS,Context.MODE_PRIVATE);
        return BotRecoveryAdvisor.assess(prefs.getBoolean(TelegramBotService.PREF_DESIRED,false),
            BotSecrets.hasToken(c),prefs.getString("telegram_error_category",""),
            prefs.getLong("service_heartbeat",0L),System.currentTimeMillis(),validatedNetwork(c));
    }

    private static String time(long ms) {
        return ms<=0?"ثبت نشده":new SimpleDateFormat("yyyy/MM/dd HH:mm:ss",Locale.US).format(new Date(ms));
    }

    static String report(Context c) {
        SharedPreferences prefs=c.getSharedPreferences(TelegramBotService.PREFS,Context.MODE_PRIVATE);
        BotRecoveryAdvisor.Problem state=problem(c);
        long retryAfter=prefs.getLong("bot_retry_at",0L);
        long now=System.currentTimeMillis();
        StringBuilder s=new StringBuilder();
        s.append("🛠️ عیب‌یاب Javid AI 3.3 (آفلاین)\n")
         .append("وضعیت: ").append(BotRecoveryAdvisor.explanation(state)).append('\n')
         .append("آخرین فعالیت سرویس: ").append(time(prefs.getLong("service_heartbeat",0L))).append('\n')
         .append("آخرین ارتباط موفق: ").append(time(prefs.getLong("last_telegram_poll_ok",0L))).append('\n')
         .append("خطاهای متوالی: ").append(prefs.getInt("telegram_consecutive_failures",0)).append('\n')
         .append("آخرین تلاش اتصال مجدد: ").append(time(prefs.getLong("bot_retry_started_at",0L))).append('\n');
        if (retryAfter>now && retryAfter-now < 900_000L)
            s.append("زمان تقریبی تلاش بعدی: ").append((retryAfter-now+999L)/1000L).append(" ثانیه\n");
        else s.append("تلاش بعدی: زمان‌بندی فعالی ثبت نشده\n");
        s.append("آخرین بازگشت اینترنت: ").append(time(prefs.getLong("bot_network_restored_at",0L))).append('\n')
         .append("تعداد درخواست‌های بازیابی دستی: ").append(prefs.getInt("bot_recovery_attempts",0)).append('\n')
         .append("راه‌اندازی خودکار: ").append(prefs.getBoolean(TelegramBotService.PREF_AUTO_RESUME,true)?"روشن":"خاموش").append('\n')
         .append("⚠️ بازیابی خودکار محدود به خطاهای موقت است؛ خطای 401/409 یا بات خاموش تغییر اجباری نمی‌کند.\n")
         .append("این گزارش رمز، توکن، URL خصوصی یا مشخصات کاربران را نمایش نمی‌دهد.");
        return s.toString();
    }
}

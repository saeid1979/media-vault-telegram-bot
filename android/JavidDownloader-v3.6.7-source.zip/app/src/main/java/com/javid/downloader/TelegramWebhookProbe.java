package com.javid.downloader;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Read-only, owner-triggered Webhook diagnostic for Telegram long-polling conflicts.
 * Never displays webhook URL, IP address, token, chat IDs, or Telegram error text.
 * Does not call deleteWebhook or getUpdates and cannot change Telegram configuration.
 */
final class TelegramWebhookProbe {
    private TelegramWebhookProbe() { }

    static String check(Context context) {
        if (!BotSecrets.hasToken(context)) {
            return "⚠️ ابتدا توکن بات را روی همین گوشی ثبت کن.";
        }
        HttpURLConnection connection = null;
        try {
            final String token = BotSecrets.read(context);
            if (token == null || !token.matches("[0-9]{5,15}:[A-Za-z0-9_-]{30,}")) {
                return "⚠️ توکن ثبت‌شده معتبر به نظر نمی‌رسد.";
            }
            connection = (HttpURLConnection) new URL(
                "https://api.telegram.org/bot" + token + "/getWebhookInfo").openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setRequestProperty("Accept", "application/json");
            int status = connection.getResponseCode();
            if (status == 401 || status == 403) {
                return "❌ تلگرام توکن را نپذیرفت (" + status + ").";
            }
            if (status == 429) {
                return "⏳ تلگرام موقتاً تعداد درخواست‌ها را محدود کرده است.";
            }
            if (status != 200) {
                return "⚠️ دریافت وضعیت Webhook ممکن نشد (HTTP " + status + ").";
            }
            final byte[] buffer = new byte[1024];
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                int count;
                // Telegram's webhook metadata is small; do not consume unbounded data.
                while (output.size() < 8192 && (count = input.read(buffer)) != -1) {
                    output.write(buffer, 0, Math.min(count, 8192 - output.size()));
                }
                JSONObject root = new JSONObject(
                    new String(output.toByteArray(), StandardCharsets.UTF_8));
                if (!root.optBoolean("ok", false)) {
                    return "⚠️ پاسخ معتبر از تلگرام دریافت نشد.";
                }
                JSONObject details = root.optJSONObject("result");
                if (details == null) {
                    return "⚠️ اطلاعات Webhook در پاسخ موجود نیست.";
                }
                // URL is read for boolean presence only and NEVER returned or persisted.
                boolean configured = !details.optString("url", "").isEmpty();
                int pending = Math.max(0, details.optInt("pending_update_count", 0));
                String pendingText = pending > 99999 ? ">99999" : String.valueOf(pending);
                if (configured) {
                    return "⚠️ Webhook روی بات فعال است. این گوشی با روش getUpdates " +
                        "نمی‌تواند همزمان پیام‌ها را دریافت کند.\n" +
                        "پیام‌های منتظر در تلگرام: " + pendingText + "\n" +
                        "برای جابه‌جایی بات، ابتدا محل اجرای قبلی را بررسی کن. " +
                        "این تست هیچ تنظیمی را تغییر نمی‌دهد.";
                }
                return "✅ Webhook فعال نیست؛ دریافت با getUpdates امکان‌پذیر است.\n" +
                    "پیام‌های منتظر در تلگرام: " + pendingText + "\n" +
                    "اگر خطای 409 مشاهده می‌کنی، ممکن است بات با همین توکن " +
                    "در گوشی یا سرور دیگری هم روشن باشد. این تست چیزی را حذف یا متوقف نمی‌کند.";
            }
        } catch (Exception ignored) {
            // Exception messages can contain a URL embedding the token.
            return "📴 بررسی Webhook انجام نشد؛ ارتباط اینترنت یا دسترسی به تلگرام را بررسی کن.";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}

package com.javid.downloader;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** One shared, explicit allowlist for ALL football feeds.
 * No guessed competition IDs or "all Iran/all world" shortcuts.
 * Source titles and region codes may change; unknowns are skipped.
 */
final class FootballCompetitionScope {
    private FootballCompetitionScope() {}
    private static final Set<String> ESPN = new HashSet<>(Arrays.asList(
        "eng.1", "esp.1", "ger.1", "ita.1", "fra.1",
        "ned.1", "por.1", "tur.1",
        "uefa.champions", "uefa.europa", "uefa.europa.conf",
        "fifa.world", "fifa.wwc", "fifa.friendly", "fifa.friendly.w",
        "fifa.worldq", "fifa.worldq.uefa", "fifa.worldq.afc",
        "fifa.worldq.caf", "fifa.worldq.conmebol",
        "fifa.worldq.concacaf", "fifa.worldq.ofc",
        "uefa.euro", "uefa.euroq", "uefa.weuro", "uefa.nations",
        "conmebol.america", "afc.asian.cup", "caf.nations", "concacaf.gold"
    ));
    static String[] espnLeagues() { return ESPN.stream().sorted().toArray(String[]::new); }
    static boolean espn(String slug) { return ESPN.contains(slug); }
    static boolean nationalEspn(String slug) {
        return slug != null && (slug.startsWith("fifa.") || slug.equals("uefa.euro") ||
            slug.equals("uefa.euroq") || slug.equals("uefa.weuro") ||
            slug.equals("uefa.nations") || slug.equals("conmebol.america") ||
            slug.equals("afc.asian.cup") || slug.equals("caf.nations") ||
            slug.equals("concacaf.gold"));
    }
    private static String norm(String v) {
        return v == null ? "" : v.toLowerCase(Locale.ROOT).replace('–','-')
            .replace('—','-').replaceAll("\\s+"," ").trim();
    }
    private static boolean one(String s,String... terms){
        for(String term:terms) if(s.contains(term)) return true;
        return false;
    }
    private static boolean excluded(String name) {
        return one(name,"u-17","u17","u-19","u19","u-20","u20","u-21","u21",
            "under 17","under-17","under 19","under-19","under 20","under-20",
            "youth","reserve","amateur","academy","futsal","club friendly",
            "club world cup","club friendlies","women's champions league","womens champions league");
    }
    static boolean iranDomestic(String name) {
        String n=norm(name);
        if(excluded(n)) return false;
        return one(n,"persian gulf pro league","persian gulf league","persian gulf",
            "iran pro league","iranian pro league","iran premier league",
            "pro league iran", "azadegan", "iran 1st division", "iran first division",
            "hazfi", "iran cup", "iran super cup", "iranian super cup",
            "لیگ برتر", "لیگ آزادگان", "جام حذفی", "سوپرجام ایران");
    }
    static boolean europeClub(String title,String country,String regionCode) {
        String n=norm(title), c=norm(country),r=norm(regionCode);
        if(excluded(n))return false;
        // UEFA club competitions only; ignore similarly named leagues on other continents.
        if(one(n,"uefa champions league","uefa europa league", "uefa conference league",
                "europa conference league", "europa league", "champions league") &&
                one(c+" "+r,"international","europe","uefa","int","eur")) return true;
        if(one(c+" "+r,"england"," eng") && n.equals("premier league"))return true;
        if(one(c+" "+r,"spain"," esp") && one(n,"laliga","la liga","primera division"))return true;
        if(one(c+" "+r,"germany"," ger") && (n.equals("bundesliga") || n.equals("1. bundesliga")))return true;
        if(one(c+" "+r,"italy"," ita") && n.equals("serie a"))return true;
        if(one(c+" "+r,"france"," fra") && (n.equals("ligue 1")||n.startsWith("ligue 1 ")))return true;
        if(one(c+" "+r,"netherlands"," ned") && n.equals("eredivisie"))return true;
        if(one(c+" "+r,"portugal"," por") && one(n,"primeira liga","liga portugal","liga nos"))return true;
        if(one(c+" "+r,"turkey","turkiye"," tur") && one(n,"super lig","süper lig"))return true;
        return false;
    }
    static boolean nationalTournament(String title) {
        String n=norm(title);
        if(excluded(n))return false;
        return one(n,"fifa world cup", "world cup", "world championship", "world cup qualification",
            "world cup qualifying", "world cup qualifiers", "european championship",
            "uefa euro", "uefa nations league", "nations league", "copa america",
            "copa américa", "asian cup", "africa cup of nations", "afcon", "gold cup",
            "international friendly", "international friendlies", "friendly international",
            "national team friendly", "national teams friendly", "international friendly games",
            "world cup qualification",
            "مقدماتی جام جهانی", "جام ملت‌های آسیا", "جام جهانی");
    }
    static boolean sofa(String name,String country,String region) {
        String c=norm(country), r=norm(region);
        if(c.equals("iran")||r.equals("iran")) return iranDomestic(name);
        return europeClub(name,c,r)||nationalTournament(name);
    }
    static boolean fotmob(String name,String code) {
        String c=norm(code),n=norm(name);
        if(c.equals("irn") || c.equals("iran"))return iranDomestic(name);
        if(europeClub(name,"",c))return true;
        return nationalTournament(n);
    }
    static boolean iranNational(String home,String away) {
        return isIranNational(home)||isIranNational(away);
    }
    private static boolean isIranNational(String s) {
        String n=norm(s);
        return n.equals("iran") || n.equals("iran women") || n.equals("iran national team") ||
            n.equals("ایران") || n.equals("تیم ملی ایران");
    }
}

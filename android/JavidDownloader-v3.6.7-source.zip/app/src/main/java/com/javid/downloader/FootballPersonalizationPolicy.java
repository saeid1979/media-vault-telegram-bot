package com.javid.downloader;

/** Explicit owner-independent per-recipient notification preferences.
 * Unknown incident types are suppressed, never turned on implicitly. */
final class FootballPersonalizationPolicy {
    static final String GOAL="GOAL", YELLOW="YELLOW", RED="RED";
    static final String FINAL="FINAL", NIGHTLY="NIGHTLY";
    static final String LINEUP="LINEUP", KICKOFF="KICKOFF", HALFTIME="HALFTIME";
    private FootballPersonalizationPolicy() {}
    static String column(String kind) {
        if(kind==null)return "";
        switch(kind) {
            case GOAL:return "goal";
            case YELLOW:return "yellow";
            case RED:return "red";
            case FINAL:return "final_report";
            case LINEUP:return "lineup";
            case KICKOFF:return "kickoff";
            case HALFTIME:return "halftime";
            case NIGHTLY:return "nightly";
            default:return "";
        }
    }
    static String label(String kind) {
        if(kind==null)return "";
        switch(kind) {
            case GOAL:return "⚽ گل";
            case YELLOW:return "🟨 کارت زرد";
            case RED:return "🟥 کارت قرمز";
            case FINAL:return "📊 گزارش پایان بازی";
            case LINEUP:return "📋 ترکیب اولیه";
            case KICKOFF:return "▶️ شروع مسابقه";
            case HALFTIME:return "⏸ گزارش نیمه اول";
            case NIGHTLY:return "🕚 نتایج ساعت ۲۳";
            default:return "";
        }
    }
    static String fromIncident(String kind) {
        if("RED".equals(kind))return RED;
        if("YELLOW".equals(kind))return YELLOW;
        return "";
    }
}

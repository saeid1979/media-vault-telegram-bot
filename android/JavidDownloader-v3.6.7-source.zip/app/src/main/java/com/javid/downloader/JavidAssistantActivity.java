package com.javid.downloader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import java.util.Locale;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Javid AI v3.5.0: offline command assistant for the phone owner.
 * All natural-language interpretation is deterministic and on-device.
 * No external AI APIs, no logging of prompts, no token or user identity disclosure.
 */
public final class JavidAssistantActivity extends Activity {
    private final int NAVY = Color.rgb(16, 44, 53);
    private final int INK = Color.rgb(31, 47, 57);
    private final int SKY = Color.rgb(225, 239, 251);
    private final int TEAL = Color.rgb(0, 142, 126);
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private ScrollView feedScroll;
    private LinearLayout messages;
    private EditText input;
    private boolean testingNetwork = false;
    private static final int VOICE_REQUEST = 350;
    private static final String VOICE_PREFS = "javid_assistant_voice";

    private int dp(int n) { return (int) (getResources().getDisplayMetrics().density * n + .5f); }

    private GradientDrawable panel(int rgb) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(rgb); shape.setCornerRadius(dp(15)); return shape;
    }
    private TextView text(String s, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(INK); v.setTextSize(size);
        v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }
    private Button chip(String s, Runnable action) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(s); b.setTextSize(12);
        b.setTextColor(INK); b.setBackground(panel(SKY)); b.setMinHeight(0);
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(Color.rgb(248, 250, 253));
        main.setPadding(dp(12), dp(12), dp(12), dp(12));
        setContentView(main);
        TextView title = text("🧠 Javid AI • دستیار بات", 20, true);
        main.addView(title);
        TextView notice = text("نسخه 3.6 • فرمان متنی آفلاین؛ دکمه گفتار از سرویس تشخیص گفتار گوشی استفاده می‌کند که ممکن است اینترنت و پردازش ابری نیاز داشته باشد.", 11, false);
        notice.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams noticeParams = new LinearLayout.LayoutParams(-1,-2);
        noticeParams.topMargin=dp(5);noticeParams.bottomMargin=dp(8);
        main.addView(notice, noticeParams);
        feedScroll = new ScrollView(this);
        feedScroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(dp(4),dp(4),dp(4),dp(8));
        feedScroll.addView(messages);
        main.addView(feedScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout suggestions = new LinearLayout(this);
        suggestions.setOrientation(LinearLayout.HORIZONTAL);
        suggestions.addView(chip("وضعیت بات", () -> send("وضعیت بات")), new LinearLayout.LayoutParams(0,dp(46),1));
        suggestions.addView(chip("آمار امروز", () -> send("آمار امروز")), new LinearLayout.LayoutParams(0,dp(46),1));
        suggestions.addView(chip("مشکلات", () -> send("مشکل بات چیست")), new LinearLayout.LayoutParams(0,dp(46),1));
        main.addView(suggestions);
        LinearLayout recoveryRow=new LinearLayout(this);
        recoveryRow.setOrientation(LinearLayout.HORIZONTAL);
        recoveryRow.addView(chip("🛠 عیب‌یابی کامل", () -> bubble(BotRecoveryDiagnostics.report(this),false)),
            new LinearLayout.LayoutParams(0,dp(47),1));
        recoveryRow.addView(chip("♻️ بازیابی امن", () -> send("بات را بازیابی کن")),
            new LinearLayout.LayoutParams(0,dp(47),1));
        main.addView(recoveryRow);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        input=new EditText(this);
        input.setTextDirection(View.TEXT_DIRECTION_RTL);
        input.setHint("مثلاً: چند کاربر دارم؟");
        input.setSingleLine(false); input.setMaxLines(2); input.setTextSize(15);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        row.addView(input,new LinearLayout.LayoutParams(0,dp(60),1));
        Button voiceButton = chip("🎙️", this::requestVoice);
        row.addView(voiceButton,new LinearLayout.LayoutParams(dp(55),dp(52)));
        Button sendButton = chip("ارسال ←", () -> {
            String value=input.getText().toString();input.setText("");send(value);
        });
        row.addView(sendButton,new LinearLayout.LayoutParams(dp(88),dp(52)));
        main.addView(row);
        bubble("سلام! درباره وضعیت بات، تعداد کاربران، آمار دانلودها، خطاها، مدیریت اعضا یا صف دانلود بپرس. می‌توانی روشن/خاموش کردن بات را هم درخواست کنی؛ پیش از اجرا تأیید لازم است.",false);
    }

    /** Recognition is opt-in: Android may route microphone audio to a provider. */
    private void requestVoice() {
        if (!getSharedPreferences(VOICE_PREFS,MODE_PRIVATE).getBoolean("consented",false)) {
            new AlertDialog.Builder(this)
                .setTitle("اجازه استفاده از تشخیص گفتار")
                .setMessage("با فشردن میکروفون، تشخیص گفتار سیستم گوشی فعال می‌شود. بسته به سرویس نصب‌شده ممکن است صدای شما برای پردازش به ارائه‌دهنده آن سرویس ارسال شود و اینترنت لازم باشد. متن شناسایی‌شده فقط در کادر قرار می‌گیرد و تا وقتی «ارسال» را نزنید اجرا نمی‌شود. ادامه می‌دهید؟")
                .setNegativeButton("انصراف",(dialog,which)->{})
                .setPositiveButton("قبول",(dialog,which)->{
                    getSharedPreferences(VOICE_PREFS,MODE_PRIVATE).edit()
                        .putBoolean("consented",true).apply();
                    launchVoice();
                }).show();
            return;
        }
        launchVoice();
    }
    private void launchVoice() {
        try {
            Intent listen = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            listen.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            listen.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR");
            listen.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
            listen.putExtra(RecognizerIntent.EXTRA_PROMPT,"فرمان فارسی را بگو");
            startActivityForResult(listen,VOICE_REQUEST);
        } catch (ActivityNotFoundException unavailable) {
            bubble("سرویس تشخیص گفتار در این گوشی نصب نیست. از ورودی متنی استفاده کن.",false);
        } catch (Exception blocked) {
            bubble("دسترسی به تشخیص گفتار در این دستگاه ممکن نشد.",false);
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode!=VOICE_REQUEST || resultCode!=RESULT_OK || data==null) return;
        ArrayList<String> result=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (result!=null && !result.isEmpty() && result.get(0)!=null) {
            input.setText(result.get(0));
            input.setSelection(input.length());
            bubble("🎙️ متن گفتار در کادر قرار گرفت؛ بررسی کن و سپس خودت «ارسال» را بزن.",false);
        }
    }

    private void bubble(String value,boolean owner) {
        if (isFinishing() || isDestroyed()) return;
        TextView view = text(value, 14, false);
        view.setTextIsSelectable(true);
        view.setPadding(dp(14),dp(12),dp(14),dp(12));
        view.setBackground(panel(owner? Color.rgb(218,243,235):Color.WHITE));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(owner?dp(42):0,dp(5),owner?0:dp(24),dp(5));
        messages.addView(view,p);
        feedScroll.post(() -> feedScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void send(String value) {
        if (value == null || value.trim().isEmpty()) return;
        if (value.length() > 700) { bubble("لطفاً پرسش کوتاه‌تر، تا ۷۰۰ نویسه بنویس.",false);return; }
        bubble(value.trim(),true);
        JavidAssistantRouter.Intent choice = JavidAssistantRouter.detect(value);
        switch (choice) {
            case HELP:
                bubble("می‌توانی بپرسی: «وضعیت بات»، «چند کاربر دارم؟»، «آمار امروز»، «مشکل بات چیست؟»، «وبهوک را بررسی کن»، «اتصال تلگرام»، «صف دانلود»، «مدیریت کاربران»، «روشن کن بات»، «بات را خاموش کن» یا «بات را بازیابی کن». فرامین حساس نیاز به تأیید دارند.",false);
                break;
            case BOT_STATUS:
                bubble(BotHealthSnapshot.report(this),false);break;
            case BOT_START:
                confirmPower(true);break;
            case BOT_STOP:
                confirmPower(false);break;
            case TELEGRAM_TEST:
                networkProbe(false);break;
            case WEBHOOK_TEST:
                networkProbe(true);break;
            case DIAGNOSE:
                bubble(BotRecoveryDiagnostics.report(this),false);break;
            case RECOVER:
                proposeSafeRecovery();break;
            case USERS:
                try (BotUserStore store=new BotUserStore(this)) {
                    bubble("👥 اعضای ثبت‌شده: " + store.count() + "\nکاربران VIP فعال: " + store.countVip() +
                        "\nاطلاعات فردی کاربران در گفتگو نمایش داده نمی‌شود.",false);
                } catch (Exception e) {bubble("آمار کاربران در دسترس نیست.",false);}
                break;
            case USER_MANAGER:
                openPage(UserManagerActivity.class,"مدیریت و ویرایش کاربران از طریق صفحه اختصاصی انجام می‌شود.");break;
            case STATS:
                try (BotStatsStore stats=new BotStatsStore(this)) {
                    List<BotStatsStore.Day> days=stats.lastDays(1);
                    BotStatsStore.Day d=days.get(0);
                    bubble("📊 آمار امروز (محلی):\nدانلود موفق: "+d.downloadOk+
                        "\nدانلود ناموفق: "+d.downloadFailed+
                        "\nپیام ارسال‌شده: "+d.messageOk+
                        "\nخطاهای ارسال: "+d.messageFailed+
                        "\nاعداد فقط از فعالیت ثبت‌شده روی همین گوشی محاسبه می‌شوند.",false);
                }catch(Exception e){bubble("در حال حاضر دریافت آمار ممکن نیست.",false);}
                break;
            case DASHBOARD:
                openPage(DashboardActivity.class,"داشبورد مدیریتی باز شد.");break;
            case DOWNLOADS:
                openPage(DownloadQueueActivity.class,"مدیریت صف دانلود باز شد.");break;
            default:
                bubble("این درخواست را هنوز نمی‌شناسم. «راهنما» را بنویس تا فرمان‌های پشتیبانی‌شده را ببینی. این نسخه بدون اتصال به سرویس هوش مصنوعی خارجی کار می‌کند.",false);
        }
    }

    private void openPage(Class<? extends Activity> page,String note) {
        bubble(note,false);
        startActivity(new Intent(this,page));
    }
    private void networkProbe(boolean webhook) {
        if (testingNetwork) { bubble("تست قبلی هنوز تمام نشده است.",false);return; }
        testingNetwork=true;
        bubble("در حال بررسی مستقیم Telegram API (فقط با درخواست تو)...",false);
        bg.execute(() -> {
            String answer = webhook ? TelegramWebhookProbe.check(getApplicationContext()) :
                TelegramConnectionProbe.check(getApplicationContext());
            runOnUiThread(() -> { testingNetwork=false; bubble(answer,false); });
        });
    }
    private void diagnose() {
        SharedPreferences p=getSharedPreferences(TelegramBotService.PREFS, Context.MODE_PRIVATE);
        boolean desired=p.getBoolean(TelegramBotService.PREF_DESIRED,false);
        String error=p.getString("telegram_error_category","");
        int failures=p.getInt("telegram_consecutive_failures",0);
        long heartbeat=p.getLong("service_heartbeat",0);
        String hint;
        if (!BotSecrets.hasToken(this)) hint="توکن بات ثبت نشده است؛ از بخش بات تلگرام توکن معتبر را ذخیره کن.";
        else if (!desired) hint="بات به درخواست مالک خاموش است؛ در صورت نیاز با تأیید روشنش کن.";
        else if ("409".equals(error)) hint="احتمال اجرای هم‌زمان بات در دستگاه دیگر وجود دارد؛ Webhook را جداگانه بررسی کن.";
        else if ("401".equals(error)) hint="تلگرام توکن بات را نپذیرفت؛ توکن را در بخش تنظیمات بررسی کن.";
        else if ("network".equals(error)) hint="ارتباط شبکه برقرار نشده؛ وضعیت اینترنت و محدودیت پس‌زمینه گوشی را بررسی کن.";
        else if (heartbeat==0 || System.currentTimeMillis()-heartbeat>90000L)
            hint="ضربان سرویس تازه نیست؛ ممکن است سیستم اجرای پس‌زمینه را محدود کرده باشد.";
        else hint="سرویس اخیراً فعال بوده است. برای بررسی اتصال واقعی، «اتصال تلگرام» را امتحان کن.";
        bubble("🔎 بررسی محلی:\nخطاهای متوالی: "+failures+"\n"+hint+
            "\n\nاین تشخیص براساس گزارش داخلی برنامه است و هیچ تنظیمی را خودکار تغییر نمی‌دهد.",false);
    }
    /** Owner-confirmed, rate-limited recovery: no webhook removal, no forced stop. */
    private void proposeSafeRecovery() {
        BotRecoveryAdvisor.Problem problem=BotRecoveryDiagnostics.problem(this);
        SharedPreferences prefs=getSharedPreferences(TelegramBotService.PREFS,MODE_PRIVATE);
        long now=System.currentTimeMillis();
        long previous=prefs.getLong("bot_recovery_last_attempt",0L);
        if (!BotRecoveryAdvisor.canRequestSafeResume(problem,previous,now)) {
            bubble("بازیابی خودکار امن در این وضعیت لازم یا مجاز نیست.\n" +
                BotRecoveryAdvisor.explanation(problem) +
                "\nدر صورت نیاز، تست شبکه/وبهوک را دستی انجام بده.",false);
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("تأیید درخواست بازیابی بات")
            .setMessage("ضربان سرویس تازه نیست. یک درخواست راه‌اندازی سرویس می‌فرستم؛ " +
                "اطلاعات، توکن، وبهوک و تنظیمات دیگر تغییر نمی‌کنند. " +
                "اندروید ممکن است این درخواست را محدود کند. ادامه می‌دهی؟")
            .setNegativeButton("انصراف",(d,w)->bubble("درخواست بازیابی لغو شد.",false))
            .setPositiveButton("تأیید بازیابی",(d,w)->safeResume())
            .show();
    }

    private void safeResume() {
        SharedPreferences p=getSharedPreferences(TelegramBotService.PREFS,MODE_PRIVATE);
        long now=System.currentTimeMillis();
        if (!BotRecoveryAdvisor.canRequestSafeResume(BotRecoveryDiagnostics.problem(this),
            p.getLong("bot_recovery_last_attempt",0L),now)) {
            bubble("وضعیت تغییر کرده یا محدودیت سه‌دقیقه‌ای برقرار است.",false);return;
        }
        try {
            android.content.Intent service=new android.content.Intent(this,TelegramBotService.class);
            service.setAction(TelegramBotService.ACTION_RESUME);
            startForegroundService(service);
            p.edit().putLong("bot_recovery_last_attempt",now)
                .putInt("bot_recovery_attempts",Math.max(0,p.getInt("bot_recovery_attempts",0))+1)
                .apply();
            bubble("درخواست بازیابی سرویس ثبت شد. اتصال واقعی را از «وضعیت بات» یا «تست اتصال تلگرام» بررسی کن.",false);
        } catch (Exception restricted) {
            bubble("اندروید راه‌اندازی سرویس را محدود کرد. برنامه را باز نگه دار و محدودیت باتری را بررسی کن.",false);
        }
    }

    private void confirmPower(boolean enable) {
        new AlertDialog.Builder(this)
            .setTitle(enable?"تأیید روشن‌کردن بات":"تأیید خاموش‌کردن بات")
            .setMessage(enable?"بات تلگرام روی این گوشی اجرا شود؟ ممکن است برای اجرا به مجوز اعلان نیاز باشد.":
                "بات روی این گوشی متوقف شود؟ تا روشن‌شدن مجدد، پیام‌های دریافتی پردازش نخواهند شد.")
            .setNegativeButton("انصراف",(dialog,which)->bubble("عملیات لغو شد.",false))
            .setPositiveButton("تأیید",(dialog,which)->changePower(enable))
            .show();
    }
    private void changePower(boolean enable) {
        if (enable && !BotSecrets.hasToken(this)) {bubble("ابتدا توکن بات را از صفحه بات تلگرام ذخیره کن.",false);return;}
        try {
            Intent intent = new Intent(this,TelegramBotService.class);
            intent.setAction(enable?TelegramBotService.ACTION_START:TelegramBotService.ACTION_STOP);
            if (enable) startForegroundService(intent);
            else {
                getSharedPreferences(TelegramBotService.PREFS,MODE_PRIVATE).edit()
                    .putBoolean(TelegramBotService.PREF_DESIRED,false).apply();
                startService(intent);
            }
            bubble(enable?"درخواست راه‌اندازی بات ثبت شد؛ برای اطمینان وضعیت را بررسی کن.":
                "درخواست توقف بات ثبت شد.",false);
        }catch(Exception e){bubble("این عملیات توسط اندروید مجاز نشد؛ از صفحه مدیریت بات اقدام کن.",false);}
    }
    @Override protected void onDestroy() { bg.shutdownNow();super.onDestroy(); }
}

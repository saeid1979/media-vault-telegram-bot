package com.javid.downloader;

import java.util.concurrent.TimeUnit;

/** Controls one-time delivery after an observed live -> final transition. */
final class FootballFinalReportPolicy {
    private FootballFinalReportPolicy() { }
    static final long MAX_REPORT_DELAY_MS = TimeUnit.HOURS.toMillis(9);

    /** Existing games only: do not spam historic finals when the bot is first installed. */
    static boolean shouldPublish(boolean hadBaseline, boolean wasFinished, boolean nowFinished,
                                 long kickoffMs, long nowMs, boolean alreadyReported) {
        return hadBaseline && !wasFinished && nowFinished && !alreadyReported &&
               kickoffMs > 0L && kickoffMs <= nowMs &&
               nowMs - kickoffMs <= MAX_REPORT_DELAY_MS;
    }

    static String safeValue(String raw) {
        if (raw == null) return "—";
        String cleaned = raw.replace('\n', ' ').replace('\r', ' ').trim();
        if (cleaned.isEmpty() || cleaned.equalsIgnoreCase("null") ||
            cleaned.equals("-") || cleaned.equals("N/A")) return "—";
        return cleaned.length() > 28 ? cleaned.substring(0, 28) : cleaned;
    }
    static boolean meaningful(String v) {
        return v != null && !safeValue(v).equals("—");
    }
}

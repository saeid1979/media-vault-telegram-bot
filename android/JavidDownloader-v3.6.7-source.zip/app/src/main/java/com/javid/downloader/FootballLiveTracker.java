package com.javid.downloader;

import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Live football results using two independent unauthenticated public data feeds:
 * ESPN scoreboards for major world competitions and Sofascore (and FotMob fallback)
 * for Iran and major leagues. Unofficial feeds can fail or change: no invented
 * score, minute or scorer is ever shown. Only the change from a verified
 * previous result can trigger a goal notification.
 */
final class FootballLiveTracker {
    static final String STATE = "football_score_state_v2";
    static final String LAST_STATUS = "football_last_status";
    static final String LAST_CHECK = "football_last_check";
    private final SharedPreferences prefs;
    FootballLiveTracker(SharedPreferences prefs) { this.prefs = prefs; }

    static final class Match {
        String id, home, away, league, source, clock = "", scorers = "";
        boolean iran, nationalTeam;
        int h = -1, a = -1, importance = 2;
        long kickoff;
        boolean live, finished, upcoming, halftime;
        boolean incidentsKnown;
        boolean scoreConflict;
        String stableKey="";
        final List<Incident> incidents=new ArrayList<>();
        String score() {
            return h >= 0 && a >= 0 ? h + "–" + a : "—";
        }
        String line() {
            return (live ? "🔴 " : finished ? "✅ " : "🕒 ") +
                league + " | " + home + " " + (upcoming?"—":score()) + " " + away +
                (clock.isEmpty() ? live ? " (زنده)" : finished ? " (پایان)" : "" : " (" + clock + ")") +
                (scorers.isEmpty() ? "" : "\n  ⚽ " + scorers);
        }
        String sourceLine() { return "منبع: " + source; }
    }
    static final class Incident {
        String id, kind, minute, player;
        boolean home;
        String message(Match match) {
            String icon="RED".equals(kind)?"🟥":"🟨";
            String label="RED".equals(kind)?"کارت قرمز":"کارت زرد";
            return icon+" "+label+" در بازی زنده\n"+match.league+"\n"+
                match.home+" "+match.score()+" "+match.away+
                (minute.isEmpty()?"":"\nدقیقه: "+minute)+
                (player.isEmpty()?"":"\nبازیکن: "+player)+
                "\nتیم: "+(home?match.home:match.away)+
                "\nمنبع: "+match.source;
        }
    }

    static final class Snapshot {
        final List<Match> games = new ArrayList<>();
        int sourcesOk, sourcesFailed;
        boolean iranCovered;
        int iranFeedsOk, iranFeedsFailed;
        int iranMatches;
        int scorerMatches;
        int scorerUnavailable;
        int mergedDuplicates, scoreConflicts, corroboratedMatches;
        int espnGames, fotmobGames, sofaGames;
        String iranError = "";
        String diagnostics() {
            return "منابع پاسخگو: " + sourcesOk + "، ناموفق: " +
                sourcesFailed + "، بازی‌های مهم: " + games.size() +
                "، لیگ ایران: " + iranMatches + " بازی" +
                "، منبع گل‌زن: " + scorerMatches + " بازی موفق / " +
                scorerUnavailable + " بدون جزئیات" +
                "، منابع ایران: " + iranFeedsOk + " پاسخگو / " + iranFeedsFailed + " ناموفق" +
                "، منابع مسابقه: ESPN " + espnGames + " / FotMob " + fotmobGames +
                " / Sofascore " + sofaGames +
                "، بازی‌های تکراری حذف‌شده: " + mergedDuplicates +
                "، تأیید دو منبعی: " + corroboratedMatches +
                "، اختلاف نتیجه (اعلان متوقف): " + scoreConflicts +
                (iranError.isEmpty() ? "" : "، آخرین خطا: " + iranError);
        }
    }

    static JSONObject getJson(String endpoint, int maxBytes) throws Exception {
        HttpURLConnection conn = (HttpURLConnection)new URL(endpoint).openConnection();
        conn.setConnectTimeout(6500);
        conn.setReadTimeout(7000);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("User-Agent", "JavidDownloaderAndroid/2.0 (football score reader)");
        conn.setRequestProperty("Accept", "application/json");
        try {
            int http=conn.getResponseCode();
            if (http != 200)
                throw new IllegalStateException("HTTP " + http + " football source unavailable");
            try (InputStream stream = conn.getInputStream();
                 ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = stream.read(buffer)) != -1) {
                    if (bytes.size() + count > maxBytes) throw new IllegalStateException("Payload too large");
                    bytes.write(buffer, 0, count);
                }
                return new JSONObject(bytes.toString("UTF-8"));
            }
        } finally { conn.disconnect(); }
    }
    private static String text(String s, int max) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() <= max ? s : s.substring(0,max);
    }
    private static String valScore(Object value) {
        if (value instanceof JSONObject) {
            JSONObject score = (JSONObject) value;
            return score.optString("displayValue", score.optString("current", ""));
        }
        return value == null ? "" : String.valueOf(value);
    }
    private static int parseScore(String v) {
        try { return Integer.parseInt(v.trim()); }
        catch (Exception ignored) { return -1; }
    }
    private static long parseInstant(String str) {
        try { return Instant.parse(str).toEpochMilli(); }
        catch (Exception ignored) { return 0; }
    }
    private static boolean recent(Match match, long now) {
        // Avoid stale historic season events; only a 40-hour window, or ongoing live games.
        return match.live || (match.kickoff > now - TimeUnit.HOURS.toMillis(
                match.iran ? 24 * 7 : 40) &&
            match.kickoff < now + TimeUnit.HOURS.toMillis(8));
    }
    private static final String[] ESPN = FootballCompetitionScope.espnLeagues();
    // Avoid repeated empty-source requests while retaining frequent polling of
    // competitions that have listed fixtures on the current match day.
    private static final Map<String,Long> quietEspnUntil = new HashMap<>();
    private static String label(String id) {
        switch (id) {
            case "uefa.champions": return "لیگ قهرمانان اروپا";
            case "uefa.europa": return "لیگ اروپا";
            case "uefa.europa.conf": return "لیگ کنفرانس اروپا";
            case "eng.1": return "لیگ برتر انگلیس";
            case "esp.1": return "لالیگا";
            case "ger.1": return "بوندس‌لیگا";
            case "ita.1": return "سری آ";
            case "fra.1": return "لیگ فرانسه";
            case "ned.1": return "اردیویسه هلند";
            case "por.1": return "لیگ پرتغال";
            case "tur.1": return "سوپرلیگ ترکیه";
            case "fifa.world": return "جام جهانی تیم‌های ملی";
            case "fifa.wwc": return "جام جهانی بانوان";
            case "fifa.friendly": case "fifa.friendly.w": return "دوستانه ملی";
            case "uefa.euro": return "جام ملت‌های اروپا";
            case "uefa.euroq": return "مقدماتی یورو";
            case "uefa.nations": return "لیگ ملت‌های اروپا";
            case "conmebol.america": return "کوپا آمریکا";
            case "afc.asian.cup": return "جام ملت‌های آسیا";
            case "caf.nations": return "جام ملت‌های آفریقا";
            case "concacaf.gold": return "گلدکاپ تیم‌های ملی";
            default: return id.startsWith("fifa.worldq")?"مقدماتی جام جهانی":id;
        }
    }

    private static void fromEspn(Snapshot snapshot, String league, JSONObject result,
                                 Map<String,Match> found, long now) {
        JSONArray events = result.optJSONArray("events");
        if (events == null) return;
        for (int i=0; i<events.length(); i++) {
            JSONObject game = events.optJSONObject(i);
            if (game == null) continue;
            JSONObject status = game.optJSONObject("status");
            JSONObject type = status == null ? null : status.optJSONObject("type");
            String state = type == null ? "" : type.optString("state", "");
            if (!"in".equals(state) && !"post".equals(state) && !"pre".equals(state)) continue;
            JSONArray comps = game.optJSONArray("competitions");
            JSONObject comp = comps == null ? null : comps.optJSONObject(0);
            JSONArray teams = comp == null ? null : comp.optJSONArray("competitors");
            if (teams == null) continue;
            Match m = new Match();
            m.id = "espn:" + league + ":" + game.optString("id","");
            if (m.id.endsWith(":")) continue;
            m.league = label(league);
            m.source = "ESPN";
            m.live = "in".equals(state);
            m.finished = "post".equals(state) && type.optBoolean("completed", true);
            m.upcoming="pre".equals(state);
            m.halftime=FootballMatchMilestones.isHalfTime(
                type==null?"":type.optString("name","")) ||
                FootballMatchMilestones.isHalfTime(type==null?"":type.optString("shortDetail","")) ||
                FootballMatchMilestones.isHalfTime(status==null?"":status.optString("displayClock",""));
            m.kickoff = parseInstant(game.optString("date", ""));
            m.nationalTeam = FootballCompetitionScope.nationalEspn(league);
            m.importance = m.nationalTeam ? 0 : 1;
            if (status != null && m.live) {
                String clock = status.optString("displayClock", "");
                if (clock.isEmpty()) clock = type.optString("shortDetail","");
                m.clock = text(clock,16);
            }
            for (int t=0;t<teams.length();t++) {
                JSONObject p=teams.optJSONObject(t);
                if (p==null) continue;
                JSONObject team=p.optJSONObject("team");
                String name=text(team==null?"":team.optString("displayName", ""),48);
                String score=valScore(p.opt("score"));
                if ("home".equals(p.optString("homeAway"))) {
                    m.home=name; m.h=parseScore(score);
                } else if ("away".equals(p.optString("homeAway"))) {
                    m.away=name; m.a=parseScore(score);
                }
            }
            if (m.upcoming && m.kickoff>now && m.kickoff<=now+TimeUnit.MINUTES.toMillis(90)) {
                m.h=0;m.a=0; // pre-match placeholder, never displayed as a score
            }
            if (m.home!=null && !m.home.isEmpty() && m.away!=null &&
                !m.away.isEmpty() && m.h>=0 && m.a>=0 && recent(m,now) &&
                (!m.upcoming || m.kickoff>now && m.kickoff<=now+TimeUnit.MINUTES.toMillis(90))) {
                if (m.nationalTeam && FootballCompetitionScope.iranNational(m.home,m.away))
                    m.importance = 0;
                found.put(m.id,m);
            }
        }
    }

    private static boolean selectedTournament(JSONObject tournament) {
        if(tournament == null)return false;
        JSONObject category=tournament.optJSONObject("category");
        JSONObject unique=tournament.optJSONObject("uniqueTournament");
        String country=category==null?"":category.optString("name","");
        String region=category==null?"":category.optString("slug","");
        String name=unique!=null?unique.optString("name",tournament.optString("name","")):
            tournament.optString("name","");
        return FootballCompetitionScope.sofa(name,country,region);
    }

    private static String sofaLeague(JSONObject tournament) {
        JSONObject unique = tournament.optJSONObject("uniqueTournament");
        JSONObject category=tournament.optJSONObject("category");
        String country=category==null?"":category.optString("name","");
        String name = unique==null?tournament.optString("name",""):
            unique.optString("name", tournament.optString("name",""));
        boolean iran = "Iran".equalsIgnoreCase(country) ||
            (unique != null && unique.optInt("id", -1) == 915);
        return text((iran ? "ایران · " : "") + name,58);
    }
    private static int sofaScore(JSONObject teamScore) {
        if (teamScore == null) return -1;
        return teamScore.has("current") ? teamScore.optInt("current",-1):
            teamScore.optInt("display",-1);
    }
    private static void fromSofa(JSONObject response, Map<String,Match> found, long now,
                                 Snapshot snapshot) {
        JSONArray events = response.optJSONArray("events");
        if (events==null) return;
        for (int i=0; i<events.length();i++) {
            JSONObject event=events.optJSONObject(i);
            if(event==null)continue;
            JSONObject tournament=event.optJSONObject("tournament");
            if(!selectedTournament(tournament))continue;
            JSONObject status=event.optJSONObject("status");
            String type = status==null?"":status.optString("type","").toLowerCase(Locale.ROOT);
            boolean live=type.contains("inprogress") || type.equals("in");
            boolean ended=type.contains("finished") || type.equals("post");
            boolean upcoming=type.contains("notstarted") || type.contains("pre") || type.equals("notstarted");
            if (!live && !ended && !upcoming) continue;
            JSONObject home=event.optJSONObject("homeTeam");
            JSONObject away=event.optJSONObject("awayTeam");
            Match m=new Match();
            m.id="sofa:"+event.optString("id","");
            if(m.id.endsWith(":"))continue;
            m.home=text(home==null?"":home.optString("name",""),48);
            m.away=text(away==null?"":away.optString("name",""),48);
            m.h=sofaScore(event.optJSONObject("homeScore"));
            m.a=sofaScore(event.optJSONObject("awayScore"));
            m.league=sofaLeague(tournament);
            m.source="Sofascore";
            m.live=live;m.finished=ended;m.upcoming=upcoming;
            m.halftime=status!=null && (
                FootballMatchMilestones.isHalfTime(status.optString("description","")) ||
                FootballMatchMilestones.isHalfTime(status.optString("code","")));
            m.kickoff=1000L*event.optLong("startTimestamp",0);
            m.iran=m.league.contains("ایران");
            m.nationalTeam=FootballCompetitionScope.nationalTournament(m.league);
            m.importance=(m.iran||m.nationalTeam)?0:1;
            // Provider sometimes returns the full clock in 'description'. Do not
            // guess a minute when it instead returns '1st half', 'HT', etc.
            if(live && status!=null) {
                String clock=status.optString("description","");
                if (clock.matches(".*[0-9]{1,3}['’]?(\\\\+[0-9]+)?.*"))
                    m.clock=text(clock,18);
            }
            if(m.upcoming && m.kickoff>now && m.kickoff<=now+TimeUnit.MINUTES.toMillis(90)){
                m.h=0;m.a=0;
            }
            if(m.h>=0&&m.a>=0&&!m.home.isEmpty()&&!m.away.isEmpty()&&recent(m,now) &&
               (!m.upcoming || m.kickoff>now && m.kickoff<=now+TimeUnit.MINUTES.toMillis(90)))
                found.put(m.id,m);
            if(m.iran) { snapshot.iranCovered=true; snapshot.iranMatches++; }
        }
    }
    private static void fromFotmob(JSONObject response, Map<String,Match> found,long now,
                                   Snapshot snapshot) {
        JSONArray leagues=response.optJSONArray("leagues");
        if(leagues==null)return;
        for(int i=0;i<leagues.length();i++){
            JSONObject league=leagues.optJSONObject(i);
            if(league==null)continue;
            String title=league.optString("name","");
            String ccode=league.optString("ccode","");
            String slug=(title+" "+ccode).toLowerCase(Locale.ROOT);
            boolean iran=ccode.equalsIgnoreCase("IRN") &&
                FootballCompetitionScope.iranDomestic(title);
            if(!FootballCompetitionScope.fotmob(title,ccode))continue;
            JSONArray matches=league.optJSONArray("matches");
            if(matches==null)continue;
            for(int j=0;j<matches.length();j++){
                JSONObject e=matches.optJSONObject(j);
                if(e==null)continue;
                JSONObject status=e.optJSONObject("status");
                if(status==null)continue;
                boolean live=status.optBoolean("started",false)&&
                    !status.optBoolean("finished",false) && !status.optBoolean("cancelled",false);
                boolean ended=status.optBoolean("finished",false);
                boolean upcoming=!status.optBoolean("started",false)&&
                    !status.optBoolean("cancelled",false)&&!ended;
                if(!live&&!ended&&!upcoming)continue;
                JSONObject home=e.optJSONObject("home"),away=e.optJSONObject("away");
                if(home==null||away==null)continue;
                Match m=new Match();
                m.id="fotmob:"+e.optString("id","");
                if(m.id.endsWith(":"))continue;
                m.home=text(home.optString("name",""),48);
                m.away=text(away.optString("name",""),48);
                m.h=home.has("score")&&!home.isNull("score")?home.optInt("score",-1):-1;
                m.a=away.has("score")&&!away.isNull("score")?away.optInt("score",-1):-1;
                m.league=(iran?"ایران · ":"")+text(title,50);
                m.source="FotMob";
                m.live=live;m.finished=ended;m.upcoming=upcoming;
                JSONObject reasonForHalf=status.optJSONObject("reason");
                JSONObject timeForHalf=status.optJSONObject("liveTime");
                m.halftime=FootballMatchMilestones.isHalfTime(
                    reasonForHalf==null?"":reasonForHalf.optString("short","")) ||
                    FootballMatchMilestones.isHalfTime(
                    timeForHalf==null?"":timeForHalf.optString("short",""));
                m.kickoff=parseInstant(status.optString("utcTime",""));
                if(m.kickoff==0) m.kickoff=e.optLong("timeTS",0);
                if(live) {
                    JSONObject time=status.optJSONObject("liveTime");
                    m.clock=time==null?"":text(time.optString("short",""),15);
                    if(m.clock.isEmpty()) {
                        JSONObject reason=status.optJSONObject("reason");
                        m.clock=reason==null?"":text(reason.optString("short",""),15);
                    }
                }
                m.nationalTeam=FootballCompetitionScope.nationalTournament(title);
                m.importance=(iran||m.nationalTeam)?0:1;
                m.iran=iran;
                if(m.upcoming && m.kickoff>now && m.kickoff<=now+TimeUnit.MINUTES.toMillis(90)) {
                    m.h=0;m.a=0;
                }
                if(m.h>=0&&m.a>=0&&!m.home.isEmpty()&&!m.away.isEmpty()&&recent(m,now) &&
                    (!m.upcoming || m.kickoff>now && m.kickoff<=now+TimeUnit.MINUTES.toMillis(90))) {
                    if(m.nationalTeam&&FootballCompetitionScope.iranNational(m.home,m.away))m.importance=0;
                    found.put(m.id,m);
                }
                if(iran) { snapshot.iranCovered=true; snapshot.iranMatches++; }
            }
        }
    }

    private static final String SOFA_IRAN = "https://api.sofascore.com/api/v1";
    private static final String FOTMOB_IRAN = "https://www.fotmob.com/api/data";
    private static int iranUniqueTournamentId = 915; // Persian Gulf Pro League

    private static String sourceError(Exception e) {
        if (e.getMessage() != null && e.getMessage().contains("HTTP "))
            return text(e.getMessage(), 90);
        return e.getClass().getSimpleName();
    }

    /** League-specific data source: avoids dropping Iran from huge global schedules. */
    private static void iranSeasonResults(Snapshot snap, Map<String,Match> matches, long now) {
        try {
            JSONObject seasons=getJson(SOFA_IRAN+
                "/unique-tournament/"+iranUniqueTournamentId+"/seasons",300_000);
            JSONArray seasonsList=seasons.optJSONArray("seasons");
            if(seasonsList==null || seasonsList.length()==0)
                throw new IllegalStateException("No active Iran season");
            int season=seasonsList.getJSONObject(0).optInt("id",0);
            if(season<=0)throw new IllegalStateException("Invalid Iran season");
            JSONObject results=getJson(SOFA_IRAN+
                "/unique-tournament/915/season/"+season+"/events/last/0",500_000);
            snap.iranFeedsOk++;
            snap.sourcesOk++;
            fromSofa(results,matches,now,snap);
        }catch(Exception failure){
            snap.iranFeedsFailed++;
            snap.iranError="Sofascore "+sourceError(failure);
        }
    }

    /** The /api/matches URL used by old versions was moved to /api/data/matches. */
    private static void iranDailyFotmob(Snapshot snap,Map<String,Match> matches,long now) {
        java.time.LocalDate today=LocalDate.now(ZoneId.of("Asia/Tehran"));
        // One live date and the 3 preceding Iranian local days.
        // Show latest Iranian results even when no game is played today.
        for(int ago=0;ago<4;ago++) {
            String date=today.minusDays(ago).format(DateTimeFormatter.BASIC_ISO_DATE);
            try {
                JSONObject result=getJson(FOTMOB_IRAN+
                    "/matches?date="+date+"&ccode3=IRN",6_000_000);
                snap.iranFeedsOk++;
                snap.sourcesOk++;
                fromFotmob(result,matches,now,snap);
            }catch(Exception failure) {
                snap.iranFeedsFailed++;
                snap.iranError="FotMob "+sourceError(failure);
            }
            // Avoid excessive calls after collecting at least one recent match
            // if additional days would no longer improve live goal alerts.
            if(ago>=1 && snap.iranCovered)break;
        }
    }

    private static String nameFrom(JSONObject row) {
        if(row==null)return "";
        JSONObject player=row.optJSONObject("player");
        String name=player==null?"":player.optString("name","");
        if(name.isEmpty() && player!=null)name=player.optString("shortName","");
        if(name.isEmpty())name=row.optString("nameStr","");
        if(name.isEmpty())name=row.optString("playerName","");
        if(name.isEmpty())name=row.optString("scorerName","");
        if(name.isEmpty())name=row.optString("name","");
        return text(name,48);
    }
    private static String compactGoals(List<String> goals) {
        if(goals.isEmpty())return "";
        StringBuilder out=new StringBuilder();
        for(String g:goals){
            if(out.length()+g.length()>400)break;
            if(out.length()>0)out.append("، ");
            out.append(g);
        }
        return out.toString();
    }
    private static String sofaGoals(String id) {
        try {
            JSONObject result=getJson(SOFA_IRAN+"/event/"+id+"/incidents",350_000);
            JSONArray incidents=result.optJSONArray("incidents");
            if(incidents==null)return "";
            List<String> goals=new ArrayList<>();
            for(int i=0;i<incidents.length();i++) {
                JSONObject item=incidents.optJSONObject(i);
                if(item==null || !"goal".equalsIgnoreCase(
                    item.optString("incidentType","")))continue;
                String scorer=nameFrom(item);
                if(scorer.isEmpty())continue;
                int minute=item.optInt("time",-1);
                int injury=item.optInt("addedTime",0);
                String stamp=minute>0 && minute<=130 ?
                    " "+minute+(injury>0?"+"+injury:"")+"′" : "";
                String side=item.optBoolean("isHome",false)?"میزبان":"میهمان";
                goals.add(scorer+stamp+" ("+side+")");
            }
            return compactGoals(goals);
        }catch(Exception unavailable){return "";}
    }
    private static String fotmobGoals(String id) {
        try {
            JSONObject data=getJson(FOTMOB_IRAN+"/matchDetails?matchId="+id,2_200_000);
            // FotMob uses several event structures, dependent on competition.
            // Prefer matchFacts events; some low-coverage leagues only return
            // header.events, or lists without the player object.
            List<JSONArray> candidates=new ArrayList<>();
            JSONObject content=data.optJSONObject("content");
            JSONObject facts=content==null?null:content.optJSONObject("matchFacts");
            if(facts!=null){
                JSONObject events=facts.optJSONObject("events");
                if(events!=null) {
                    JSONArray list=events.optJSONArray("events");
                    if(list!=null)candidates.add(list);
                }
                JSONArray list=facts.optJSONArray("events");
                if(list!=null)candidates.add(list);
            }
            JSONObject header=data.optJSONObject("header");
            if(header!=null) {
                JSONArray list=header.optJSONArray("events");
                if(list!=null)candidates.add(list);
            }
            for(JSONArray events:candidates) {
                List<String> goals=new ArrayList<>();
                for(int i=0;i<events.length();i++) {
                    JSONObject event=events.optJSONObject(i);
                    if(event==null)continue;
                    String kind=event.optString("type",event.optString("eventType",""));
                    if(!kind.toLowerCase(Locale.ROOT).contains("goal"))continue;
                    String scorer=nameFrom(event);
                    if(scorer.isEmpty())continue;
                    String stamp=text(event.optString("timeStr",""),12);
                    if(stamp.isEmpty()){
                        int minute=event.optInt("time",event.optInt("minute",0));
                        if(minute>0 && minute<=130)
                            stamp=minute+"′";
                    }
                    goals.add(scorer+(stamp.isEmpty()?"":" "+stamp)+
                        (event.optBoolean("isHome",false)?" (میزبان)":" (میهمان)"));
                }
                if(!goals.isEmpty())return compactGoals(goals);
            }
            return "";
        }catch(Exception unavailable){return "";}
    }

    private static final class CachedGoals {
        String text;
        long at;
        CachedGoals(String text,long at){this.text=text;this.at=at;}
    }
    private static final java.util.concurrent.ConcurrentHashMap<String,CachedGoals>
        goalCache=new java.util.concurrent.ConcurrentHashMap<>();
    private static String cachedGoals(Match match) {
        long now=System.currentTimeMillis();
        CachedGoals cached=goalCache.get(match.id);
        long ttl=match.live?TimeUnit.MINUTES.toMillis(2):TimeUnit.HOURS.toMillis(4);
        if(cached!=null && now-cached.at<ttl)return cached.text;
        String result="";
        if(match.id.startsWith("sofa:"))result=sofaGoals(match.id.substring(5));
        else if(match.id.startsWith("fotmob:"))result=fotmobGoals(match.id.substring(7));
        if(goalCache.size()>64)goalCache.clear();
        goalCache.put(match.id,new CachedGoals(result,now));
        return result;
    }
    private static void enrichIranGoals(Snapshot snap) {
        int inspected=0;
        for(Match match:snap.games) {
            if(!match.iran || match.h+match.a<=0 || match.h<0 || match.a<0)continue;
            if(inspected>=12)break;
            inspected++;
            match.scorers=cachedGoals(match);
            if(match.scorers.isEmpty())snap.scorerUnavailable++;
            else snap.scorerMatches++;
        }
    }

    /** Event timelines are fetched only for active matches, capped to bound
     * requests on a phone. A missing endpoint NEVER generates a guessed card.
     */
    private static void enrichLiveIncidents(Snapshot snapshot) {
        int requested=0;
        for(Match m:snapshot.games) {
            if(!m.live || requested>=10)continue;
            requested++;
            try {
                JSONObject details;
                JSONArray rows;
                if(m.id.startsWith("sofa:")) {
                    details=getJson(SOFA_IRAN+"/event/"+m.id.substring(5)+"/incidents",350_000);
                    rows=details.optJSONArray("incidents");
                } else if(m.id.startsWith("fotmob:")) {
                    details=getJson(FOTMOB_IRAN+"/matchDetails?matchId="+m.id.substring(7),2_200_000);
                    JSONObject content=details.optJSONObject("content");
                    JSONObject facts=content==null?null:content.optJSONObject("matchFacts");
                    JSONObject events=facts==null?null:facts.optJSONObject("events");
                    rows=events==null?null:events.optJSONArray("events");
                    if(rows==null && facts!=null) rows=facts.optJSONArray("events");
                } else if(m.id.startsWith("espn:")) {
                    int last=m.id.lastIndexOf(':');
                    String league=m.id.substring(5,last), event=m.id.substring(last+1);
                    details=getJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+
                        league+"/summary?event="+event,1_200_000);
                    rows=details.optJSONArray("keyEvents");
                } else continue;
                if(rows==null)continue;
                m.incidentsKnown=true;
                for(int i=0;i<rows.length() && i<120;i++) {
                    JSONObject row=rows.optJSONObject(i);
                    if(row==null)continue;
                    String rawType=row.optString("incidentType",row.optString("type",""));
                    if(row.optJSONObject("type")!=null) {
                        JSONObject type=row.optJSONObject("type");
                        rawType=type.optString("text",type.optString("name",type.optString("description","")));
                    }
                    String kind=FootballNotificationPolicy.incidentKind(rawType,
                        row.optString("incidentClass",row.optString("cardDescription","")),
                        row.optString("card",""),
                        row.optBoolean("cancelled",false)||row.optBoolean("isCancelled",false));
                    if(!"RED".equals(kind) && !"YELLOW".equals(kind))continue;
                    Incident inc=new Incident();
                    inc.kind=kind;
                    inc.player=nameFrom(row);
                    if(inc.player.isEmpty())inc.player=text(row.optString("athleteName",""),48);
                    int minute=row.optInt("time",row.optInt("minute",-1));
                    int added=row.optInt("addedTime",row.optInt("overloadTime",0));
                    String formatted=text(row.optString("timeStr",""),14);
                    if(formatted.isEmpty() && minute>0 && minute<=130)
                        formatted=minute+(added>0?"+"+added:"")+"′";
                    inc.minute=formatted;
                    inc.home=row.optBoolean("isHome",row.optBoolean("home",false));
                    // ESPN cards often have team info instead of isHome.
                    String eventId=row.optString("id",row.optString("eventId",""));
                    if(eventId.isEmpty())eventId=kind+":"+inc.minute+":"+
                        inc.player.toLowerCase(Locale.ROOT)+":"+inc.home;
                    inc.id=kind+":"+eventId;
                    m.incidents.add(inc);
                }
            }catch(Exception ignored) {
                // Missing event information is not a zero-card declaration.
            }
        }
    }

    Snapshot collect() {
        Snapshot snapshot = new Snapshot();
        Map<String, Match> matches = new HashMap<>();
        long now = System.currentTimeMillis();

        // Iran sources come first so bad global ESPN response times never
        // prevent loading the user's priority league.
        iranDailyFotmob(snapshot,matches,now);
        if(!snapshot.iranCovered || snapshot.iranMatches==0)
            iranSeasonResults(snapshot,matches,now);

        String date = LocalDate.now(ZoneId.of("UTC"))
            .format(DateTimeFormatter.BASIC_ISO_DATE);
        for(String league:ESPN) {
            String leagueDay=league+":"+date;
            Long skipUntil=quietEspnUntil.get(leagueDay);
            if(skipUntil!=null && skipUntil>now)continue;
            try {
                JSONObject data=getJson("https://site.api.espn.com/apis/site/v2/sports/soccer/"+
                    league+"/scoreboard?dates="+date+"&limit=80",900_000);
                snapshot.sourcesOk++;
                JSONArray listed=data.optJSONArray("events");
                if(listed==null || listed.length()==0)
                    quietEspnUntil.put(leagueDay,now+TimeUnit.MINUTES.toMillis(15));
                else quietEspnUntil.remove(leagueDay);
                fromEspn(snapshot,league,data,matches,now);
            }catch(Exception unavailable){
                snapshot.sourcesFailed++;
                // Temporary upstream failure: retry in 3 minutes, not every
                // 60-second live-match check.
                quietEspnUntil.put(leagueDay,now+TimeUnit.MINUTES.toMillis(3));
            }
        }
        if(quietEspnUntil.size()>120)quietEspnUntil.clear();
        // Sofa daily is only a limited fallback if the league-specific and
        // FotMob routes failed; the global feed can be several megabytes.
        if(!snapshot.iranCovered) {
            try {
                String local=LocalDate.now(ZoneId.of("Asia/Tehran")).toString();
                JSONObject daily=getJson(SOFA_IRAN+
                    "/sport/football/scheduled-events/"+local,6_000_000);
                snapshot.iranFeedsOk++;
                snapshot.sourcesOk++;
                fromSofa(daily,matches,now,snapshot);
            }catch(Exception failure) {
                snapshot.iranFeedsFailed++;
                snapshot.iranError="Sofascore daily "+sourceError(failure);
            }
        }
        // Both ESPN and FotMob may describe the same match under unrelated IDs.
        // Prefer a source consistently, and suppress event notifications when
        // independent providers disagree rather than inventing a "new goal".
        List<FootballSourceReliability.Game> candidates=new ArrayList<>();
        for(Match m:matches.values()) {
            candidates.add(new FootballSourceReliability.Game(m.id,m.home,m.away,
                m.source,m.kickoff,m.h,m.a,m.iran,m.nationalTeam,m.live,m.finished));
        }
        FootballSourceReliability.Result reconciled=FootballSourceReliability.reconcile(candidates);
        snapshot.mergedDuplicates=reconciled.duplicates;
        snapshot.scoreConflicts=reconciled.conflicting;
        snapshot.corroboratedMatches=reconciled.corroborated;
        for(FootballSourceReliability.Group group:reconciled.games) {
            Match preferred=matches.get(group.preferred.id);
            if(preferred==null)continue;
            preferred.stableKey=group.stableId;
            preferred.scoreConflict=group.scoreConflict;
            snapshot.games.add(preferred);
            if("ESPN".equals(preferred.source))snapshot.espnGames++;
            else if("FotMob".equals(preferred.source))snapshot.fotmobGames++;
            else if("Sofascore".equals(preferred.source))snapshot.sofaGames++;
        }
        snapshot.iranMatches=0;
        for(Match m:snapshot.games) if(m.iran)snapshot.iranMatches++;
        snapshot.iranCovered=snapshot.iranMatches>0;

        snapshot.games.sort((a,b)->{
            int importance=Boolean.compare(b.iran,a.iran);
            if(importance!=0)return importance;
            int live=Boolean.compare(b.live,a.live);
            if(live!=0)return live;
            int priority=Integer.compare(a.importance,b.importance);
            if(priority!=0)return priority;
            return Long.compare(b.kickoff,a.kickoff);
        });
        enrichIranGoals(snapshot);
        enrichLiveIncidents(snapshot);
        prefs.edit().putLong(LAST_CHECK,System.currentTimeMillis())
            .putString(LAST_STATUS,snapshot.diagnostics()).apply();
        return snapshot;
    }

    static String summary(Snapshot snap) {
        if(snap.sourcesOk==0)
            return "⚠️ منابع نتایج فوتبال پاسخ ندادند. نتیجه تأییدنشده ارسال نمی‌شود.";
        StringBuilder msg=new StringBuilder("⚽ فوتبال منتخب | ایران، لیگ‌های اروپا و تیم‌های ملی\n");
        msg.append("\n🇮🇷 لیگ‌های ایران:\n");
        int local=0;
        for(Match m:snap.games) {
            if(m.upcoming || !m.iran)continue;
            if(local++>=14)break;
            msg.append(m.line()).append("\n");
        }
        if(local==0) {
            msg.append(snap.iranFeedsOk>0 ?
                "در بازه بررسی‌شده نتیجه تازه‌ای از لیگ ایران ثبت نشده است.\n":
                "⚠️ منابع اختصاصی ایران پاسخ ندادند؛ برای بررسی /footballstatus را بزن.\n");
        }
        msg.append("\n🌍 تیم‌های ملی جهان (از جمله ایران):\n");
        int national=0;
        for(Match m:snap.games) {
            if(m.upcoming || !m.nationalTeam)continue;
            if(national++>=10)break;
            msg.append(m.line()).append("\n");
        }
        if(national==0)msg.append("مسابقه ملی تازه‌ای در بازه بررسی دریافت نشده است.\n");
        msg.append("\n🇪🇺 لیگ‌ها و جام‌های مهم اروپا:\n");
        int euro=0;
        for(Match m:snap.games){
            if(m.upcoming || m.iran || m.nationalTeam)continue;
            if(euro++>=10)break;
            msg.append(m.line()).append("\n");
        }
        if(euro==0)msg.append("نتیجه تازه‌ای از لیگ‌های منتخب اروپا ثبت نشده است.\n");
        msg.append("\nمنابع: ").append(snap.iranCovered?
            "FotMob / Sofascore برای ایران؛ ":"")
            .append("ESPN برای جهان. نام گل‌زن فقط در صورت دریافت داده نمایش داده می‌شود.");
        return msg.toString();
    }
    static String iranSummary(Snapshot snap) {
        StringBuilder msg=new StringBuilder("🇮🇷 لیگ‌های ایران و تیم ملی ایران\n");
        int count=0;
        for(Match m:snap.games) {
            if(m.upcoming || (!m.iran && !(m.nationalTeam && FootballCompetitionScope.iranNational(m.home,m.away)))) continue;
            if(count++>=18)break;
            msg.append("\n").append(m.line()).append("\nمنبع: ").append(m.source).append("\n");
        }
        if(count==0)msg.append(snap.iranFeedsOk>0 ?
            "مسابقه زنده یا پایان‌یافته‌ای در بازه اخیر از لیگ ایران دریافت نشد.":
            "⚠️ دسترسی به داده‌های لیگ ایران برقرار نشد؛ /footballstatus را بررسی کن.");
        msg.append("\n\nوضعیت: ").append(snap.diagnostics());
        return msg.toString();
    }
    private static String key(Match m) {
        return m.stableKey==null || m.stableKey.isEmpty()?m.id:m.stableKey;
    }
    private static JSONObject stateEntry(Match m, JSONObject prior,
                                         boolean finalReportSent, boolean lineupSent,
                                         boolean kickoffSent, boolean halftimeSent) throws Exception {
        JSONObject state=new JSONObject().put("h",m.h).put("a",m.a)
            .put("live",m.live).put("finished",m.finished)
            .put("finalReportSent",finalReportSent)
            .put("upcoming",m.upcoming).put("halftime",m.halftime)
            .put("lineupSent",lineupSent).put("kickoffSent",kickoffSent)
            .put("halftimeSent",halftimeSent)
            .put("ts",System.currentTimeMillis());
        if(m.incidentsKnown) {
            JSONArray known=new JSONArray();
            for(Incident incident:m.incidents)known.put(incident.id);
            state.put("incidentIds",known).put("incidentsKnown",true);
        } else if(prior!=null && prior.optBoolean("incidentsKnown",false)) {
            // Preserve the previous baseline during API outages.
            state.put("incidentIds",prior.optJSONArray("incidentIds"))
                 .put("incidentsKnown",true);
        }
        return state;
    }
    private static final long MAX_STATE_AGE=TimeUnit.DAYS.toMillis(2);
    private static final Map<String,Long> lastLineupCheck=new java.util.concurrent.ConcurrentHashMap<>();
    private static boolean lineupProbeDue(String id,long now) {
        Long last=lastLineupCheck.get(id);
        if(last!=null && now-last<TimeUnit.MINUTES.toMillis(12))return false;
        if(lastLineupCheck.size()>150)lastLineupCheck.clear();
        lastLineupCheck.put(id,now);
        return true;
    }
    private static String goalScorer(Match m) {
        String all = m.scorers;
        if (all==null||all.isEmpty()) {
            all=cachedGoals(m);
        }
        if(all==null||all.isEmpty())return "";
        // Only claim a known scorer when incident details exist.
        String[] goals=all.split("، ");
        return "⚽ گل‌زن گزارش‌شده: " + goals[goals.length-1];
    }
    static final class FootballAlert {
        final Match match;
        final String text,kind;
        FootballAlert(Match match,String text,String kind) {
            this.match=match;this.text=text;this.kind=kind;
        }
    }
    static final class Update {
        Snapshot snapshot;
        final List<String> alerts=new ArrayList<>(); // compatibility with 2.2 diagnostics
        final List<FootballAlert> footballAlerts=new ArrayList<>();
    }
    Update check() {
        Update out=new Update();
        out.snapshot=collect();
        if(out.snapshot.sourcesOk==0)return out;
        JSONObject prior;
        try{prior=new JSONObject(prefs.getString(STATE,"{}"));}
        catch(Exception ignored){prior=new JSONObject();}
        JSONObject next=new JSONObject();
        long now=System.currentTimeMillis();
        int lineupChecks=0;
        for(Match m:out.snapshot.games) {
            try {
                JSONObject old=prior.optJSONObject(key(m));
                // Migrate previous provider-specific score baseline on upgrade.
                if(old==null)old=prior.optJSONObject(m.id);
                if(m.scoreConflict) {
                    // Keep the last trusted score baseline. A conflict may be
                    // caused by API lag, provisional goals or VAR reversals.
                    if(old!=null)next.put(key(m),old);
                    continue;
                }
                boolean lineupSent=old!=null && old.optBoolean("lineupSent",false);
                boolean kickoffSent=old!=null && old.optBoolean("kickoffSent",false);
                boolean halftimeSent=old!=null && old.optBoolean("halftimeSent",false);
                if(lineupChecks<3 && FootballMatchMilestones.canFetchLineup(
                        m.upcoming,m.kickoff,now,lineupSent) &&
                        lineupProbeDue(m.id,now)) {
                    lineupChecks++;
                    FootballMatchExtras.Lineup lineup=FootballMatchExtras.fetchLineup(m);
                    if(FootballMatchMilestones.shouldSendLineup(m.upcoming,m.kickoff,now,
                            lineupSent,lineup.home.size(),lineup.away.size())) {
                        String message=FootballMatchExtras.lineupMessage(m,lineup);
                        out.alerts.add(message);
                        out.footballAlerts.add(new FootballAlert(m,message,
                            FootballPersonalizationPolicy.LINEUP));
                        lineupSent=true;
                    }
                }
                if(FootballMatchMilestones.shouldSendKickoff(old!=null,
                        old!=null && old.optBoolean("upcoming",false),
                        old!=null && old.optBoolean("live",false),m.live,kickoffSent,
                        m.kickoff,now)) {
                    String message="▶️ شروع مسابقه\n"+m.league+"\n"+
                        m.home+" — "+m.away+"\nمنبع: "+m.source;
                    out.alerts.add(message);
                    out.footballAlerts.add(new FootballAlert(m,message,
                        FootballPersonalizationPolicy.KICKOFF));
                    kickoffSent=true;
                }
                if(FootballMatchMilestones.shouldSendHalftime(old!=null,
                        old!=null && old.optBoolean("live",false),
                        old!=null && old.optBoolean("halftime",false),
                        m.halftime,halftimeSent)) {
                    String message=FootballMatchExtras.halftimeMessage(m);
                    out.alerts.add(message);
                    out.footballAlerts.add(new FootballAlert(m,message,
                        FootballPersonalizationPolicy.HALFTIME));
                    halftimeSent=true;
                }
                if(old!=null && m.live) {
                    int h=old.optInt("h",-1),a=old.optInt("a",-1);
                    // A verified score increment is a goal. Do not broadcast
                    // offside decisions, VAR corrections, or routine full-time notices.
                    if ((h>=0 && m.h>h) || (a>=0 && m.a>a)) {
                        String scorer=goalScorer(m);
                        String message="⚽ گل!\n"+m.line()+
                            (scorer.isEmpty()?"":"\n"+scorer)+"\nمنبع: "+m.source;
                        out.alerts.add(message);
                        out.footballAlerts.add(new FootballAlert(m,message,FootballPersonalizationPolicy.GOAL));
                    }
                    if(m.incidentsKnown && old.optBoolean("incidentsKnown",false)) {
                        Set<String> seen=new HashSet<>();
                        JSONArray ids=old.optJSONArray("incidentIds");
                        if(ids!=null)for(int i=0;i<ids.length();i++)seen.add(ids.optString(i,""));
                        for(Incident incident:m.incidents) {
                            if(!seen.contains(incident.id)) {
                                String message=incident.message(m);
                                out.alerts.add(message);
                                out.footballAlerts.add(new FootballAlert(m,message,FootballPersonalizationPolicy.fromIncident(incident.kind)));
                            }
                        }
                    }
                }
                // The post-match report is separate from goal/card notifications
                // and the nightly 23:00 digest. Trigger only upon an observed
                // final-whistle transition: no flood of historic matches on startup.
                boolean finalSent=old!=null && old.optBoolean("finalReportSent",false);
                if(FootballFinalReportPolicy.shouldPublish(
                        old!=null, old!=null && old.optBoolean("finished",false),
                        m.finished,m.kickoff,now,finalSent) &&
                        out.footballAlerts.size()<8) {
                    FootballFinalStats.Summary stats=FootballFinalStats.fetch(m);
                    String report=FootballFinalStats.message(m,stats);
                    out.alerts.add(report);
                    out.footballAlerts.add(new FootballAlert(m,report,FootballPersonalizationPolicy.FINAL));
                    finalSent=true;
                }
                next.put(key(m),stateEntry(m,old,finalSent,lineupSent,kickoffSent,halftimeSent));
            } catch(Exception ignored){ }
        }
        // Retain last-seen matches briefly. When an upstream temporarily omits a
        // match it should not be mistaken for a new match on the next poll.
        JSONArray keys=prior.names();
        if(keys!=null)for(int i=0;i<keys.length();i++){
            String id=keys.optString(i,"");
            if(next.has(id))continue;
            JSONObject entry=prior.optJSONObject(id);
            if(entry!=null && now-entry.optLong("ts",0)<MAX_STATE_AGE)
                try{next.put(id,entry);}catch(Exception ignored){}
        }
        prefs.edit().putString(STATE,next.toString()).apply();
        // Avoid a huge storm after reconnection.
        while(out.alerts.size()>8)out.alerts.remove(out.alerts.size()-1);
        while(out.footballAlerts.size()>8)
            out.footballAlerts.remove(out.footballAlerts.size()-1);
        return out;
    }
}
package com.javid.downloader;

public final class RainProbabilityPolicyTest {
    private static void check(boolean valid,String message) {
        if(!valid)throw new AssertionError(message);
    }
    public static void main(String[] args) {
        long t=1_800_000_000L;
        long[] hours={t,t+3600,t+7200,t+10800,t+14400};
        double[] scores={50,51,73,30,99};
        RainProbabilityPolicy.Event found=RainProbabilityPolicy.firstEvent(t,hours,scores);
        check(found!=null,"Should find >50 rain alert");
        check(found.startEpochSeconds==t+3600,"50% must not alert");
        check(found.peakProbability==73,"Should aggregate contiguous hourly probability");
        check(found.endEpochSeconds==t+10800,"Must end when probability drops");
        check(RainProbabilityPolicy.firstEvent(t,hours,new double[]{0,20,50,20,50})==null,
            "50% is NOT more than 50%");
        check(RainProbabilityPolicy.firstEvent(t,hours,new double[]{0,0,51,0,0})!=null,
            "51% should qualify");
        System.out.println("PASS: 50% rain probability tests");
    }
}

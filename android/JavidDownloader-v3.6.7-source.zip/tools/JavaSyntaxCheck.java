import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.util.*;
import java.io.*;
/** Syntax-only smoke test, does NOT replace Android compilation. */
public class JavaSyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> errors=new DiagnosticCollector<>();
        StandardJavaFileManager manager=compiler.getStandardFileManager(errors,null,null);
        Iterable<? extends JavaFileObject> files=manager.getJavaFileObjects(args);
        JavacTask task=(JavacTask)compiler.getTask(null,manager,errors,
            Arrays.asList("-proc:none"),null,files);
        int count=0;
        for(Object ignored:task.parse())count++;
        boolean failed=false;
        for(Diagnostic<?> error:errors.getDiagnostics()){
            if(error.getKind()==Diagnostic.Kind.ERROR){
                failed=true;
                System.err.println(error);
            }
        }
        if(failed)System.exit(1);
        System.out.println("Syntax parse OK for "+count+" Java source files.");
    }
}
